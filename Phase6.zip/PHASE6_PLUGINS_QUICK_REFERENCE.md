# PRISM Phase 6 (Plugin System) - Quick Reference

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
```

---

## Files to Create

### Core Module (4 files)
```
core/
├── __init__.py              # Exports
├── plugin_base.py           # EnginePlugin, WorkflowPlugin, PanelPlugin
├── plugin_loader.py         # Auto-discovery system
├── settings_manager.py      # Settings/presets
└── validator.py             # Plugin validation
```

### Plugin Directories
```
plugins/
├── __init__.py
├── engines/
│   ├── __init__.py
│   └── example_plugin.py    # Example engine
├── workflows/
│   └── __init__.py
└── panels/
    └── __init__.py
```

### Configuration
```
config/
├── defaults.yaml            # Default settings
└── presets/
    ├── quick_analysis.yaml
    └── full_analysis.yaml
```

---

## Verification Commands

```bash
# Test 1: Check directories
ls -la plugins/ config/

# Test 2: Test imports
python -c "from core import PluginLoader, SettingsManager; print('OK')"

# Test 3: Run example plugin
python plugins/engines/example_plugin.py

# Test 4: Full verification
python test_phase6_plugins.py
# Expected: ALL 7 TESTS PASSED
```

---

## Quick Plugin Creation

### New Engine (3 steps)
```python
# 1. Create: plugins/engines/my_engine.py
from core import EnginePlugin

class MyEngine(EnginePlugin):
    name = "my_engine"
    version = "1.0.0"
    
    def analyze(self, data, **kwargs):
        return {"status": "ok"}

# 2. Verify: python prism_run.py --list-engines
# 3. Use: python prism_run.py --panel market --engine my_engine
```

---

## Key Classes

| Class | Purpose |
|-------|---------|
| `EnginePlugin` | Base for analysis engines |
| `WorkflowPlugin` | Base for workflows |
| `PanelPlugin` | Base for data panels |
| `PluginLoader` | Auto-discovers plugins |
| `SettingsManager` | Manages config/presets |
| `PluginValidator` | Validates plugins |

---

## Commit Message

```
Phase 6: Add professional plugin system

- Add core/plugin_base.py with base classes
- Add core/plugin_loader.py for auto-discovery
- Add core/settings_manager.py for configuration
- Add plugins/ drop-in directories
- Add config/ with defaults and presets
- Add example_plugin.py demonstrating usage

New plugins appear automatically without code changes.
```

---

## Success Criteria

✅ `from core import PluginLoader` works  
✅ `plugins/engines/` exists with example  
✅ `config/defaults.yaml` exists  
✅ Example plugin runs standalone  
✅ New plugin auto-discovered  
✅ Settings load/save works  
✅ test_phase6_plugins.py passes all 7 tests

---

## Architecture Overview

```
User creates:
  plugins/engines/new_engine.py
       ↓
PluginLoader.discover_all()
       ↓
New engine in --list-engines
       ↓
Available for analysis!
```

No code changes required - just drop files in plugins/
