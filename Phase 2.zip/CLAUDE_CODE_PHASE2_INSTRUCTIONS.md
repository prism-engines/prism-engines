# PRISM Phase 2: HTML Runner Implementation
## Claude Code Implementation Instructions

**TARGET BRANCH: main**
**DO NOT CREATE A NEW BRANCH - Work directly on main**
**PREREQUISITE: Phase 1 must be complete (engines/, workflows/ registries)**

---

## Overview

Phase 2 creates the HTML-based web interface for PRISM. After this phase, running `python prism_run.py` opens a browser with a clean UI for selecting panels, workflows, and running analysis.

**Goals:**
1. Create Flask-based web server
2. Create dispatcher to route UI → workflow execution
3. Create HTML templates (base, index, results, reports)
4. Update root prism_run.py to launch HTML interface
5. Verify end-to-end workflow

**Success Criteria:**
- `python prism_run.py` starts server and opens browser
- UI shows panel/workflow/weighting dropdowns
- Clicking RUN executes analysis and shows results
- Report HTML is generated and accessible

---

## Step 1: Update runner/__init__.py

**File:** `runner/__init__.py`

```python
"""
PRISM Runner Package
=====================

Unified entry point for PRISM analysis with HTML interface.

Usage:
    python -m runner                    # Launch HTML UI
    python -m runner --cli              # CLI mode
    
    from runner import Dispatcher
    
    dispatcher = Dispatcher()
    results = dispatcher.run({"workflow": "regime_comparison"})
"""

from .dispatcher import Dispatcher, DispatchError

__all__ = [
    "Dispatcher",
    "DispatchError",
]
```

---

## Step 2: Create runner/dispatcher.py

**File:** `runner/dispatcher.py`

```python
"""
PRISM Dispatcher
=================

Routes UI requests to the appropriate workflow execution.
"""

import logging
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime
import sys

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

logger = logging.getLogger(__name__)


class DispatchError(Exception):
    """Raised when dispatch fails."""
    pass


class Dispatcher:
    """Routes analysis requests to workflow execution."""
    
    def __init__(self, output_dir: Optional[Path] = None):
        self.output_dir = output_dir or PROJECT_ROOT / "output"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.current_run_dir: Optional[Path] = None
        self.run_start_time: Optional[datetime] = None
    
    def run(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an analysis based on parameters."""
        self.run_start_time = datetime.now()
        
        # Create output directory for this run
        timestamp = self.run_start_time.strftime("%Y-%m-%d_%H%M%S")
        self.current_run_dir = self.output_dir / timestamp
        self.current_run_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Starting dispatch: {params.get('workflow')} on {params.get('panel')}")
        logger.info(f"Output directory: {self.current_run_dir}")
        
        try:
            workflow_key = params.get("workflow", "regime_comparison")
            
            # Route to appropriate handler
            if workflow_key == "regime_comparison":
                results = self._run_regime_comparison(params)
            elif workflow_key == "full_temporal":
                results = self._run_full_temporal(params)
            elif workflow_key == "daily_update":
                results = self._run_daily_update(params)
            else:
                results = self._run_workflow_from_registry(workflow_key, params)
            
            duration = (datetime.now() - self.run_start_time).total_seconds()
            results.update({
                "status": "success",
                "output_dir": str(self.current_run_dir),
                "duration": duration,
                "timestamp": timestamp,
            })
            
            logger.info(f"Dispatch complete in {duration:.1f}s")
            return results
            
        except Exception as e:
            logger.exception(f"Dispatch failed: {e}")
            duration = (datetime.now() - self.run_start_time).total_seconds()
            return {
                "status": "error",
                "error": str(e),
                "output_dir": str(self.current_run_dir),
                "duration": duration,
            }
    
    def _run_regime_comparison(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Run the regime comparison workflow."""
        logger.info("Running regime comparison workflow...")
        
        try:
            from engine_core.tandem_regime_runner import TandemRegimeRunner
            
            comparison_periods = params.get("comparison_periods") or [
                "2001_dotcom", "2008_gfc", "2020_covid", "2022_bear"
            ]
            
            runner = TandemRegimeRunner(
                current_period="2024_current",
                comparison_periods=comparison_periods,
                data_source="database",
                output_dir=self.current_run_dir,
            )
            
            results = runner.run()
            return {
                "report_path": results.get("report_path"),
                "comparisons": results.get("comparisons", {}),
            }
            
        except ImportError as e:
            logger.warning(f"TandemRegimeRunner not available: {e}")
            return self._create_placeholder_report("regime_comparison", params)
    
    def _run_full_temporal(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Run the full temporal analysis workflow."""
        logger.info("Running full temporal analysis workflow...")
        return self._create_placeholder_report("full_temporal", params)
    
    def _run_daily_update(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Run the daily update workflow."""
        logger.info("Running daily update workflow...")
        return self._create_placeholder_report("daily_update", params)
    
    def _run_workflow_from_registry(self, workflow_key: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Run a workflow loaded from the registry."""
        logger.info(f"Running workflow from registry: {workflow_key}")
        
        try:
            from workflows.workflow_loader import WorkflowLoader
            loader = WorkflowLoader()
            results = loader.run_workflow(workflow_key, panel=params.get("panel"))
            return results
        except Exception as e:
            logger.warning(f"Could not run workflow {workflow_key}: {e}")
            return self._create_placeholder_report(workflow_key, params)
    
    def _create_placeholder_report(self, workflow: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create a placeholder report."""
        report_path = self.current_run_dir / f"{workflow}_report.html"
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PRISM Report - {workflow}</title>
    <style>
        body {{ font-family: system-ui, sans-serif; background: #f8fafc; padding: 2rem; }}
        .container {{ max-width: 800px; margin: 0 auto; }}
        .card {{ background: white; border-radius: 12px; padding: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 1rem; }}
        h1 {{ color: #2563eb; }}
        .badge {{ display: inline-block; padding: 0.25rem 0.75rem; background: #dbeafe; color: #1d4ed8; border-radius: 9999px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>🔍 PRISM Analysis Report</h1>
            <p><span class="badge">{workflow}</span></p>
            <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        </div>
        <div class="card">
            <h2>📋 Configuration</h2>
            <p><strong>Workflow:</strong> {workflow}</p>
            <p><strong>Panel:</strong> {params.get('panel', 'market')}</p>
            <p><strong>Weighting:</strong> {params.get('weighting', 'hybrid')}</p>
        </div>
        <div class="card">
            <h2>⚠️ Placeholder Report</h2>
            <p>Full implementation will include detailed analysis results.</p>
        </div>
    </div>
</body>
</html>"""
        
        with open(report_path, "w") as f:
            f.write(html_content)
        
        return {"report_path": str(report_path), "placeholder": True}
```

---

## Step 3: Create runner/prism_run.py (Flask Server)

**File:** `runner/prism_run.py`

This is a large file (~400 lines). Key components:

1. **Flask App Factory** (`create_app()`)
2. **Routes**: `/`, `/run`, `/reports`, `/health`, `/api/*`
3. **Data Loaders**: `get_available_panels()`, `get_available_workflows()`, `get_weighting_methods()`
4. **Server Management**: `run_server()`, `open_browser()`

See the full implementation in the Phase 2 package.

---

## Step 4: Create templates/base.html

**File:** `templates/base.html`

Base template with:
- CSS variables and styling
- Header with PRISM logo and navigation
- Footer
- Block placeholders for content

Key CSS classes:
- `.card` - White card with shadow
- `.btn`, `.btn-primary`, `.btn-run` - Buttons
- `.option-card` - Selectable option cards
- `.form-select`, `.form-input` - Form elements

---

## Step 5: Create templates/runner/index.html

**File:** `templates/runner/index.html`

Main UI with:
- Panel selection (clickable cards)
- Workflow dropdown
- Weighting method selection
- Timeframe options (collapsible)
- Comparison periods (for regime_comparison)
- RUN button
- Loading overlay

JavaScript handles:
- Option card selection
- Workflow-based UI changes
- Form submission with loading state

---

## Step 6: Create templates/runner/results.html

**File:** `templates/runner/results.html`

Results display with:
- Success/error alert
- Report link
- Output folder path
- Similarity rankings (for regime comparison)
- Configuration summary
- Navigation buttons

---

## Step 7: Create templates/runner/reports.html

**File:** `templates/runner/reports.html`

Report listing with:
- Table of recent reports
- Open button for each report
- Empty state when no reports

---

## Step 8: Update Root prism_run.py

**File:** `prism_run.py` (project root)

```python
#!/usr/bin/env python3
"""
PRISM Runner - Unified Entry Point
===================================

Launches the PRISM analysis interface.

Usage:
    python prism_run.py              # Opens HTML interface in browser
    python prism_run.py --cli        # Command-line interface
    python prism_run.py --port 8080  # Custom port
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

def main():
    """Main entry point - delegates to runner module."""
    from runner.prism_run import main as runner_main
    runner_main()

if __name__ == "__main__":
    main()
```

---

## Step 9: Create Directory Structure

```bash
mkdir -p templates/runner
mkdir -p templates/static
```

---

## Step 10: Verify Phase 2

```bash
# Test 1: Runner imports
python -c "from runner.prism_run import create_app; print('✓ Runner imports OK')"

# Test 2: Dispatcher works
python -c "from runner.dispatcher import Dispatcher; d = Dispatcher(); print('✓ Dispatcher OK')"

# Test 3: Full verification
python test_phase2.py

# Test 4: Manual launch (will open browser)
python prism_run.py
```

---

## Step 11: Commit Changes

```bash
git add runner/ templates/ prism_run.py test_phase2.py
git commit -m "Phase 2: Add HTML Runner interface

- Add runner/prism_run.py Flask server with auto-browser launch
- Add runner/dispatcher.py to route UI to workflow execution
- Add templates/base.html with PRISM styling
- Add templates/runner/ UI templates (index, results, reports)
- Update root prism_run.py to delegate to HTML runner

Usage: python prism_run.py opens browser to http://localhost:5000
Select panel, workflow, weighting → click RUN → view results"
```

---

## Files Created Summary

```
runner/
  __init__.py         # Package with Dispatcher export
  prism_run.py        # Flask server (~400 lines)
  dispatcher.py       # Routes UI → workflows (~200 lines)

templates/
  base.html           # Base template with styling (~300 lines)
  runner/
    index.html        # Main UI (~300 lines)
    results.html      # Results display (~150 lines)
    reports.html      # Report listing (~50 lines)

prism_run.py          # Root entry point (updated)
test_phase2.py        # Verification script
```

---

## How It Works

```
python prism_run.py
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│  Flask Server (localhost:5000)                              │
│  Browser auto-opens                                         │
└─────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│  templates/runner/index.html                                │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  📊 Panel: [Market] [Economy] [Climate] [Custom]    │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │  🔄 Workflow: ▼ Regime Comparison                   │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │  ⚖️ Weighting: [Meta] [ML] [✓Hybrid] [None]        │    │
│  ├─────────────────────────────────────────────────────┤    │
│  │           [ ▶ RUN ANALYSIS ]                        │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
         │ POST /run
         ▼
┌─────────────────────────────────────────────────────────────┐
│  runner/dispatcher.py                                       │
│  → routes to workflow handler                               │
│  → creates output directory                                 │
│  → generates HTML report                                    │
└─────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│  templates/runner/results.html                              │
│                                                             │
│  ✅ Analysis Complete!                                      │
│  📄 Open Report → output/2024-12-07_1430/report.html       │
└─────────────────────────────────────────────────────────────┘
```

---

## Next Phase Preview

Phase 3 will:
- Wire up real workflow execution (TandemRegimeRunner, TemporalRunner)
- Add WebSocket for live progress updates
- Add session persistence (remember last run)
- Connect to actual database and ML models
