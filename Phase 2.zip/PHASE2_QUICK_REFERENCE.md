# PRISM Phase 2 - Quick Reference for Claude Code

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
```

---

## Files to Create (9 total)

### 1. runner/__init__.py (update)
```python
from .dispatcher import Dispatcher, DispatchError
__all__ = ["Dispatcher", "DispatchError"]
```

### 2. runner/dispatcher.py (~200 lines)
- Dispatcher class routes UI params → workflow execution
- Creates timestamped output directories
- Generates placeholder reports for unimplemented workflows

### 3. runner/prism_run.py (~400 lines)
- Flask app factory: `create_app()`
- Routes: `/`, `/run`, `/reports`, `/health`, `/api/*`
- Data loaders that read from Phase 1 registries
- Server launch with auto-browser open

### 4. templates/base.html (~300 lines)
- CSS styling (cards, buttons, forms, badges)
- Header with PRISM logo
- Navigation links
- Footer

### 5. templates/runner/index.html (~300 lines)
- Panel selection cards
- Workflow dropdown
- Weighting method selection
- RUN button with loading state

### 6. templates/runner/results.html (~150 lines)
- Success/error display
- Report link
- Configuration summary

### 7. templates/runner/reports.html (~50 lines)
- Table of recent reports

### 8. prism_run.py (root - update)
```python
#!/usr/bin/env python3
import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

def main():
    from runner.prism_run import main as runner_main
    runner_main()

if __name__ == "__main__":
    main()
```

### 9. test_phase2.py
- Verification script (8 test functions)

---

## Directory Structure After Phase 2

```
prism-engine/
├── prism_run.py              # Entry point (launches HTML UI)
├── engines/                   # Phase 1
│   ├── __init__.py
│   ├── registry.yaml
│   └── engine_loader.py
├── workflows/                 # Phase 1
│   ├── __init__.py
│   ├── registry.yaml
│   └── workflow_loader.py
├── runner/                    # Phase 2
│   ├── __init__.py
│   ├── prism_run.py          # Flask server
│   └── dispatcher.py         # UI → workflow routing
├── templates/                 # Phase 2
│   ├── base.html
│   └── runner/
│       ├── index.html
│       ├── results.html
│       └── reports.html
├── test_phase1.py
└── test_phase2.py
```

---

## Verification Commands

```bash
# Test 1: Flask available
python -c "from flask import Flask; print('Flask OK')"

# Test 2: Runner imports
python -c "from runner.prism_run import create_app; print('Runner OK')"

# Test 3: Dispatcher works
python -c "from runner.dispatcher import Dispatcher; Dispatcher().run({'workflow':'daily_update'})"

# Test 4: Full verification
python test_phase2.py

# Test 5: Launch (will open browser!)
python prism_run.py
```

---

## Commit Message

```
Phase 2: Add HTML Runner interface

- Add runner/prism_run.py Flask server with auto-browser launch
- Add runner/dispatcher.py to route UI to workflow execution
- Add templates/base.html with PRISM styling
- Add templates/runner/ UI templates (index, results, reports)
- Update root prism_run.py to delegate to HTML runner

Usage: python prism_run.py opens browser to http://localhost:5000
Select panel, workflow, weighting → click RUN → view results
```

---

## Success Criteria

✅ `python test_phase2.py` passes all 8 tests  
✅ `python prism_run.py` starts server on port 5000  
✅ Browser opens to UI with panel/workflow dropdowns  
✅ Clicking RUN executes and shows results page  
✅ Report HTML files generated in output/ directory

---

## Key Routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/` | GET | Main runner UI |
| `/run` | POST | Execute analysis |
| `/reports` | GET | List recent reports |
| `/health` | GET | Health check |
| `/api/workflows/<panel>` | GET | Get workflows for panel |
| `/output/<path>` | GET | Serve report files |

---

## What User Sees

```
┌─────────────────────────────────────────────────────────────┐
│  🔍 PRISM   Panel-Based Regime Analysis      Runner  Reports│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📊 SELECT PANEL DOMAIN                                     │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐           │
│  │📈Market │ │🏛Economy│ │📊M+E    │ │🌍Climate│           │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘           │
│                                                             │
│  🔄 SELECT WORKFLOW                                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ ▼ Regime Comparison (2-5 min)                       │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ⚖️ ENGINE WEIGHTING                                        │
│  ┌───────┐ ┌───────┐ ┌─────────┐ ┌───────┐                 │
│  │ Meta  │ │  ML   │ │✓Hybrid  │ │ None  │                 │
│  └───────┘ └───────┘ └─────────┘ └───────┘                 │
│                                                             │
│              ┌──────────────────────┐                       │
│              │   ▶ RUN ANALYSIS     │                       │
│              └──────────────────────┘                       │
│              Estimated time: 2-5 minutes                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
