"""Unit tests for PRISM lenses"""
