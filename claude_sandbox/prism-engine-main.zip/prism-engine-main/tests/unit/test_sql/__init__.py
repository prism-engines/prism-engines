"""Tests for SQL database module."""
