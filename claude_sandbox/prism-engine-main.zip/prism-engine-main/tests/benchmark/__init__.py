"""
PRISM Benchmark Tests
=====================

Tests for benchmark dataset loading and validation.
"""
