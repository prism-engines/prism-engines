"""
PRISM Engine - Test Suite

Run with: pytest tests/
"""
