# Raw Data (Unmodified)

Raw CSV files exactly as fetched.
Never edited.
Never overwritten.