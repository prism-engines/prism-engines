# Data Folder

Contains raw, cleaned, and registry datasets.
Everything here is purely input — no engine logic.