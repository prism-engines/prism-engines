# Registry Files

Holds indicator registry and metric registry definitions.