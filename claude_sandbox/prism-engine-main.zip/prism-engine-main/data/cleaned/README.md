# Cleaned Data

Normalized, aligned, or otherwise processed versions of raw data.