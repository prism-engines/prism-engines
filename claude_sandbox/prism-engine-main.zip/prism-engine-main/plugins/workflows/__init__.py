"""
PRISM Workflow Plugins
=======================

Drop-in directory for workflow plugins.
Place Python files here to add new workflows.
"""
