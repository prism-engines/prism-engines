# PRISM Unified FRED Fetcher Integration

## Overview

We're replacing the multi-source data fetching approach (Stooq → Yahoo → FRED with fallback chains) with a **single-source FRED-only fetcher**. FRED provides both market data (S&P 500, NASDAQ, VIX, GICS sectors) and economic data, eliminating fallback complexity.

---

## File Placement

**New file:** `prism_fred_unified.py`

**Recommended location:**
```
fetch/fetcher_unified.py
```

This sits alongside existing fetchers:
```
fetch/
├── fetcher_base.py
├── fetcher_fred.py       # Existing (may be deprecated or merged)
├── fetcher_yahoo.py      # Keep for backward compat, lower priority
├── fetcher_stooq.py      # Keep for backward compat, lower priority
└── fetcher_unified.py    # NEW - Single source for all PRISM data
```

---

## Task 1: Check for Naming Conflicts

The new fetcher uses these indicator keys. **Please scan the codebase for conflicts with existing keys in registries and scripts.**

### New Fetcher Keys by Panel

**MARKET Panel:**
```
sp500, nasdaq, djia
sect_energy, sect_materials, sect_industrials, sect_cons_disc, sect_cons_stpl
sect_healthcare, sect_financials, sect_tech, sect_comm, sect_utilities, sect_realestate
vix, stress_idx, hy_spread, ted_spread, mortgage_30y, home_price, fin_oblig
```

**ECONOMY Panel:**
```
gdp_real, gdp_potential, indpro, cap_util, housing_starts, retail_sales, cap_orders
payrolls, unemployment, lfpr, emp_pop, init_claims, job_openings
pce, pce_core, cpi, cpi_core, infl_expect
fed_funds, treasury_10y, yield_curve, fed_balance, m2, bank_reserves
consumer_sent, ism_mfg_new, ism_svc
```

**GLOBAL Panel:**
```
oil_wti, nat_gas, commodity_idx, usd_eur, usd_index
trade_balance, imports, exports
```

**CREDIT Panel:**
```
bus_loans, consumer_cred, fed_debt, total_debt, debt_gdp
```

### Files to Check

1. **Panel registries:**
   - `panels/market/registry.yaml`
   - `panels/economy/registry.yaml`
   - `panels/climate/registry.yaml`
   - `panels/custom/registry.yaml`

2. **Data registries:**
   - `data/registry/market_registry.json`
   - `data/registry/system_registry.json`

3. **Any Python files referencing indicator keys:**
   - `data_fetch/*.py`
   - `engine_core/lenses/*.py`
   - `panels/**/panel.py`
   - `runner/*.py`

### What to Report

For each conflict found, note:
- **File:** where the conflict exists
- **Existing key:** what's currently used (e.g., `fedfunds`)
- **New key:** what the unified fetcher uses (e.g., `fed_funds`)
- **Recommendation:** align new fetcher OR update existing code

---

## Task 2: Integration Points

After resolving naming, update these files to use the unified fetcher:

### Primary Integration
```python
# In data_fetch/fetch_market_data.py or panels/*/panel.py

# OLD (multi-source with fallback)
from fetch.fetcher_stooq import StooqFetcher
from fetch.fetcher_yahoo import YahooFetcher
from fetch.fetcher_fred import FREDFetcher

# NEW (single source)
from fetch.fetcher_unified import PRISMFetcher

fetcher = PRISMFetcher(api_key=FRED_API_KEY)
market_df = fetcher.fetch_panel('market')
economy_df = fetcher.fetch_panel('economy')
```

### Panel-Level Integration
```python
# panels/market/panel.py
def fetch_data(self, indicators, start_date, end_date):
    from fetch.fetcher_unified import PRISMFetcher
    fetcher = PRISMFetcher()
    return fetcher.fetch_panel('market', indicators=indicators)

# panels/economy/panel.py  
def fetch_data(self, indicators, start_date, end_date):
    from fetch.fetcher_unified import PRISMFetcher
    fetcher = PRISMFetcher()
    return fetcher.fetch_panel('economy', indicators=indicators)
```

---

## Task 3: Deprecation Path

Once unified fetcher is validated:

1. **Keep but deprioritize:**
   - `fetcher_yahoo.py` — may still be useful for intraday or specific tickers
   - `fetcher_stooq.py` — backup option

2. **Merge or deprecate:**
   - `fetcher_fred.py` — functionality now in `fetcher_unified.py`

3. **Simplify:**
   - `data_fetch/fetch_market_data.py` — remove fallback chains, just call unified fetcher

---

## Task 4: Validation Checklist

After integration, verify:

- [ ] `PRISMFetcher` imports without error
- [ ] `fetch_panel('market')` returns DataFrame with expected columns
- [ ] `fetch_panel('economy')` returns DataFrame with expected columns
- [ ] `get_sectors()` returns all 11 GICS sectors
- [ ] `save_to_csv()` writes to expected location
- [ ] Existing panel loaders work with new data format
- [ ] No broken imports in `runner/`, `engine_core/`, `panels/`

---

## Key Benefits of This Change

| Before | After |
|--------|-------|
| 3 data sources (Stooq, Yahoo, FRED) | 1 source (FRED) |
| Fallback chains with error handling | Direct fetch, simple errors |
| Mixed ticker formats | Consistent PRISM keys |
| Separate market vs economy fetchers | Unified by panel |
| ~200 lines of fallback logic | ~50 lines direct fetch |

---

## Questions for Claude Code

1. Are there any hardcoded FRED symbols (like `FEDFUNDS`, `DGS10`) in Python files that should use the new keys instead?

2. Do any scripts construct indicator lists dynamically that would break with new key names?

3. Is there a central config or constants file where indicator mappings are defined?

4. What's the current state of `data_fetch/fetch_market_data.py` — is it still using the Stooq→Yahoo fallback pattern?

---

## Files Attached

- `prism_fred_unified.py` — The new unified fetcher (place in `fetch/fetcher_unified.py`)
