# PR: Add Hidden Variation Detector (HVD) - Advisory Only

## Summary

Adds a **Hidden Variation Detector (HVD)** layer that uses similarity metrics and unsupervised ML to:

1. **Find highly similar indicators** - Potential double-count / redundancy
2. **Find behavior clusters** - Groups of indicators that move together
3. **Flag divergences** - Family members that stop behaving alike

**IMPORTANT**: This is READ-ONLY and ADVISORY.
- ❌ No changes to PRISM geometry math
- ❌ No changes to weights / engine outputs  
- ✅ Only warnings, clusters, and summary objects for UI and logs

---

## Files to Create

| File | Target Location |
|------|-----------------|
| `hidden_variation_detector.py` | `analysis/hidden_variation_detector.py` |
| `test_hidden_variation_detector.py` | `tests/test_hidden_variation_detector.py` |

---

## Step 1: Create Directory and Module

```bash
mkdir -p analysis
touch analysis/__init__.py
```

---

## Step 2: Create `analysis/hidden_variation_detector.py`

```python
"""
Hidden Variation Detector (HVD)
===============================

Advisory-only layer that uses similarity metrics and unsupervised ML to:
1. Find highly similar indicators (potential double-count / redundancy)
2. Find behavior clusters (groups of indicators that move together)
3. Flag divergences (family members that stop behaving alike)

IMPORTANT: This module is READ-ONLY and ADVISORY.
- No changes to PRISM geometry math
- No changes to weights / engine outputs
- Only warnings, clusters, and summary objects for UI and logs
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict


@dataclass
class SimilarityResult:
    """Result of pairwise similarity analysis."""
    pair: Tuple[str, str]
    window: str                    # e.g. 'full', '5y', '1y'
    correlation: float
    distance: float                # e.g. 1 - |corr|
    flags: List[str] = field(default_factory=list)


@dataclass
class ClusterResult:
    """Result of clustering analysis."""
    cluster_id: int
    members: List[str]
    method: str                    # e.g. 'kmeans', 'hierarchical', 'correlation'
    centroid_indicator: Optional[str] = None
    intra_cluster_correlation: Optional[float] = None
    notes: str = ""


@dataclass
class FamilyDivergence:
    """Detected divergence within an indicator family."""
    family_id: str
    member_1: str
    member_2: str
    correlation: float
    window: str
    expected_correlation: float = 0.80
    severity: str = "medium"


@dataclass
class HVDReport:
    """Complete Hidden Variation Detector report."""
    indicators: List[str]
    similarity_results: List[SimilarityResult]
    clusters: List[ClusterResult]
    family_divergences: List[FamilyDivergence]
    warnings: List[str]
    meta: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def high_similarity_pairs(self) -> List[SimilarityResult]:
        return [r for r in self.similarity_results if 'HIGH_SIMILARITY' in r.flags]
    
    def summary(self) -> Dict[str, Any]:
        return {
            'total_indicators': len(self.indicators),
            'high_similarity_count': len(self.high_similarity_pairs),
            'cluster_count': len(self.clusters),
            'divergence_count': len(self.family_divergences),
            'warning_count': len(self.warnings)
        }


def compute_similarity_matrix(
    panel: pd.DataFrame,
    min_overlap: int = 252
) -> Dict[Tuple[str, str], float]:
    """
    Compute pairwise Pearson correlations between columns.
    Only use overlapping non-NaN periods.
    """
    similarity = {}
    columns = list(panel.columns)
    
    for i, col1 in enumerate(columns):
        for col2 in columns[i+1:]:
            mask = panel[col1].notna() & panel[col2].notna()
            if mask.sum() < min_overlap:
                continue
            
            series1 = panel.loc[mask, col1]
            series2 = panel.loc[mask, col2]
            
            try:
                corr = np.corrcoef(series1.values, series2.values)[0, 1]
                if not np.isnan(corr):
                    similarity[(col1, col2)] = corr
            except Exception:
                continue
    
    return similarity


def detect_high_similarity_pairs(
    similarity: Dict[Tuple[str, str], float],
    threshold: float = 0.90,
) -> List[SimilarityResult]:
    """Flag pairs above threshold as HIGH_SIMILARITY."""
    results = []
    
    for (col1, col2), corr in similarity.items():
        if abs(corr) >= threshold:
            results.append(SimilarityResult(
                pair=(col1, col2),
                window='full',
                correlation=round(corr, 4),
                distance=round(1 - abs(corr), 4),
                flags=['HIGH_SIMILARITY']
            ))
    
    results.sort(key=lambda x: abs(x.correlation), reverse=True)
    return results


def detect_clusters_kmeans(
    panel: pd.DataFrame,
    n_clusters: int = 4,
    random_state: int = 42,
) -> List[ClusterResult]:
    """Use KMeans to cluster indicators. Falls back to correlation if sklearn unavailable."""
    try:
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler
    except ImportError:
        return detect_clusters_correlation(panel)
    
    returns = panel.pct_change().dropna()
    if returns.shape[0] < 30 or returns.shape[1] < n_clusters:
        return detect_clusters_correlation(panel)
    
    X = returns.T.values
    X = np.nan_to_num(X, nan=0.0)
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    actual_n_clusters = min(n_clusters, X_scaled.shape[0])
    kmeans = KMeans(n_clusters=actual_n_clusters, random_state=random_state, n_init=10)
    labels = kmeans.fit_predict(X_scaled)
    
    columns = list(panel.columns)
    cluster_members = defaultdict(list)
    
    for col, label in zip(columns, labels):
        cluster_members[label].append(col)
    
    return [
        ClusterResult(cluster_id=cid, members=members, method='kmeans')
        for cid, members in cluster_members.items()
    ]


def detect_clusters_correlation(
    panel: pd.DataFrame,
    threshold: float = 0.70,
) -> List[ClusterResult]:
    """Cluster indicators based on correlation similarity."""
    columns = list(panel.columns)
    if len(columns) < 2:
        return []
    
    corr_matrix = panel.corr(method='pearson')
    visited = set()
    clusters = []
    cluster_id = 0
    
    for col in columns:
        if col in visited:
            continue
        
        cluster = []
        queue = [col]
        
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            
            visited.add(current)
            cluster.append(current)
            
            for other in columns:
                if other not in visited:
                    corr = corr_matrix.loc[current, other]
                    if not np.isnan(corr) and abs(corr) >= threshold:
                        queue.append(other)
        
        if len(cluster) >= 2:
            clusters.append(ClusterResult(
                cluster_id=cluster_id,
                members=cluster,
                method='correlation_threshold'
            ))
            cluster_id += 1
    
    return clusters


def detect_family_divergences(
    panel: pd.DataFrame,
    family_manager: Any,
    divergence_threshold: float = 0.70,
    window_days: int = 756
) -> Tuple[List[FamilyDivergence], List[str]]:
    """Detect divergences within indicator families."""
    divergences = []
    warnings_list = []
    
    if family_manager is None:
        return divergences, warnings_list
    
    try:
        families = family_manager.families
    except AttributeError:
        return divergences, warnings_list
    
    panel_cols = set(panel.columns)
    
    for family_id, family in families.items():
        try:
            members_in_panel = [m for m in family.members if m in panel_cols]
        except AttributeError:
            continue
        
        if len(members_in_panel) < 2:
            continue
        
        warnings_list.append(
            f"Family '{family_id}': members {members_in_panel} present in panel. "
            f"May overweight signal unless handled explicitly."
        )
        
        for i, m1 in enumerate(members_in_panel):
            for m2 in members_in_panel[i+1:]:
                mask = panel[m1].notna() & panel[m2].notna()
                if mask.sum() < 100:
                    continue
                
                recent_mask = mask & (mask.cumsum() > mask.sum() - window_days)
                if recent_mask.sum() > 50:
                    recent_corr = panel.loc[recent_mask, m1].corr(panel.loc[recent_mask, m2])
                    
                    if recent_corr < divergence_threshold:
                        severity = 'high' if recent_corr < 0.4 else 'medium'
                        divergences.append(FamilyDivergence(
                            family_id=family_id,
                            member_1=m1,
                            member_2=m2,
                            correlation=round(recent_corr, 4),
                            window=f'{window_days}d',
                            severity=severity
                        ))
                        warnings_list.append(
                            f"DIVERGENCE in family '{family_id}': {m1} vs {m2} "
                            f"corr={recent_corr:.2f} (last {window_days} days)."
                        )
    
    return divergences, warnings_list


def build_hvd_report(
    panel: pd.DataFrame,
    family_manager: Any = None,
    similarity_threshold: float = 0.90,
    cluster_method: str = 'auto',
    n_clusters: int = 4,
    min_overlap: int = 252
) -> HVDReport:
    """
    Build complete Hidden Variation Detector report.
    
    Main orchestrator:
    1. Compute similarity matrix
    2. Detect high-similarity pairs
    3. Cluster indicators
    4. Detect family divergences (if family_manager provided)
    5. Generate warnings
    """
    indicators = list(panel.columns)
    warnings_list = []
    
    # Safety checks
    if panel.empty:
        return HVDReport(
            indicators=[], similarity_results=[], clusters=[],
            family_divergences=[], warnings=["Panel is empty"],
            meta={'status': 'empty_panel'}
        )
    
    if len(indicators) < 2:
        return HVDReport(
            indicators=indicators, similarity_results=[], clusters=[],
            family_divergences=[], warnings=["Need at least 2 indicators"],
            meta={'status': 'insufficient_indicators'}
        )
    
    # Step 1: Similarity
    similarity = compute_similarity_matrix(panel, min_overlap=min(min_overlap, len(panel) // 2))
    
    # Step 2: High-similarity pairs
    high_sim = detect_high_similarity_pairs(similarity, threshold=similarity_threshold)
    if high_sim:
        warnings_list.append(f"Found {len(high_sim)} high-similarity pair(s) (corr >= {similarity_threshold})")
    
    # Step 3: Clustering
    if cluster_method == 'kmeans':
        clusters = detect_clusters_kmeans(panel, n_clusters=n_clusters)
    elif cluster_method == 'correlation':
        clusters = detect_clusters_correlation(panel)
    else:
        clusters = detect_clusters_kmeans(panel, n_clusters=n_clusters)
        if not clusters:
            clusters = detect_clusters_correlation(panel)
    
    # Step 4: Family divergences
    family_divergences, family_warnings = detect_family_divergences(panel, family_manager)
    warnings_list.extend(family_warnings)
    
    return HVDReport(
        indicators=indicators,
        similarity_results=high_sim,
        clusters=clusters,
        family_divergences=family_divergences,
        warnings=warnings_list,
        meta={'status': 'completed', 'panel_shape': panel.shape}
    )


def print_hvd_summary(report: HVDReport, max_warnings: int = 10, max_pairs: int = 5):
    """Print formatted HVD summary."""
    print("\n" + "=" * 60)
    print("HIDDEN VARIATION DETECTOR SUMMARY")
    print("=" * 60)
    
    summary = report.summary()
    print(f"\nIndicators analyzed: {summary['total_indicators']}")
    print(f"High-similarity pairs: {summary['high_similarity_count']}")
    print(f"Clusters found: {summary['cluster_count']}")
    
    if report.warnings:
        print(f"\n⚠️  Warnings ({min(len(report.warnings), max_warnings)}):")
        for w in report.warnings[:max_warnings]:
            print(f"   • {w}")
    
    high_sim = report.high_similarity_pairs
    if high_sim:
        print(f"\n🔴 High-Similarity Pairs (top {min(len(high_sim), max_pairs)}):")
        for r in high_sim[:max_pairs]:
            print(f"   {r.pair[0]} ~ {r.pair[1]}: corr={r.correlation:.3f}")
    
    print("=" * 60)
```

---

## Step 3: Integration Points

### 3.1 Panel Runtime Loader Integration

In `panel/runtime_loader.py`, add optional HVD:

```python
from analysis.hidden_variation_detector import build_hvd_report

def load_runtime_panel(..., enable_hvd: bool = True) -> dict:
    """Load panel with optional HVD analysis."""
    # ... existing panel loading ...
    
    result = {
        "panel": panel,
        # existing fields...
    }
    
    if enable_hvd:
        try:
            from data.family_manager import FamilyManager
            fm = FamilyManager()
        except Exception:
            fm = None
        
        hvd_report = build_hvd_report(panel, family_manager=fm)
        result["hvd_report"] = hvd_report
    else:
        result["hvd_report"] = None
    
    return result
```

### 3.2 Test Panel Script Integration

In `start/run_test_panel.py`:

```python
from analysis.hidden_variation_detector import build_hvd_report, print_hvd_summary

# After panel is built:
try:
    from data.family_manager import FamilyManager
    fm = FamilyManager()
except Exception:
    fm = None

hvd = build_hvd_report(panel, family_manager=fm)
print_hvd_summary(hvd)
```

---

## Step 4: Create Tests

Create `tests/test_hidden_variation_detector.py` with the test file provided.

---

## Verification

Run the module standalone:

```bash
python analysis/hidden_variation_detector.py
```

Expected output:
```
Hidden Variation Detector - Standalone Test
============================================================

Test panel: 500 rows, 9 columns

============================================================
HIDDEN VARIATION DETECTOR SUMMARY
============================================================

Indicators analyzed: 9
High-similarity pairs: 7
Clusters found: 4

⚠️  Warnings (1):
   • Found 7 high-similarity pair(s) (corr >= 0.85)

🔴 High-Similarity Pairs (top 5):
   trend_b ~ diverge_b: corr=0.999
   trend_a ~ trend_b: corr=0.999
   ...

✅ trend_a ~ trend_b correctly flagged as high-similarity
✅ random_a ~ random_b correctly NOT flagged
✅ Multiple clusters detected (4)
```

Run tests:

```bash
python tests/test_hidden_variation_detector.py
```

Expected output:
```
RESULTS: 9/9 passed, 0 failed
```

---

## Acceptance Criteria

| Criteria | Status |
|----------|--------|
| `analysis/hidden_variation_detector.py` exists and imports cleanly | ✅ |
| `build_hvd_report()` returns HVDReport | ✅ |
| High-correlation pairs (>0.90) flagged | ✅ |
| Clustering works (KMeans or correlation) | ✅ |
| Family divergence detection works | ✅ |
| Graceful degradation (empty panel, few indicators) | ✅ |
| No changes to geometry/weights | ✅ |
| All tests pass | ✅ |

---

## Non-Goals / Guardrails

- ❌ No changes to existing geometry code, weights, or MRF logic
- ❌ No DB writes from HVD module
- ❌ No heavy DL dependencies (PyTorch, TensorFlow)
- ✅ Everything is read-only advisory insight
- ✅ Safe to call from test / HTML / runners without breaking anything

---

## How HVD Complements Family Manager

| Component | Purpose |
|-----------|---------|
| **Family Manager** | **Prevention** - Blocks known duplicates based on registry |
| **HVD** | **Detection** - Discovers unknown duplicates via correlation |

They work together:
1. Family Manager defines known relationships (sp500_d ↔ sp500_m)
2. HVD discovers unknown high correlations
3. HVD warns when family members present
4. HVD detects when family members diverge unexpectedly

---

## Branch Instructions

```bash
git checkout main
git pull origin main
git checkout -b claude/add-hidden-variation-detector

# Add files
mkdir -p analysis tests
cp hidden_variation_detector.py analysis/
cp test_hidden_variation_detector.py tests/
touch analysis/__init__.py

# Test
python analysis/hidden_variation_detector.py
python tests/test_hidden_variation_detector.py

# Commit
git add .
git commit -m "Add Hidden Variation Detector (HVD) - advisory only

- Detects high-similarity indicator pairs
- Clusters indicators by correlation/KMeans
- Flags family divergences
- No changes to geometry math
- Read-only advisory output"

git push -u origin claude/add-hidden-variation-detector
```
