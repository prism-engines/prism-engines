# PRISM Schema v2.1 — Summary for Implementation

## Overview

This is a consolidated schema that merges the existing `schema.sql` with the calibration/analysis tables from `sql_schema_extension.py`, plus two new columns.

## Key Decisions

### 1. Keep `indicators.name` (NOT `indicator_name`)
The Languard proposal suggested renaming to `indicator_name`. We rejected this because:
- Current FK relationship is clean: `indicators.name` → `indicator_values.indicator_name`
- The `indicator_` prefix in `indicator_values` already disambiguates
- Changing would break all existing code with no real benefit

### 2. Add `fred_code` and `category` to `indicators`
**New columns:**
```sql
fred_code TEXT UNIQUE    -- FRED API series ID (e.g., 'FEDFUNDS', 'M2SL')
category  TEXT           -- Grouping: 'Growth', 'Liquidity', 'Sentiment', 'Volatility'
```
Benefits:
- Direct FRED mapping without JSON parsing
- Fast grouping queries for lens analysis

### 3. Keep `timeseries` as a VIEW
The Languard proposal made this a full table. We kept it as a VIEW because:
- Single source of truth remains `indicator_values`
- No data duplication or sync issues
- Backward compatibility for old code paths

### 4. Merge calibration/analysis tables into main schema
Previously split between `schema.sql` and `sql_schema_extension.py`. Now unified:
- `calibration_lenses`
- `calibration_indicators`
- `calibration_config`
- `analysis_rankings`
- `analysis_signals`
- `consensus_events`
- `consensus_history`

### 5. Add `system_name` to `systems`
Human-readable names for system codes:
```sql
system_name TEXT DEFAULT ''  -- e.g., 'Financial Markets' for 'finance'
```

---

## Files Provided

| File | Purpose |
|------|---------|
| `prism_schema_v2.1.sql` | Complete canonical schema for new databases |
| `003_v2.1_migration.sql` | Raw SQL migration (put in `data/sql/migrations/`) |
| `migrate_to_v2.1.py` | Safe Python migration runner with validation |

---

## Migration Usage

### Option A: Python script (recommended)
```bash
# Dry run first
python migrate_to_v2.1.py --dry-run

# Apply migration
python migrate_to_v2.1.py --db /path/to/prism.db
```

### Option B: Raw SQL
```bash
sqlite3 prism.db < 003_v2.1_migration.sql
```

---

## Post-Migration Cleanup

After migration, you can remove `sql_schema_extension.py` or refactor it to just contain the `PrismDB` class (no schema creation).

The `ensure_schema()` function in that file can be simplified to just verify tables exist rather than create them.

---

## Validation Checklist

After migration, verify:
- [ ] `indicators` table has `fred_code` and `category` columns
- [ ] `systems` table has `system_name` column
- [ ] All 6 calibration/analysis tables exist
- [ ] `timeseries` is a VIEW (not a table)
- [ ] `metadata.schema_version` = '2.1'

---

## What I Rejected from Languard

| Languard Proposal | Status | Reason |
|-------------------|--------|--------|
| Rename `name` → `indicator_name` | ❌ Rejected | Unnecessary churn, no benefit |
| `timeseries` as TABLE | ❌ Rejected | Violates single-source-of-truth |
| Everything else | ✅ Accepted | Good additions |
