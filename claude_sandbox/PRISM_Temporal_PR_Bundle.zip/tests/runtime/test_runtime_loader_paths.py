from panel.runtime_loader import resolve_path

def test_resolve_path_returns_full_path():
    p = resolve_path("engine/orchestration/temporal_analysis.py")
    assert p.exists()
