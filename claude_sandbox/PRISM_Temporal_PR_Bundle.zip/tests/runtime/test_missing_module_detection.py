import pytest
from panel.runtime_loader import validate_manifest

def test_missing_module_detection():
    bad_manifest = { "modules": { "bad": "not/real.py" } }
    with pytest.raises(FileNotFoundError):
        validate_manifest(bad_manifest)
