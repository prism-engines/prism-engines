import json
from pathlib import Path

def test_manifest_loads():
    manifest = json.loads(Path("MANIFEST.json").read_text())
    assert "modules" in manifest
    assert manifest["metadata"]["domain_agnostic"]
