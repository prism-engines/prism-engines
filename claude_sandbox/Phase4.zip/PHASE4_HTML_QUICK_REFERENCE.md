# PRISM Phase 4 (HTML Output) - Quick Reference

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
pip install jinja2 --break-system-packages
```

---

## Files to Create (6 templates + 1 Python + 1 test)

```
templates/
├── base.html                    # Base template with CSS
└── reports/
    ├── base_report.html         # Report base (extends base.html)
    ├── regime_comparison.html   # Regime comparison report
    ├── lens_validation.html     # Lens validation report
    └── generic.html             # Fallback for other workflows

runner/
└── report_generator.py          # NEW: Jinja2 rendering

test_phase4_html.py              # Verification script
```

**Files to Update:**
- `runner/__init__.py` - Add ReportGenerator exports
- `runner/output_manager.py` - Add generate_html_report() method
- `runner/cli_runner.py` - Update _save_results() to generate HTML

---

## Verification Commands

```bash
# Test 1: Verify Jinja2
python -c "import jinja2; print(f'Jinja2 {jinja2.__version__}')"
# Expected: Jinja2 3.x.x

# Test 2: List templates
python -c "from runner.report_generator import ReportGenerator; print(ReportGenerator().list_templates())"
# Expected: {'base_report': ..., 'regime_comparison': ..., ...}

# Test 3: Generate test report
python -c "
from runner.report_generator import generate_report
path = generate_report({'panel': 'market', 'workflow': 'test', 'status': 'completed'})
print(f'Report: {path}')
"
# Expected: Report: output/report_test_TIMESTAMP.html

# Test 4: Full verification
python test_phase4_html.py
# Expected: ALL 7 TESTS PASSED

# Test 5: CLI generates HTML
python prism_run.py --panel market --workflow regime_comparison
ls output/*/report.html
# Expected: HTML report in output directory
```

---

## Commit Message

```
Phase 4: Add HTML output system with Jinja2

- Add templates/base.html with CSS styling
- Add templates/reports/ with workflow-specific templates
- Add runner/report_generator.py Jinja2 rendering
- Update output_manager.py with HTML generation
- Update cli_runner.py to generate HTML reports

Templates: base, regime_comparison, lens_validation, generic
Reports auto-generated to output/ directory
```

---

## Success Criteria

✅ `import jinja2` works  
✅ templates/base.html exists with CSS  
✅ templates/reports/*.html exist (4 templates)  
✅ `from runner.report_generator import ReportGenerator` works  
✅ `ReportGenerator().generate(results)` creates HTML file  
✅ HTML contains styled content with headers, tables, progress bars  
✅ test_phase4_html.py passes all 7 tests

---

## Template Structure

```
base.html
    └── reports/base_report.html (extends base.html)
            ├── regime_comparison.html (extends base_report)
            ├── lens_validation.html (extends base_report)
            └── generic.html (extends base_report)
```

---

## Report Features

| Feature | Description |
|---------|-------------|
| Header | Gradient banner with title, subtitle, metadata |
| Stats Cards | 4-column grid with key metrics |
| Progress Bars | Visual similarity scores |
| Tables | Styled with hover effects |
| Badges | Status indicators (success/warning/danger) |
| Responsive | Mobile-friendly layout |
| Footer | Generation timestamp, panel/workflow info |

---

## Phase 5 Preview

Phase 5 (HTML Runner UI) will:
- Add Flask web server
- Create interactive form UI
- Live workflow selection dropdowns
- Run button triggers backend execution
- Display report in browser
