# PRISM Phase 4: HTML Output System
## Claude Code Implementation Instructions

**TARGET BRANCH: main**
**DO NOT CREATE A NEW BRANCH - Work directly on main**
**PREREQUISITE: Phases 1-3 must be complete (engines/, workflows/, panels/, runner/ exist)**

---

## Overview

Phase 4 adds Jinja2 template-based HTML report generation. Analysis results will be rendered as professional, styled HTML reports.

**Current State:**
- CLI runner outputs plain text to console
- Results saved as JSON and text files
- No HTML report generation

**Target State:**
- `templates/reports/` directory with Jinja2 templates
- `runner/report_generator.py` renders results to HTML
- Professional styled reports with charts placeholder
- Reports auto-saved to output directory

**Goals:**
1. Add Jinja2 dependency
2. Create base template with CSS styling
3. Create workflow-specific report templates
4. Create ReportGenerator class
5. Integrate with executor to auto-generate HTML
6. Test end-to-end HTML report generation

**Success Criteria:**
- `python prism_run.py --panel market --workflow regime_comparison` generates HTML report
- Report opens in browser with professional styling
- Templates are modular and extensible

---

## Architecture

```
templates/
├── base.html                    # Base template with CSS/layout
└── reports/
    ├── base_report.html         # Report base (extends base.html)
    ├── regime_comparison.html   # Regime comparison report
    ├── temporal_analysis.html   # Temporal analysis report
    ├── lens_validation.html     # Lens validation report
    ├── daily_update.html        # Daily update report
    └── generic.html             # Fallback for other workflows

runner/
├── report_generator.py          # NEW: Jinja2 report rendering
└── output_manager.py            # UPDATED: HTML generation
```

---

## Step 1: Verify Jinja2 is Available

```bash
pip install jinja2 --break-system-packages
python -c "import jinja2; print(f'Jinja2 {jinja2.__version__} OK')"
```

---

## Step 2: Create templates/base.html

**File:** `templates/base.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}PRISM Report{% endblock %}</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            line-height: 1.6;
            color: var(--gray-800);
            background: var(--gray-50);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 2rem;
            margin-bottom: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .header .subtitle {
            opacity: 0.9;
            font-size: 1.1rem;
        }
        
        .header .meta {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--gray-200);
        }
        
        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--gray-200);
        }
        
        .card-header h2 {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        
        .card-header .icon {
            font-size: 1.5rem;
            margin-right: 0.75rem;
        }
        
        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }
        
        th, td {
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--gray-200);
        }
        
        th {
            background: var(--gray-100);
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        tr:hover {
            background: var(--gray-50);
        }
        
        /* Progress bars */
        .progress-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .progress-bar {
            flex: 1;
            height: 24px;
            background: var(--gray-200);
            border-radius: 12px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary) 0%, var(--success) 100%);
            border-radius: 12px;
            transition: width 0.3s ease;
        }
        
        .progress-value {
            min-width: 60px;
            font-weight: 600;
            color: var(--gray-700);
        }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .badge-success {
            background: #dcfce7;
            color: #166534;
        }
        
        .badge-warning {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-danger {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .badge-info {
            background: #dbeafe;
            color: #1e40af;
        }
        
        /* Grid */
        .grid {
            display: grid;
            gap: 1.5rem;
        }
        
        .grid-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .grid-3 {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .grid-4 {
            grid-template-columns: repeat(4, 1fr);
        }
        
        @media (max-width: 768px) {
            .grid-2, .grid-3, .grid-4 {
                grid-template-columns: 1fr;
            }
        }
        
        /* Stats */
        .stat-card {
            text-align: center;
            padding: 1.5rem;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .stat-label {
            color: var(--gray-600);
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        /* Lists */
        .list-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--gray-100);
        }
        
        .list-item:last-child {
            border-bottom: none;
        }
        
        .list-item .bullet {
            width: 8px;
            height: 8px;
            background: var(--primary);
            border-radius: 50%;
            margin-right: 1rem;
        }
        
        /* Footer */
        .footer {
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 1px solid var(--gray-200);
            text-align: center;
            color: var(--gray-600);
            font-size: 0.875rem;
        }
        
        /* Utility */
        .text-success { color: var(--success); }
        .text-warning { color: var(--warning); }
        .text-danger { color: var(--danger); }
        .text-muted { color: var(--gray-600); }
        .font-mono { font-family: 'Monaco', 'Menlo', monospace; }
        .mt-1 { margin-top: 0.5rem; }
        .mt-2 { margin-top: 1rem; }
        .mb-1 { margin-bottom: 0.5rem; }
        .mb-2 { margin-bottom: 1rem; }
    </style>
    {% block extra_css %}{% endblock %}
</head>
<body>
    <div class="container">
        {% block content %}{% endblock %}
        
        <div class="footer">
            <p>Generated by PRISM Engine • {{ timestamp | default('') }}</p>
            <p class="mt-1">Panel: {{ panel | default('N/A') }} • Workflow: {{ workflow | default('N/A') }}</p>
        </div>
    </div>
    
    {% block extra_js %}{% endblock %}
</body>
</html>
```

---

## Step 3: Create templates/reports/base_report.html

**File:** `templates/reports/base_report.html`

```html
{% extends "base.html" %}

{% block content %}
<div class="header">
    <h1>{% block report_title %}PRISM Analysis Report{% endblock %}</h1>
    <div class="subtitle">{% block report_subtitle %}{% endblock %}</div>
    <div class="meta">
        <span>📅 {{ timestamp | default('N/A') }}</span>
        <span style="margin: 0 1rem;">•</span>
        <span>⏱️ Duration: {{ duration | default(0) | round(2) }}s</span>
        <span style="margin: 0 1rem;">•</span>
        <span>📊 {{ indicators_analyzed | default(0) }} indicators</span>
    </div>
</div>

<!-- Summary Stats -->
<div class="grid grid-4 mb-2">
    {% block summary_stats %}
    <div class="card stat-card">
        <div class="stat-value">{{ indicators_analyzed | default(0) }}</div>
        <div class="stat-label">Indicators</div>
    </div>
    <div class="card stat-card">
        <div class="stat-value">{{ lenses_run | length if lenses_run is iterable else lenses_run | default(0) }}</div>
        <div class="stat-label">Lenses Run</div>
    </div>
    <div class="card stat-card">
        <div class="stat-value">{{ duration | default(0) | round(1) }}s</div>
        <div class="stat-label">Duration</div>
    </div>
    <div class="card stat-card">
        <div class="stat-value">
            {% if status == 'completed' %}
            <span class="text-success">✓</span>
            {% else %}
            <span class="text-danger">✗</span>
            {% endif %}
        </div>
        <div class="stat-label">Status</div>
    </div>
    {% endblock %}
</div>

{% block report_content %}{% endblock %}

<!-- Configuration -->
<div class="card">
    <div class="card-header">
        <span class="icon">⚙️</span>
        <h2>Configuration</h2>
    </div>
    <table>
        <tr>
            <th>Parameter</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Panel</td>
            <td><span class="badge badge-info">{{ panel | default('N/A') }}</span></td>
        </tr>
        <tr>
            <td>Workflow</td>
            <td><span class="badge badge-info">{{ workflow | default('N/A') }}</span></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>
                {% if status == 'completed' %}
                <span class="badge badge-success">Completed</span>
                {% elif status == 'failed' %}
                <span class="badge badge-danger">Failed</span>
                {% else %}
                <span class="badge badge-warning">{{ status | default('Unknown') }}</span>
                {% endif %}
            </td>
        </tr>
        {% if parameters %}
        <tr>
            <td>Parameters</td>
            <td class="font-mono">{{ parameters | tojson }}</td>
        </tr>
        {% endif %}
    </table>
</div>

{% if lenses_run and lenses_run is iterable %}
<div class="card">
    <div class="card-header">
        <span class="icon">🔍</span>
        <h2>Lenses Executed</h2>
    </div>
    <div class="grid grid-4">
        {% for lens in lenses_run %}
        <div class="list-item">
            <span class="bullet"></span>
            <span>{{ lens }}</span>
        </div>
        {% endfor %}
    </div>
</div>
{% endif %}

{% endblock %}
```

---

## Step 4: Create templates/reports/regime_comparison.html

**File:** `templates/reports/regime_comparison.html`

```html
{% extends "reports/base_report.html" %}

{% block report_title %}Regime Comparison Analysis{% endblock %}
{% block report_subtitle %}Historical regime similarity analysis for {{ panel | default('market') | title }} panel{% endblock %}

{% block report_content %}

<!-- Closest Match Highlight -->
{% if closest_match %}
<div class="card" style="background: linear-gradient(135deg, #dbeafe 0%, #ede9fe 100%); border: 2px solid var(--primary);">
    <div class="card-header" style="border-bottom-color: rgba(37, 99, 235, 0.2);">
        <span class="icon">🎯</span>
        <h2>Closest Historical Match</h2>
    </div>
    <div style="text-align: center; padding: 1rem;">
        <div style="font-size: 3rem; font-weight: 700; color: var(--primary);">{{ closest_match }}</div>
        <div class="text-muted mt-1">Current market conditions most closely resemble this period</div>
    </div>
</div>
{% endif %}

<!-- Similarity Scores -->
{% if similarities %}
<div class="card">
    <div class="card-header">
        <span class="icon">📊</span>
        <h2>Regime Similarity Scores</h2>
    </div>
    <p class="text-muted mb-2">How closely current conditions match historical regimes:</p>
    
    <table>
        <thead>
            <tr>
                <th>Period</th>
                <th>Similarity</th>
                <th style="width: 50%;">Visual</th>
            </tr>
        </thead>
        <tbody>
            {% for period, score in similarities.items() | sort(attribute='1', reverse=true) %}
            <tr>
                <td>
                    <strong>{{ period }}</strong>
                    {% if period == closest_match %}
                    <span class="badge badge-success" style="margin-left: 0.5rem;">Best Match</span>
                    {% endif %}
                </td>
                <td class="font-mono">{{ (score * 100) | round(1) }}%</td>
                <td>
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ (score * 100) | round }}%;"></div>
                        </div>
                    </div>
                </td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
{% endif %}

<!-- Comparison Periods -->
{% if comparison_periods %}
<div class="card">
    <div class="card-header">
        <span class="icon">📅</span>
        <h2>Comparison Periods</h2>
    </div>
    <div class="grid grid-{{ comparison_periods | length if comparison_periods | length <= 4 else 4 }}">
        {% for period in comparison_periods %}
        <div class="stat-card" style="background: var(--gray-50); border-radius: 8px;">
            <div style="font-size: 1.5rem; font-weight: 600;">{{ period }}</div>
            <div class="text-muted" style="font-size: 0.875rem;">Historical Period</div>
        </div>
        {% endfor %}
    </div>
</div>
{% endif %}

{% endblock %}
```

---

## Step 5: Create templates/reports/lens_validation.html

**File:** `templates/reports/lens_validation.html`

```html
{% extends "reports/base_report.html" %}

{% block report_title %}Lens Validation Report{% endblock %}
{% block report_subtitle %}Engine validation results for PRISM analysis system{% endblock %}

{% block summary_stats %}
<div class="card stat-card">
    <div class="stat-value">{{ engines_validated | default(0) }}</div>
    <div class="stat-label">Engines Tested</div>
</div>
<div class="card stat-card">
    <div class="stat-value text-success">{{ engines_valid | default(0) }}</div>
    <div class="stat-label">Valid</div>
</div>
<div class="card stat-card">
    <div class="stat-value text-danger">{{ (engines_validated | default(0)) - (engines_valid | default(0)) }}</div>
    <div class="stat-label">Invalid</div>
</div>
<div class="card stat-card">
    <div class="stat-value">{{ ((engines_valid | default(0)) / (engines_validated | default(1)) * 100) | round }}%</div>
    <div class="stat-label">Pass Rate</div>
</div>
{% endblock %}

{% block report_content %}

<!-- Validation Results -->
{% if validation_details %}
<div class="card">
    <div class="card-header">
        <span class="icon">🔍</span>
        <h2>Validation Details</h2>
    </div>
    <table>
        <thead>
            <tr>
                <th>Engine</th>
                <th>Status</th>
                <th>Loadable</th>
                <th>Has Analyze</th>
                <th>Has Rank</th>
                <th>Errors</th>
            </tr>
        </thead>
        <tbody>
            {% for engine, details in validation_details.items() | sort %}
            <tr>
                <td><strong>{{ engine }}</strong></td>
                <td>
                    {% if details.valid %}
                    <span class="badge badge-success">✓ Valid</span>
                    {% else %}
                    <span class="badge badge-danger">✗ Invalid</span>
                    {% endif %}
                </td>
                <td>
                    {% if details.loadable %}
                    <span class="text-success">✓</span>
                    {% else %}
                    <span class="text-danger">✗</span>
                    {% endif %}
                </td>
                <td>
                    {% if details.has_analyze %}
                    <span class="text-success">✓</span>
                    {% else %}
                    <span class="text-muted">-</span>
                    {% endif %}
                </td>
                <td>
                    {% if details.has_rank_indicators %}
                    <span class="text-success">✓</span>
                    {% else %}
                    <span class="text-muted">-</span>
                    {% endif %}
                </td>
                <td>
                    {% if details.errors %}
                    <span class="text-danger font-mono" style="font-size: 0.75rem;">
                        {{ details.errors[0][:50] }}{% if details.errors[0] | length > 50 %}...{% endif %}
                    </span>
                    {% else %}
                    <span class="text-muted">None</span>
                    {% endif %}
                </td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
{% endif %}

{% endblock %}
```

---

## Step 6: Create templates/reports/generic.html

**File:** `templates/reports/generic.html`

```html
{% extends "reports/base_report.html" %}

{% block report_title %}{{ workflow_type | default(workflow) | replace('_', ' ') | title }} Report{% endblock %}
{% block report_subtitle %}Analysis results for {{ panel | default('') | title }} panel{% endblock %}

{% block report_content %}

<!-- Raw Results -->
<div class="card">
    <div class="card-header">
        <span class="icon">📋</span>
        <h2>Analysis Results</h2>
    </div>
    
    {% if workflow_type %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Workflow Type:</strong> {{ workflow_type }}</span>
    </div>
    {% endif %}
    
    {% if note %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Note:</strong> {{ note }}</span>
    </div>
    {% endif %}
    
    {% if time_periods_analyzed %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Time Periods:</strong> {{ time_periods_analyzed }}</span>
    </div>
    {% endif %}
    
    {% if resolution %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Resolution:</strong> {{ resolution }}</span>
    </div>
    {% endif %}
    
    {% if update_date %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Update Date:</strong> {{ update_date }}</span>
    </div>
    {% endif %}
    
    {% if indicators_updated %}
    <div class="list-item">
        <span class="bullet"></span>
        <span><strong>Indicators Updated:</strong> {{ indicators_updated }}</span>
    </div>
    {% endif %}
</div>

{% endblock %}
```

---

## Step 7: Create runner/report_generator.py

**File:** `runner/report_generator.py`

```python
"""
PRISM Report Generator
=======================

Generates HTML reports from analysis results using Jinja2 templates.
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import webbrowser

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    JINJA2_AVAILABLE = True
except ImportError:
    JINJA2_AVAILABLE = False

logger = logging.getLogger(__name__)

# Template directory
TEMPLATES_DIR = Path(__file__).parent.parent / "templates"


class ReportGenerator:
    """Generates HTML reports using Jinja2 templates."""
    
    # Map workflow types to templates
    TEMPLATE_MAP = {
        "regime_comparison": "reports/regime_comparison.html",
        "lens_validation": "reports/lens_validation.html",
        "temporal_analysis": "reports/generic.html",
        "daily_update": "reports/generic.html",
        "default": "reports/generic.html",
    }
    
    def __init__(self, templates_dir: Optional[Path] = None):
        """
        Initialize the report generator.
        
        Args:
            templates_dir: Custom templates directory
        """
        if not JINJA2_AVAILABLE:
            raise ImportError(
                "Jinja2 is required for HTML reports. "
                "Install with: pip install jinja2"
            )
        
        self.templates_dir = templates_dir or TEMPLATES_DIR
        
        if not self.templates_dir.exists():
            raise FileNotFoundError(f"Templates directory not found: {self.templates_dir}")
        
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            autoescape=select_autoescape(['html', 'xml']),
        )
        
        # Add custom filters
        self.env.filters['round'] = lambda x, n=0: round(float(x), n) if x else 0
        
        logger.info(f"Report generator initialized with templates from: {self.templates_dir}")
    
    def get_template_for_workflow(self, workflow_type: str) -> str:
        """Get the template path for a workflow type."""
        return self.TEMPLATE_MAP.get(workflow_type, self.TEMPLATE_MAP["default"])
    
    def generate(
        self,
        results: Dict[str, Any],
        output_path: Optional[Path] = None,
        open_browser: bool = False
    ) -> Path:
        """
        Generate an HTML report from analysis results.
        
        Args:
            results: Analysis results dictionary
            output_path: Where to save the report (auto-generated if None)
            open_browser: Whether to open the report in browser
            
        Returns:
            Path to the generated report
        """
        # Determine workflow type
        workflow_type = results.get("workflow_type", results.get("workflow", "default"))
        template_name = self.get_template_for_workflow(workflow_type)
        
        logger.info(f"Generating report using template: {template_name}")
        
        # Load template
        try:
            template = self.env.get_template(template_name)
        except Exception as e:
            logger.warning(f"Template {template_name} not found, using generic")
            template = self.env.get_template("reports/generic.html")
        
        # Prepare context
        context = {
            **results,
            "generated_at": datetime.now().isoformat(),
        }
        
        # Render HTML
        html_content = template.render(**context)
        
        # Determine output path
        if output_path is None:
            output_dir = Path("output")
            output_dir.mkdir(exist_ok=True)
            timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
            output_path = output_dir / f"report_{workflow_type}_{timestamp}.html"
        
        # Write file
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Report generated: {output_path}")
        
        # Open in browser if requested
        if open_browser:
            self.open_report(output_path)
        
        return output_path
    
    def open_report(self, report_path: Path) -> None:
        """Open a report in the default browser."""
        try:
            webbrowser.open(f"file://{report_path.absolute()}")
            logger.info(f"Opened report in browser: {report_path}")
        except Exception as e:
            logger.warning(f"Could not open browser: {e}")
    
    def list_templates(self) -> Dict[str, str]:
        """List available report templates."""
        templates = {}
        reports_dir = self.templates_dir / "reports"
        
        if reports_dir.exists():
            for template_file in reports_dir.glob("*.html"):
                name = template_file.stem
                templates[name] = str(template_file.relative_to(self.templates_dir))
        
        return templates


def generate_report(
    results: Dict[str, Any],
    output_path: Optional[Path] = None,
    open_browser: bool = False
) -> Optional[Path]:
    """
    Convenience function to generate a report.
    
    Args:
        results: Analysis results
        output_path: Output file path
        open_browser: Open in browser after generation
        
    Returns:
        Path to report or None if Jinja2 not available
    """
    if not JINJA2_AVAILABLE:
        logger.warning("Jinja2 not available, skipping HTML report generation")
        return None
    
    try:
        generator = ReportGenerator()
        return generator.generate(results, output_path, open_browser)
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        return None
```

---

## Step 8: Update runner/output_manager.py

Add HTML report generation to the OutputManager class.

**Add to `runner/output_manager.py`** (add this method to the class):

```python
    def generate_html_report(
        self,
        results: Dict[str, Any],
        open_browser: bool = False
    ) -> Optional[Path]:
        """
        Generate an HTML report from results.
        
        Args:
            results: Analysis results dictionary
            open_browser: Whether to open in browser
            
        Returns:
            Path to generated report or None
        """
        try:
            from .report_generator import generate_report
            
            run_dir = self.get_run_directory()
            report_path = run_dir / "report.html"
            
            return generate_report(results, report_path, open_browser)
            
        except ImportError:
            logger.warning("Report generator not available")
            return None
        except Exception as e:
            logger.error(f"HTML report generation failed: {e}")
            return None
```

---

## Step 9: Update runner/cli_runner.py

Update the `_save_results` method to generate HTML reports.

**Find and update the `_save_results` method in `runner/cli_runner.py`:**

```python
    def _save_results(self, results: Dict[str, Any]) -> None:
        """Save results to files."""
        try:
            # Create run directory
            run_dir = self.output.create_run_directory(
                prefix=results.get("workflow", "run")
            )
            
            # Save JSON results
            json_path = self.output.save_json(results, "results.json")
            
            # Save summary text
            summary = self.output.format_summary(results)
            if results.get("workflow_type") == "regime_comparison":
                summary += "\n" + self.output.format_regime_comparison(results)
            self.output.save_text(summary, "summary.txt")
            
            # Generate HTML report
            html_path = self.output.generate_html_report(results, open_browser=False)
            
            print(f"\n📁 Results saved to: {run_dir}")
            if html_path:
                print(f"📄 HTML Report: {html_path}")
                
                # Ask if user wants to open report
                response = input("\nOpen report in browser? [y/N]: ").strip().lower()
                if response in ("y", "yes"):
                    import webbrowser
                    webbrowser.open(f"file://{html_path.absolute()}")
            
        except Exception as e:
            logger.error(f"Could not save results: {e}")
            print(f"\n⚠️ Could not save results: {e}")
```

---

## Step 10: Update runner/__init__.py

Add report generator exports.

**Update `runner/__init__.py`:**

```python
"""
PRISM Runner Package
"""

from .dispatcher import Dispatcher, DispatchError

# Import CLI components
try:
    from .cli_runner import CLIRunner, run_cli
    from .executor import WorkflowExecutor
    from .output_manager import OutputManager
    _CLI_AVAILABLE = True
except ImportError:
    _CLI_AVAILABLE = False
    CLIRunner = None
    run_cli = None
    WorkflowExecutor = None
    OutputManager = None

# Import report generator
try:
    from .report_generator import ReportGenerator, generate_report
    _REPORTS_AVAILABLE = True
except ImportError:
    _REPORTS_AVAILABLE = False
    ReportGenerator = None
    generate_report = None

__all__ = [
    "Dispatcher",
    "DispatchError",
]

if _CLI_AVAILABLE:
    __all__.extend([
        "CLIRunner",
        "run_cli",
        "WorkflowExecutor",
        "OutputManager",
    ])

if _REPORTS_AVAILABLE:
    __all__.extend([
        "ReportGenerator",
        "generate_report",
    ])
```

---

## Step 11: Create Test Script

**File:** `test_phase4_html.py`

```python
#!/usr/bin/env python3
"""
Phase 4 HTML Output System Verification
=========================================
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))


def test_jinja2_available():
    """Test Jinja2 is installed."""
    print("\n" + "=" * 50)
    print("TEST: Jinja2 Available")
    print("=" * 50)
    
    try:
        import jinja2
        print(f"✓ Jinja2 version: {jinja2.__version__}")
        return True
    except ImportError:
        print("❌ Jinja2 not installed")
        print("   Run: pip install jinja2")
        return False


def test_templates_exist():
    """Test template files exist."""
    print("\n" + "=" * 50)
    print("TEST: Templates Exist")
    print("=" * 50)
    
    templates_dir = PROJECT_ROOT / "templates"
    
    required = [
        "base.html",
        "reports/base_report.html",
        "reports/regime_comparison.html",
        "reports/lens_validation.html",
        "reports/generic.html",
    ]
    
    all_exist = True
    for template in required:
        path = templates_dir / template
        if path.exists():
            print(f"✓ {template}")
        else:
            print(f"❌ {template} MISSING")
            all_exist = False
    
    return all_exist


def test_report_generator_import():
    """Test report generator imports."""
    print("\n" + "=" * 50)
    print("TEST: Report Generator Import")
    print("=" * 50)
    
    try:
        from runner.report_generator import ReportGenerator, generate_report
        print("✓ ReportGenerator imported")
        print("✓ generate_report imported")
        return True
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False


def test_report_generator_init():
    """Test report generator initialization."""
    print("\n" + "=" * 50)
    print("TEST: Report Generator Initialization")
    print("=" * 50)
    
    try:
        from runner.report_generator import ReportGenerator
        
        generator = ReportGenerator()
        templates = generator.list_templates()
        
        print(f"✓ Generator initialized")
        print(f"✓ Found {len(templates)} templates: {list(templates.keys())}")
        
        return True
    except Exception as e:
        print(f"❌ Initialization failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_report_generation():
    """Test actual report generation."""
    print("\n" + "=" * 50)
    print("TEST: Report Generation")
    print("=" * 50)
    
    try:
        from runner.report_generator import ReportGenerator
        
        generator = ReportGenerator()
        
        # Test data
        results = {
            "panel": "market",
            "workflow": "regime_comparison",
            "workflow_type": "regime_comparison",
            "status": "completed",
            "timestamp": "2025-01-01T12:00:00",
            "duration": 1.5,
            "indicators_analyzed": 33,
            "lenses_run": ["pca", "clustering", "granger"],
            "similarities": {
                "2008": 0.72,
                "2020": 0.85,
                "2022": 0.61,
            },
            "closest_match": "2020",
            "comparison_periods": ["2008", "2020", "2022"],
        }
        
        # Generate report
        output_path = PROJECT_ROOT / "output" / "test_report.html"
        report_path = generator.generate(results, output_path)
        
        if report_path and report_path.exists():
            size = report_path.stat().st_size
            print(f"✓ Report generated: {report_path}")
            print(f"✓ File size: {size:,} bytes")
            
            # Check content
            content = report_path.read_text()
            checks = [
                ("<!DOCTYPE html>", "HTML doctype"),
                ("PRISM", "PRISM branding"),
                ("2020", "Closest match"),
                ("regime_comparison", "Workflow type"),
            ]
            
            for check, desc in checks:
                if check in content:
                    print(f"✓ Contains {desc}")
                else:
                    print(f"⚠ Missing {desc}")
            
            return True
        else:
            print("❌ Report not generated")
            return False
            
    except Exception as e:
        print(f"❌ Generation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_cli_generates_html():
    """Test CLI generates HTML report."""
    print("\n" + "=" * 50)
    print("TEST: CLI Generates HTML")
    print("=" * 50)
    
    try:
        from runner import WorkflowExecutor, OutputManager
        
        executor = WorkflowExecutor()
        output = OutputManager()
        
        # Run a workflow
        results = executor.execute("market", "lens_validation")
        
        # Generate HTML
        run_dir = output.create_run_directory(prefix="test_cli")
        html_path = output.generate_html_report(results)
        
        if html_path and html_path.exists():
            print(f"✓ CLI workflow generated HTML: {html_path}")
            return True
        else:
            print("❌ HTML not generated from CLI")
            return False
            
    except Exception as e:
        print(f"❌ CLI HTML test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_multiple_templates():
    """Test different workflow templates."""
    print("\n" + "=" * 50)
    print("TEST: Multiple Templates")
    print("=" * 50)
    
    try:
        from runner.report_generator import ReportGenerator
        
        generator = ReportGenerator()
        
        workflows = [
            ("regime_comparison", {"similarities": {"2020": 0.8}, "closest_match": "2020"}),
            ("lens_validation", {"engines_validated": 20, "engines_valid": 15, "validation_details": {}}),
            ("daily_update", {"update_date": "2025-01-01", "indicators_updated": 33}),
        ]
        
        all_ok = True
        for wf_type, extra_data in workflows:
            results = {
                "panel": "market",
                "workflow": wf_type,
                "workflow_type": wf_type,
                "status": "completed",
                "duration": 1.0,
                "indicators_analyzed": 33,
                **extra_data,
            }
            
            output_path = PROJECT_ROOT / "output" / f"test_{wf_type}.html"
            report_path = generator.generate(results, output_path)
            
            if report_path and report_path.exists():
                print(f"✓ {wf_type} template works")
            else:
                print(f"❌ {wf_type} template failed")
                all_ok = False
        
        return all_ok
        
    except Exception as e:
        print(f"❌ Multiple template test failed: {e}")
        return False


def main():
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║             PRISM PHASE 4 VERIFICATION                       ║
    ║                                                              ║
    ║  Testing: HTML Output System                                 ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    results = {
        "jinja2": test_jinja2_available(),
        "templates": test_templates_exist(),
        "import": test_report_generator_import(),
        "init": test_report_generator_init(),
        "generation": test_report_generation(),
        "cli_html": test_cli_generates_html(),
        "multi_template": test_multiple_templates(),
    }
    
    print("\n" + "=" * 50)
    print("SUMMARY")
    print("=" * 50)
    
    all_passed = True
    for test, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test}: {status}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 PHASE 4 (HTML OUTPUT) COMPLETE - ALL TESTS PASSED!")
    else:
        print("⚠️  PHASE 4 INCOMPLETE - SOME TESTS FAILED")
    print("=" * 50)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
```

---

## Step 12: Verification Commands

```bash
# Test 1: Verify Jinja2
python -c "import jinja2; print(f'Jinja2 {jinja2.__version__}')"

# Test 2: List templates
python -c "from runner.report_generator import ReportGenerator; print(ReportGenerator().list_templates())"

# Test 3: Generate test report
python -c "
from runner.report_generator import generate_report
results = {'panel': 'market', 'workflow': 'test', 'status': 'completed'}
path = generate_report(results)
print(f'Report: {path}')
"

# Test 4: Full verification
python test_phase4_html.py

# Test 5: CLI with HTML output
python prism_run.py --panel market --workflow regime_comparison
# Check output/ directory for report.html
```

---

## Step 13: Commit

```bash
git add templates/ runner/report_generator.py runner/__init__.py runner/output_manager.py runner/cli_runner.py test_phase4_html.py
git commit -m "Phase 4: Add HTML output system with Jinja2

- Add templates/base.html with CSS styling
- Add templates/reports/ with workflow-specific templates
- Add runner/report_generator.py Jinja2 rendering
- Update output_manager.py with HTML generation
- Update cli_runner.py to generate HTML reports

Templates: base, regime_comparison, lens_validation, generic
Reports auto-generated to output/ directory"
```

---

## Files Summary

```
templates/
├── base.html                    # Base template with CSS (~200 lines)
└── reports/
    ├── base_report.html         # Report base (~100 lines)
    ├── regime_comparison.html   # Regime report (~80 lines)
    ├── lens_validation.html     # Validation report (~80 lines)
    └── generic.html             # Fallback template (~50 lines)

runner/
├── report_generator.py          # NEW: Jinja2 rendering (~180 lines)
├── output_manager.py            # UPDATED: +generate_html_report
├── cli_runner.py                # UPDATED: HTML in _save_results
└── __init__.py                  # UPDATED: export ReportGenerator

test_phase4_html.py              # Verification script
```

---

## What This Enables

**Before Phase 4:**
```
output/
├── results.json
└── summary.txt
```

**After Phase 4:**
```
output/
├── results.json
├── summary.txt
└── report.html    ← Professional styled HTML report
```

The HTML report includes:
- Styled header with workflow info
- Summary statistics cards
- Similarity scores with progress bars
- Configuration details
- Responsive design
- Print-friendly layout
