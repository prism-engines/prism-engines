#!/usr/bin/env python3
"""
PRISM Schema Migration: v2.0 → v2.1
===================================

Safe migration script with:
- Pre-flight validation
- Column existence checks (SQLite ALTER TABLE limitations)
- Rollback on failure
- Progress reporting

Usage:
    python migrate_to_v2.1.py                    # Uses default DB path
    python migrate_to_v2.1.py --db /path/to.db  # Explicit DB path
    python migrate_to_v2.1.py --dry-run         # Show what would happen
"""

import sqlite3
import sys
import argparse
from pathlib import Path
from datetime import datetime


def get_default_db_path():
    """Get default DB path (mirrors data/sql/db_path.py logic)."""
    # Check common locations
    candidates = [
        Path.home() / ".prism" / "prism.db",
        Path.cwd() / "data" / "prism.db",
        Path.cwd() / "prism.db",
    ]
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]  # Default to ~/.prism/prism.db


def column_exists(conn, table, column):
    """Check if a column exists in a table."""
    cursor = conn.execute(f"PRAGMA table_info({table})")
    columns = [row[1] for row in cursor.fetchall()]
    return column in columns


def table_exists(conn, table):
    """Check if a table exists."""
    cursor = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table,)
    )
    return cursor.fetchone() is not None


def index_exists(conn, index_name):
    """Check if an index exists."""
    cursor = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index' AND name=?",
        (index_name,)
    )
    return cursor.fetchone() is not None


def migrate(db_path: Path, dry_run: bool = False):
    """Run the v2.0 → v2.1 migration."""
    
    print("=" * 60)
    print("PRISM Schema Migration: v2.0 → v2.1")
    print("=" * 60)
    print(f"\nDatabase: {db_path}")
    print(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}")
    print()
    
    if not db_path.exists():
        print(f"❌ Database not found: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    
    changes = []
    
    try:
        # =====================================================================
        # 1. INDICATORS TABLE UPDATES
        # =====================================================================
        print("1. Checking indicators table...")
        
        if not table_exists(conn, 'indicators'):
            print("   ❌ indicators table not found - is this a PRISM database?")
            return False
        
        # Add fred_code column
        if not column_exists(conn, 'indicators', 'fred_code'):
            changes.append(("ADD COLUMN", "indicators.fred_code"))
            if not dry_run:
                conn.execute("ALTER TABLE indicators ADD COLUMN fred_code TEXT")
                # Note: Can't add UNIQUE constraint via ALTER TABLE in SQLite
                print("   ✅ Added: indicators.fred_code")
        else:
            print("   ⏭️  Skipped: indicators.fred_code (already exists)")
        
        # Add category column
        if not column_exists(conn, 'indicators', 'category'):
            changes.append(("ADD COLUMN", "indicators.category"))
            if not dry_run:
                conn.execute("ALTER TABLE indicators ADD COLUMN category TEXT")
                print("   ✅ Added: indicators.category")
        else:
            print("   ⏭️  Skipped: indicators.category (already exists)")
        
        # Add indexes
        for idx_name, idx_sql in [
            ("idx_indicators_category", "CREATE INDEX IF NOT EXISTS idx_indicators_category ON indicators(category)"),
            ("idx_indicators_source", "CREATE INDEX IF NOT EXISTS idx_indicators_source ON indicators(source)"),
        ]:
            if not index_exists(conn, idx_name):
                changes.append(("CREATE INDEX", idx_name))
                if not dry_run:
                    conn.execute(idx_sql)
                    print(f"   ✅ Added: {idx_name}")
            else:
                print(f"   ⏭️  Skipped: {idx_name} (already exists)")
        
        # =====================================================================
        # 2. SYSTEMS TABLE UPDATE
        # =====================================================================
        print("\n2. Checking systems table...")
        
        if table_exists(conn, 'systems'):
            if not column_exists(conn, 'systems', 'system_name'):
                changes.append(("ADD COLUMN", "systems.system_name"))
                if not dry_run:
                    conn.execute("ALTER TABLE systems ADD COLUMN system_name TEXT DEFAULT ''")
                    # Update existing rows
                    system_names = {
                        'finance': 'Financial Markets',
                        'market': 'Market Data',
                        'economic': 'Economic Indicators',
                        'climate': 'Climate/Weather',
                        'biology': 'Biological Systems',
                        'chemistry': 'Chemical Systems',
                        'anthropology': 'Social/Demographic',
                        'physics': 'Physical Systems',
                    }
                    for sys, name in system_names.items():
                        conn.execute(
                            "UPDATE systems SET system_name = ? WHERE system = ? AND (system_name IS NULL OR system_name = '')",
                            (name, sys)
                        )
                    print("   ✅ Added: systems.system_name (with default values)")
            else:
                print("   ⏭️  Skipped: systems.system_name (already exists)")
        else:
            print("   ⚠️  systems table not found")
        
        # =====================================================================
        # 3. CALIBRATION TABLES
        # =====================================================================
        print("\n3. Checking calibration tables...")
        
        calibration_tables = {
            'calibration_lenses': """
                CREATE TABLE IF NOT EXISTS calibration_lenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    lens_name TEXT UNIQUE,
                    weight REAL,
                    hit_rate REAL,
                    avg_lead_time REAL,
                    tier INTEGER,
                    use_lens INTEGER DEFAULT 1,
                    updated_at TEXT
                )
            """,
            'calibration_indicators': """
                CREATE TABLE IF NOT EXISTS calibration_indicators (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    indicator TEXT UNIQUE,
                    tier INTEGER,
                    score REAL,
                    optimal_window INTEGER,
                    indicator_type TEXT,
                    use_indicator INTEGER DEFAULT 1,
                    redundant_to TEXT,
                    updated_at TEXT
                )
            """,
            'calibration_config': """
                CREATE TABLE IF NOT EXISTS calibration_config (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    updated_at TEXT
                )
            """,
        }
        
        for table_name, create_sql in calibration_tables.items():
            if not table_exists(conn, table_name):
                changes.append(("CREATE TABLE", table_name))
                if not dry_run:
                    conn.execute(create_sql)
                    print(f"   ✅ Created: {table_name}")
            else:
                print(f"   ⏭️  Skipped: {table_name} (already exists)")
        
        # =====================================================================
        # 4. ANALYSIS TABLES
        # =====================================================================
        print("\n4. Checking analysis tables...")
        
        analysis_tables = {
            'analysis_rankings': """
                CREATE TABLE IF NOT EXISTS analysis_rankings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_date TEXT,
                    analysis_type TEXT,
                    indicator TEXT,
                    consensus_rank REAL,
                    tier INTEGER,
                    window_used INTEGER,
                    created_at TEXT
                )
            """,
            'analysis_signals': """
                CREATE TABLE IF NOT EXISTS analysis_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_date TEXT,
                    indicator TEXT,
                    signal_name TEXT,
                    signal_meaning TEXT,
                    rank REAL,
                    status TEXT,
                    created_at TEXT
                )
            """,
            'consensus_events': """
                CREATE TABLE IF NOT EXISTS consensus_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_date TEXT,
                    peak_consensus REAL,
                    duration_days INTEGER,
                    detected_at TEXT,
                    notes TEXT
                )
            """,
            'consensus_history': """
                CREATE TABLE IF NOT EXISTS consensus_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT,
                    consensus_value REAL,
                    window_size INTEGER,
                    created_at TEXT,
                    UNIQUE(date, window_size)
                )
            """,
        }
        
        for table_name, create_sql in analysis_tables.items():
            if not table_exists(conn, table_name):
                changes.append(("CREATE TABLE", table_name))
                if not dry_run:
                    conn.execute(create_sql)
                    print(f"   ✅ Created: {table_name}")
            else:
                print(f"   ⏭️  Skipped: {table_name} (already exists)")
        
        # Add indexes for analysis tables
        analysis_indexes = [
            ("idx_rankings_date", "CREATE INDEX IF NOT EXISTS idx_rankings_date ON analysis_rankings(run_date)"),
            ("idx_rankings_indicator", "CREATE INDEX IF NOT EXISTS idx_rankings_indicator ON analysis_rankings(indicator)"),
            ("idx_signals_date", "CREATE INDEX IF NOT EXISTS idx_signals_date ON analysis_signals(run_date)"),
            ("idx_signals_status", "CREATE INDEX IF NOT EXISTS idx_signals_status ON analysis_signals(status)"),
            ("idx_consensus_date", "CREATE INDEX IF NOT EXISTS idx_consensus_date ON consensus_history(date)"),
        ]
        
        for idx_name, idx_sql in analysis_indexes:
            if not index_exists(conn, idx_name):
                changes.append(("CREATE INDEX", idx_name))
                if not dry_run:
                    conn.execute(idx_sql)
        
        # =====================================================================
        # 5. RECORD MIGRATION
        # =====================================================================
        print("\n5. Recording migration...")
        
        if not dry_run:
            # Ensure metadata table exists
            conn.execute("""
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            
            conn.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
                ('schema_version', '2.1')
            )
            conn.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)",
                ('last_migration', datetime.now().isoformat())
            )
            conn.commit()
            print("   ✅ Recorded: schema_version = 2.1")
        
        # =====================================================================
        # SUMMARY
        # =====================================================================
        print("\n" + "=" * 60)
        if dry_run:
            print(f"DRY RUN COMPLETE - {len(changes)} changes would be made:")
            for change_type, change_target in changes:
                print(f"   • {change_type}: {change_target}")
        else:
            print(f"✅ MIGRATION COMPLETE - {len(changes)} changes applied")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()


def main():
    parser = argparse.ArgumentParser(description="Migrate PRISM database to schema v2.1")
    parser.add_argument("--db", type=Path, help="Path to database file")
    parser.add_argument("--dry-run", action="store_true", help="Show what would happen without making changes")
    
    args = parser.parse_args()
    
    db_path = args.db or get_default_db_path()
    
    success = migrate(db_path, dry_run=args.dry_run)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
