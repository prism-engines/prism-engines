# PRISM Phase 5 (Web Server) - Quick Reference

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
pip install flask --break-system-packages
```

---

## Files to Create (4 new files)

```
runner/
└── web_server.py             # Flask app with routes

templates/runner/
├── index.html                # Main form UI
├── results.html              # Results display  
└── error.html                # Error page

test_phase5_web.py            # Verification script
```

**Files to Update:**
- `runner/__init__.py` - Add web server exports
- `prism_run.py` - Add --web flag routing

---

## Verification Commands

```bash
# Test 1: Verify Flask
python -c "import flask; print(f'Flask {flask.__version__}')"
# Expected: Flask 3.x.x

# Test 2: Check templates exist
ls templates/runner/
# Expected: index.html results.html error.html

# Test 3: Run verification
python test_phase5_web.py
# Expected: ALL 8 TESTS PASSED

# Test 4: Start web server
python prism_run.py --web
# Expected: Server at http://localhost:5000

# Test 5: Browser test
# Open http://localhost:5000
# Select panel → Select workflow → Click Run
# Should see results page
```

---

## Key Routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/` | GET | Main form page |
| `/run` | POST | Execute & show results |
| `/health` | GET | Health check |
| `/api/panels` | GET | Panel list JSON |
| `/api/workflows` | GET | Workflow list JSON |

---

## Commit Message

```
Phase 5: Add Flask web server UI

- Add runner/web_server.py with Flask routes
- Add templates/runner/ (index, results, error)
- Add --web flag to prism_run.py
- Panel/workflow dropdowns with descriptions
- Run button triggers backend execution

Usage: python prism_run.py --web
```

---

## Success Criteria

✅ `import flask` works  
✅ templates/runner/*.html exist (3 templates)  
✅ `from runner.web_server import create_app` works  
✅ `python prism_run.py --web` starts server  
✅ http://localhost:5000 shows form  
✅ Panel/workflow dropdowns populated  
✅ Run button executes analysis  
✅ Results page shows similarity bars  

---

## Usage

```bash
# Default port 5000
python prism_run.py --web

# Custom port
python prism_run.py --web --port 8080

# Debug mode (auto-reload)
python prism_run.py --web --debug
```

---

## Phase 6 Preview

Phase 6 (Professional Plugin System) will:
- Add plugin discovery via entry points
- Create plugin base classes
- Support third-party engines/panels/workflows
- Add plugin configuration UI
