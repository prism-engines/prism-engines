# PR: Indicator Family System
## Prevent Duplicate Signal Overweighting

### Summary

Adds an **Indicator Family System** to prevent double-counting when the same underlying signal exists at multiple resolutions or from multiple sources.

**Problem**: Loading both `sp500_d` (daily) and `sp500_m` (monthly) double-weights S&P 500.

**Solution**: Family registry groups related indicators, auto-selects by purpose, blocks double-counting per lens.

---

## Files to Create

### 1. `data/registry/families.yaml`

```yaml
# data/registry/families.yaml
# Indicator Family Registry - Prevents duplicate signal overweighting

families:

  spx:
    canonical_name: "S&P 500"
    description: "Multi-resolution index family (daily Tiingo, monthly FRED)"
    
    members:
      sp500_d:
        source: tiingo
        symbol: "^GSPC"
        fred_code: null
        resolution: daily
        frequency: 1d
        history_start: 1928
        use_for:
          - geometry
          - phase
          - short_term_coherence
          - ml_features

      sp500_m:
        source: fred
        symbol: null
        fred_code: "SP500"
        resolution: monthly
        frequency: 1m
        history_start: 1871
        use_for:
          - calibration
          - regime_baseline
          - long_term_hurst
          - macro_trend

    rules:
      default_representation: sp500_d
      allow_multi_resolution: true
      correlation_warning_threshold: 0.90
      require_single_representation_per_lens: true


  djia:
    canonical_name: "Dow Jones Industrial Average"
    description: "US blue-chip index (Tiingo only - FRED has limited history)"
    
    members:
      djia_d:
        source: tiingo
        symbol: "^DJI"
        fred_code: null
        resolution: daily
        frequency: 1d
        history_start: 1896
        use_for:
          - geometry
          - phase
          - cross_index_coherence

    rules:
      default_representation: djia_d
      allow_multi_resolution: false
      require_single_representation_per_lens: true


  treasury_10y:
    canonical_name: "10-Year Treasury Yield"
    description: "Multi-resolution rate family"
    
    members:
      dgs10_d:
        source: fred
        symbol: null
        fred_code: "DGS10"
        resolution: daily
        frequency: 1d
        history_start: 1962
        use_for:
          - geometry
          - yield_curve
          - real_time_rates

      gs10_m:
        source: fred
        symbol: null
        fred_code: "GS10"
        resolution: monthly
        frequency: 1m
        history_start: 1953
        use_for:
          - calibration
          - long_term_rate_cycles

    rules:
      default_representation: dgs10_d
      allow_multi_resolution: true
      correlation_warning_threshold: 0.95
      require_single_representation_per_lens: true


  vix:
    canonical_name: "VIX Volatility Index"
    description: "Market fear gauge"
    
    members:
      vix_d:
        source: fred
        symbol: null
        fred_code: "VIXCLS"
        resolution: daily
        frequency: 1d
        history_start: 1990
        use_for:
          - geometry
          - risk_regime
          - fear_gauge

    rules:
      default_representation: vix_d
      allow_multi_resolution: false
      require_single_representation_per_lens: true


  usd_index:
    canonical_name: "US Dollar Index"
    description: "Trade-weighted dollar strength"
    
    members:
      dxy_d:
        source: tiingo
        symbol: "DX-Y.NYB"
        fred_code: null
        resolution: daily
        frequency: 1d
        history_start: 1971
        use_for:
          - geometry
          - currency_regime

      dtwexb_m:
        source: fred
        symbol: null
        fred_code: "DTWEXBGS"
        resolution: monthly
        frequency: 1m
        history_start: 1973
        use_for:
          - calibration
          - long_term_dollar_cycles

    rules:
      default_representation: dxy_d
      allow_multi_resolution: true
      correlation_warning_threshold: 0.85
      require_single_representation_per_lens: true


# Purpose → Resolution mapping
purpose_resolution_map:
  geometry: daily
  phase: daily
  short_term_coherence: daily
  ml_features: daily
  calibration: monthly
  regime_baseline: monthly
  long_term_hurst: monthly
  macro_trend: monthly
  wavelet: multi


# Global rules
global_rules:
  default_to_highest_resolution: true
  duplicate_correlation_threshold: 0.90
  warn_on_potential_duplicates: true
  block_on_duplicates: false
```

---

### 2. `data/family_manager.py`

```python
"""
Indicator Family Manager
========================

Manages multi-resolution versions of the same underlying signal.
Prevents double-counting in analysis.

Usage:
    manager = FamilyManager()
    
    # Get appropriate indicator for purpose
    indicator = manager.get_for_purpose('spx', 'geometry')  # → 'sp500_d'
    indicator = manager.get_for_purpose('spx', 'calibration')  # → 'sp500_m'
    
    # Validate selection (blocks duplicates)
    manager.validate_no_double_counting(['sp500_d', 'sp500_m'], lens='geometry')
"""

import yaml
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class IndicatorFamily:
    """Manage multi-resolution versions of the same underlying signal."""

    def __init__(self, family_id: str, spec: dict):
        self.family_id = family_id
        self.spec = spec
        self.members = spec.get("members", {})
        self.rules = spec.get("rules", {})
        
        self.default_member = self.rules.get("default_representation")
        self.corr_warn_threshold = self.rules.get("correlation_warning_threshold", 0.90)
        self.multi_res_allowed = self.rules.get("allow_multi_resolution", False)
        self.single_per_lens = self.rules.get("require_single_representation_per_lens", True)

    def get_for_purpose(self, purpose: str) -> str:
        """Return the correct member ID for a given analysis purpose."""
        
        # Purpose → resolution mapping
        purpose_map = {
            "geometry": "daily",
            "phase": "daily",
            "short_term_coherence": "daily",
            "ml_features": "daily",
            "calibration": "monthly",
            "regime_baseline": "monthly",
            "long_term_hurst": "monthly",
            "macro_trend": "monthly",
        }

        target_res = purpose_map.get(purpose)
        if not target_res:
            return self.default_member

        return self._get_member_by_resolution(target_res)

    def _get_member_by_resolution(self, resolution: str) -> str:
        """Pick member based on resolution."""
        for name, spec in self.members.items():
            if spec.get("resolution") == resolution:
                return name
        return self.default_member

    def validate_no_double_counting(self, selected: List[str], lens: str = None):
        """
        Ensure we never load multiple members of the same family per lens.
        
        Raises ValueError if violation detected (unless multi_res allowed).
        """
        selected_members = [m for m in selected if m in self.members]

        if len(selected_members) <= 1:
            return True

        if self.single_per_lens and lens:
            raise ValueError(
                f"[FAMILY:{self.family_id}] Multiple resolutions {selected_members} "
                f"selected for lens '{lens}'. Only one allowed per lens."
            )

        if not self.multi_res_allowed:
            raise ValueError(
                f"[FAMILY:{self.family_id}] Multiple resolutions {selected_members} "
                f"selected, but allow_multi_resolution=false."
            )

        # Allowed but warn
        print(
            f"⚠️ [FAMILY:{self.family_id}] Multi-resolution load: "
            f"{selected_members} (allowed=True)"
        )
        return True

    def get_all_members(self) -> List[str]:
        """Return all member IDs."""
        return list(self.members.keys())


class FamilyManager:
    """
    Manages all indicator families.
    
    Responsibilities:
    1. Load family registry
    2. Select appropriate indicator by purpose
    3. Prevent double-counting per lens
    4. Warn on correlated duplicates
    """

    def __init__(self, registry_path: Optional[Path] = None):
        self.registry_path = registry_path or Path("data/registry/families.yaml")
        self.families: Dict[str, IndicatorFamily] = {}
        self.member_to_family: Dict[str, str] = {}
        self._load_registry()

    def _load_registry(self):
        """Load families from YAML."""
        if not self.registry_path.exists():
            print(f"⚠️ Family registry not found: {self.registry_path}")
            return

        with open(self.registry_path) as f:
            data = yaml.safe_load(f)

        for family_id, spec in data.get("families", {}).items():
            family = IndicatorFamily(family_id, spec)
            self.families[family_id] = family
            
            # Build reverse lookup
            for member_id in family.members:
                self.member_to_family[member_id] = family_id

    def get_for_purpose(self, family_id: str, purpose: str) -> Optional[str]:
        """Get appropriate member for a purpose."""
        family = self.families.get(family_id)
        if not family:
            return None
        return family.get_for_purpose(purpose)

    def get_family_for_member(self, member_id: str) -> Optional[IndicatorFamily]:
        """Get the family containing a member."""
        family_id = self.member_to_family.get(member_id)
        if family_id:
            return self.families.get(family_id)
        return None

    def select_indicators(
        self, 
        requested: List[str], 
        purpose: str
    ) -> Tuple[List[str], List[str]]:
        """
        Resolve requested indicators, replacing family IDs with appropriate members.
        
        Returns: (selected_indicators, warnings)
        """
        selected = []
        warnings = []
        seen_families = set()

        for req in requested:
            # Is it a family ID?
            if req in self.families:
                family = self.families[req]
                member = family.get_for_purpose(purpose)
                
                if req in seen_families:
                    warnings.append(f"Family '{req}' already included - skipping")
                    continue
                
                selected.append(member)
                seen_families.add(req)

            # Is it a member ID?
            elif req in self.member_to_family:
                family_id = self.member_to_family[req]
                
                if family_id in seen_families:
                    warnings.append(
                        f"'{req}' skipped - family '{family_id}' already represented"
                    )
                    continue
                
                selected.append(req)
                seen_families.add(family_id)

            else:
                # Not in registry - pass through
                selected.append(req)

        return selected, warnings

    def validate_selection(
        self, 
        indicators: List[str], 
        lens: str = None
    ) -> Dict:
        """
        Validate indicator selection for double-counting.
        
        Returns: {valid: bool, issues: [], warnings: []}
        """
        issues = []
        warnings = []
        
        # Group by family
        family_members: Dict[str, List[str]] = {}
        for ind in indicators:
            family_id = self.member_to_family.get(ind)
            if family_id:
                if family_id not in family_members:
                    family_members[family_id] = []
                family_members[family_id].append(ind)

        # Check each family
        for family_id, members in family_members.items():
            if len(members) > 1:
                family = self.families[family_id]
                
                if family.single_per_lens and lens:
                    issues.append(
                        f"Family '{family_id}' has multiple members {members} "
                        f"in lens '{lens}' - only one allowed"
                    )
                elif not family.multi_res_allowed:
                    issues.append(
                        f"Family '{family_id}' has multiple members {members} "
                        f"but multi-resolution not allowed"
                    )
                else:
                    warnings.append(
                        f"Family '{family_id}' multi-resolution: {members} (allowed)"
                    )

        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings
        }

    def list_families(self) -> List[Dict]:
        """List all families with their members."""
        return [
            {
                'id': fid,
                'name': f.spec.get('canonical_name', fid),
                'members': f.get_all_members(),
                'default': f.default_member,
                'multi_res': f.multi_res_allowed
            }
            for fid, f in self.families.items()
        ]


# =============================================================================
# Integration Hook - Call before any analysis
# =============================================================================

def validate_before_analysis(
    indicators: List[str],
    purpose: str = 'geometry',
    lens: str = None,
    strict: bool = False
) -> Tuple[List[str], bool]:
    """
    Pre-analysis validation hook.
    
    Args:
        indicators: Requested indicators (can include family IDs)
        purpose: Analysis purpose (geometry, calibration, etc.)
        lens: Specific lens being run (for single-per-lens rule)
        strict: Raise exception on issues if True
        
    Returns:
        (resolved_indicators, is_valid)
    """
    manager = FamilyManager()
    
    # Resolve family IDs to members
    resolved, selection_warnings = manager.select_indicators(indicators, purpose)
    
    for warn in selection_warnings:
        print(f"⚠️ {warn}")
    
    # Validate for duplicates
    validation = manager.validate_selection(resolved, lens=lens)
    
    for issue in validation['issues']:
        print(f"🔴 {issue}")
    
    for warn in validation['warnings']:
        print(f"🟡 {warn}")
    
    if validation['issues'] and strict:
        raise ValueError(f"Family validation failed: {validation['issues']}")
    
    return resolved, validation['valid']


# =============================================================================
# CLI Testing
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("Indicator Family Manager - Test")
    print("=" * 60)
    
    manager = FamilyManager()
    
    print("\n📦 Registered Families:")
    for fam in manager.list_families():
        print(f"  {fam['id']}: {fam['members']} (default: {fam['default']})")
    
    print("\n🎯 Purpose-Based Selection:")
    for purpose in ['geometry', 'calibration']:
        member = manager.get_for_purpose('spx', purpose)
        print(f"  SPX for '{purpose}' → {member}")
    
    print("\n⚠️ Duplicate Detection:")
    validation = manager.validate_selection(
        ['sp500_d', 'sp500_m', 'vix_d'], 
        lens='geometry'
    )
    print(f"  Valid: {validation['valid']}")
    print(f"  Issues: {validation['issues']}")
    
    print("\n✅ Smart Selection (using family IDs):")
    selected, warns = manager.select_indicators(
        ['spx', 'treasury_10y', 'vix'], 
        purpose='geometry'
    )
    print(f"  Requested: ['spx', 'treasury_10y', 'vix']")
    print(f"  Selected:  {selected}")
    
    print("\n" + "=" * 60)
```

---

## Integration Guide

### Option A: Pre-Analysis Hook (Recommended)

Add to any analysis entry point:

```python
from data.family_manager import validate_before_analysis

def run_lens(indicators, lens_name, purpose='geometry'):
    # Validate and resolve indicators
    resolved, valid = validate_before_analysis(
        indicators,
        purpose=purpose,
        lens=lens_name,
        strict=True  # Block if duplicates detected
    )
    
    # Continue with resolved indicators
    # ...
```

### Option B: Manual Selection

```python
from data.family_manager import FamilyManager

manager = FamilyManager()

# User requests family IDs (not specific members)
requested = ['spx', 'treasury_10y', 'vix', 'usd_index']

# Manager resolves to appropriate members for purpose
selected, warnings = manager.select_indicators(requested, purpose='geometry')
# → ['sp500_d', 'dgs10_d', 'vix_d', 'dxy_d']

selected, warnings = manager.select_indicators(requested, purpose='calibration')
# → ['sp500_m', 'gs10_m', 'vix_d', 'dtwexb_m']
```

### Option C: Validation Only

```python
from data.family_manager import FamilyManager

manager = FamilyManager()

# Check if selection has duplicates
validation = manager.validate_selection(
    ['sp500_d', 'sp500_m', 'vix_d'],
    lens='geometry'
)

if not validation['valid']:
    print(f"Issues: {validation['issues']}")
    # → "Family 'spx' has multiple members ['sp500_d', 'sp500_m'] in lens 'geometry'"
```

---

## Key Rules Enforced

| Rule | Description |
|------|-------------|
| `require_single_representation_per_lens` | Only ONE member per family in any single lens |
| `allow_multi_resolution` | If False, blocks loading multiple resolutions entirely |
| `correlation_warning_threshold` | Warn if members correlate above this (default 0.90) |
| Purpose-based selection | `geometry` → daily, `calibration` → monthly |

---

## Verification

```bash
# Test the manager
python data/family_manager.py
```

Expected output:
```
📦 Registered Families:
  spx: ['sp500_d', 'sp500_m'] (default: sp500_d)
  djia: ['djia_d'] (default: djia_d)
  treasury_10y: ['dgs10_d', 'gs10_m'] (default: dgs10_d)
  vix: ['vix_d'] (default: vix_d)
  usd_index: ['dxy_d', 'dtwexb_m'] (default: dxy_d)

🎯 Purpose-Based Selection:
  SPX for 'geometry' → sp500_d
  SPX for 'calibration' → sp500_m

⚠️ Duplicate Detection:
  Valid: False
  Issues: ["Family 'spx' has multiple members ['sp500_d', 'sp500_m'] in lens 'geometry'"]

✅ Smart Selection (using family IDs):
  Requested: ['spx', 'treasury_10y', 'vix']
  Selected:  ['sp500_d', 'dgs10_d', 'vix_d']
```

---

## Summary

This PR provides:

1. **Family Registry** (`families.yaml`) - Defines indicator groups
2. **Family Manager** (`family_manager.py`) - Enforces rules
3. **Pre-Analysis Hook** - `validate_before_analysis()` for easy integration
4. **Purpose-Based Selection** - Auto-picks daily vs monthly
5. **Double-Counting Prevention** - Blocks multiple family members per lens

No changes to existing code required - just add the hook where needed.
