# PRISM Research Roadmap: Phases 8-12
## Academic Rigor & Multi-Domain Validation

**Purpose:** Transform PRISM from working prototype to publication-ready research framework capable of withstanding scrutiny from physicists, statisticians, and actuaries.

**Philosophy:** "Extraordinary claims require extraordinary evidence." Cross-domain rhythm discovery is a bold claim. The math must be bulletproof.

---

## Current State (End of Phase 7)

### What's Built ✅
- 14 lens engines (PCA, wavelet, Hurst, coherence, etc.)
- Universal cross-domain selector
- Data integrity layer (Family Manager, HVD)
- Registry architecture (YAML-based)
- CLI and web interfaces
- Plugin system

### What's Missing ❌
- Statistical significance testing
- Null model / surrogate data framework
- Confidence intervals on all estimates
- Stationarity documentation
- Reproducibility infrastructure
- Historical stress tests
- Theoretical justification
- Multi-domain validation data

---

## Phase Overview

| Phase | Focus | Reviewer Target | Duration |
|-------|-------|-----------------|----------|
| 8 | Statistical Foundation | Statistician | 2-3 weeks |
| 9 | Null Models & Significance | All | 2 weeks |
| 10 | Historical Validation | Actuary | 2 weeks |
| 11 | Physics Formalism | Physicist | 2 weeks |
| 12 | Multi-Domain Expansion | All | 3-4 weeks |

---

## Phase 8: Statistical Foundation

**Goal:** Every estimate has uncertainty quantification. Every test has proper corrections.

### 8.1 Stationarity Testing Module
```
analysis/stationarity.py
├── adf_test()           # Augmented Dickey-Fuller
├── kpss_test()          # KPSS (opposite null)
├── pp_test()            # Phillips-Perron
├── determine_order()    # I(0), I(1), I(2) classification
└── StationarityReport   # Dataclass with all results
```

**Output:** `data/registry/stationarity_manifest.yaml`
```yaml
indicators:
  spy_ma_ratio:
    adf_statistic: -4.23
    adf_pvalue: 0.001
    kpss_statistic: 0.21
    kpss_pvalue: 0.10
    integration_order: 0
    conclusion: stationary
    recommended_transform: none
    
  treasury_10y:
    adf_statistic: -1.89
    adf_pvalue: 0.34
    integration_order: 1
    conclusion: unit_root
    recommended_transform: first_difference
```

### 8.2 Confidence Interval Framework
```
analysis/uncertainty.py
├── bootstrap_ci()           # Non-parametric bootstrap
├── block_bootstrap_ci()     # For time series (preserves autocorrelation)
├── jackknife_ci()           # Leave-one-out
├── parametric_ci()          # Asymptotic formulas where available
└── UncertaintyResult        # Dataclass: estimate, se, ci_lower, ci_upper, method
```

**Integration:** Every engine wraps results:
```python
# Before
return {'hurst': 0.62}

# After  
return {
    'hurst': 0.62,
    'hurst_se': 0.04,
    'hurst_ci_95': [0.54, 0.70],
    'hurst_ci_method': 'block_bootstrap',
    'hurst_n_bootstrap': 1000
}
```

### 8.3 Multiple Comparison Corrections
```
analysis/multiple_testing.py
├── bonferroni()             # Conservative
├── holm()                   # Step-down
├── benjamini_hochberg()     # FDR control
├── benjamini_yekutieli()    # FDR under dependence
└── apply_correction()       # Unified interface
```

**Usage:** When running N lenses on M indicators:
```python
raw_pvalues = [lens.pvalue for lens in results]
adjusted = benjamini_hochberg(raw_pvalues, alpha=0.05)
significant = [p < 0.05 for p in adjusted]
```

### 8.4 Preprocessing Registry
```yaml
# data/registry/preprocessing.yaml
indicators:
  # Already stationary / bounded
  spy_ma_ratio:
    transform: none
    bounds: [0, 2]
    notes: "MA ratio naturally bounded"
    
  vix:
    transform: log
    bounds: [0, inf]
    notes: "Log-VIX more normal"
    
  # Needs differencing
  treasury_10y:
    transform: first_difference
    original_unit: percent
    transformed_unit: percent_change
    
  # Price series
  spy_price:
    transform: log_return
    original_unit: dollars
    transformed_unit: log_return
    
  # Already rate of change
  gdp_growth:
    transform: none
    unit: percent_annualized
```

### 8.5 Cointegration Testing
```
analysis/cointegration.py
├── engle_granger()          # Two-variable
├── johansen()               # Multivariate
├── bounds_test()            # ARDL bounds
└── CointegrationReport      # Rank, vectors, p-values
```

**Critical for:** Any long-run relationship claims between non-stationary series.

### 8.6 Sample Size & Power
```
analysis/power_analysis.py
├── hurst_min_samples()      # Minimum N for reliable Hurst
├── coherence_min_samples()  # Frequency resolution requirements
├── regime_min_transitions() # Minimum regime changes needed
├── bootstrap_power()        # Empirical power via simulation
└── PowerReport              # Required N, achieved power, recommendations
```

---

## Phase 9: Null Models & Significance Testing

**Goal:** Prove findings aren't artifacts. Every "discovery" tested against appropriate null.

### 9.1 Surrogate Data Framework
```
analysis/surrogates.py
├── random_shuffle()         # Destroys all structure
├── phase_randomization()    # Preserves spectrum, destroys phase
├── aaft()                   # Amplitude Adjusted Fourier Transform
├── iaaft()                  # Iterative AAFT (preserves distribution + spectrum)
├── block_bootstrap()        # Preserves local structure
├── twin_surrogates()        # For deterministic systems
└── SurrogateTest            # Full hypothesis testing framework
```

**Usage:**
```python
from analysis.surrogates import SurrogateTest

test = SurrogateTest(
    data=real_data,
    statistic=lambda x: compute_coherence(x['spy'], x['temp']),
    surrogate_method='iaaft',
    n_surrogates=1000
)

result = test.run()
# result.observed = 0.73
# result.surrogate_mean = 0.31
# result.surrogate_std = 0.08
# result.z_score = 5.25
# result.p_value = 0.00001
# result.significant = True
```

### 9.2 Null Model Zoo
```
analysis/null_models.py
├── white_noise()            # IID Gaussian
├── random_walk()            # I(1) process
├── ar1_null()               # AR(1) with matched autocorrelation
├── arma_null()              # ARMA with matched ACF/PACF
├── garch_null()             # Volatility clustering without signal
├── regime_switching_null()  # Random regime changes
└── coupled_null()           # Two series with known (zero) coupling
```

### 9.3 Significance Wrapper
Every lens gets a significance test:
```python
class SignificantHurstEngine(HurstEngine):
    def analyze_with_significance(self, data, n_surrogates=1000):
        observed = self.analyze(data)
        
        surrogate_results = []
        for _ in range(n_surrogates):
            surrogate = generate_iaaft_surrogate(data)
            surrogate_results.append(self.analyze(surrogate))
        
        return {
            'observed': observed,
            'surrogate_distribution': surrogate_results,
            'p_value': compute_pvalue(observed, surrogate_results),
            'significant': p_value < 0.05
        }
```

### 9.4 Cross-Domain Null Hypothesis
**The critical test:** "Is cross-domain coherence higher than expected by chance?"

```python
def test_cross_domain_coherence(economic_data, climate_data, n_surrogates=1000):
    """
    Null hypothesis: Economic and climate indicators are independent.
    Generate surrogates that preserve within-domain structure
    but destroy cross-domain relationships.
    """
    observed_coherence = compute_cross_domain_coherence(economic_data, climate_data)
    
    null_coherences = []
    for _ in range(n_surrogates):
        # Shuffle climate relative to economic (destroys cross-domain only)
        shuffled_climate = phase_randomize_independently(climate_data)
        null_coherences.append(
            compute_cross_domain_coherence(economic_data, shuffled_climate)
        )
    
    p_value = np.mean(null_coherences >= observed_coherence)
    return {
        'observed': observed_coherence,
        'null_mean': np.mean(null_coherences),
        'null_std': np.std(null_coherences),
        'p_value': p_value,
        'reject_null': p_value < 0.05
    }
```

### 9.5 Sensitivity Analysis Framework
```
analysis/sensitivity.py
├── parameter_sensitivity()   # Vary one parameter, measure output change
├── bootstrap_sensitivity()   # Sensitivity of results to data subsample
├── specification_curve()     # Run all reasonable specifications
└── SensitivityReport        # Heatmaps, tornado charts
```

**Specification Curve:** Run analysis with every reasonable combination:
- MA windows: [20/50, 50/100, 50/200, 100/200]
- Normalization: [z-score, min-max, rank]
- Hurst method: [RS, DFA, wavelet]
- Coherence window: [128, 256, 512]

If results are robust across specifications, much stronger claim.

---

## Phase 10: Historical Validation

**Goal:** Prove the framework works on known events. Build actuarial credibility.

### 10.1 Crisis Event Registry
```yaml
# data/registry/historical_events.yaml
events:
  - id: crash_1987
    name: "Black Monday"
    date: 1987-10-19
    type: market_crash
    severity: extreme
    drawdown_pct: 22.6
    recovery_days: 451
    
  - id: ltcm_1998
    name: "LTCM Crisis"  
    date: 1998-08-17
    type: liquidity_crisis
    severity: severe
    
  - id: dotcom_2000
    name: "Dot-com Bubble"
    date_start: 2000-03-10
    date_end: 2002-10-09
    type: bubble_burst
    severity: severe
    drawdown_pct: 49.1
    
  - id: gfc_2008
    name: "Global Financial Crisis"
    date_start: 2007-10-09
    date_end: 2009-03-09
    type: systemic_crisis
    severity: extreme
    drawdown_pct: 56.8
    
  - id: covid_2020
    name: "COVID Crash"
    date: 2020-02-19
    type: exogenous_shock
    severity: severe
    drawdown_pct: 33.9
    recovery_days: 148
    
  - id: rate_shock_2022
    name: "Rate Shock"
    date_start: 2022-01-03
    date_end: 2022-10-12
    type: monetary_tightening
    severity: moderate
    drawdown_pct: 25.4
```

### 10.2 Stress Test Suite
```
validation/stress_tests.py
├── run_single_event()       # Analyze one crisis
├── run_all_events()         # Full historical sweep
├── compute_lead_time()      # Days of warning before event
├── compute_signal_quality() # True positive, false positive rates
└── StressTestReport         # Comprehensive results
```

**Output for each event:**
```python
{
    'event': 'gfc_2008',
    'regime_before': 'expansion',
    'regime_during': 'crisis',
    'transition_detected': '2007-11-15',
    'actual_peak': '2007-10-09',
    'lead_time_days': -37,  # Negative = late detection
    'warning_signals': [
        {'date': '2007-08-15', 'signal': 'coherence_breakdown', 'strength': 0.72},
        {'date': '2007-09-20', 'signal': 'hurst_shift', 'strength': 0.65}
    ],
    'false_alarms_prior_year': 2,
    'max_drawdown_if_acted': 0.12  # vs 0.568 buy-and-hold
}
```

### 10.3 Confusion Matrix for Regimes
```
validation/regime_accuracy.py
├── compute_confusion_matrix()
├── compute_precision_recall()
├── compute_f1_score()
├── compute_auc_roc()
└── RegimeAccuracyReport
```

Compare VCF regime classification against:
- NBER recession dates
- Market drawdown > X%
- VIX > 30 threshold
- Simple trend-following rules

### 10.4 Tail Analysis
```
validation/tail_analysis.py
├── conditional_var()        # VaR given VCF regime
├── conditional_es()         # Expected Shortfall given regime
├── tail_dependence()        # Co-crash probability
├── drawdown_distribution()  # By regime
└── TailReport
```

**Key metrics:**
- P(drawdown > 20% | VCF says "crisis") vs P(drawdown > 20% | VCF says "expansion")
- If these aren't significantly different, framework has no tail value.

### 10.5 Out-of-Sample Protocol
```
validation/temporal_validation.py
├── expanding_window()       # Train on [0:t], test on [t:t+1]
├── rolling_window()         # Train on [t-w:t], test on [t:t+1]
├── blocked_cv()             # K-fold with temporal blocks
├── purged_cv()              # Gap between train/test (prevent leakage)
└── ValidationReport
```

**Mandatory split:**
- Discovery: 1970-2015 (hypothesis generation)
- Validation: 2016-2024 (hypothesis testing)
- Never tune parameters on validation set.

---

## Phase 11: Physics Formalism

**Goal:** Satisfy a physicist that the math is rigorous and the claims are justified.

### 11.1 Metric Tensor Definition
```
theory/geometry.py
├── define_metric()          # g_ij for the indicator space
├── compute_distance()       # Proper distance using metric
├── compute_geodesic()       # Shortest path in curved space
├── ricci_curvature()        # Intrinsic curvature
└── GeometryReport
```

**Document clearly:**
```python
# The VCF metric tensor
# 
# Our indicator space has N dimensions, one per normalized indicator.
# After normalization to [0,1] or z-score, we adopt Euclidean metric:
#
#   g_ij = δ_ij (Kronecker delta)
#   ds² = Σ_i (dx_i)²
#
# Justification: All indicators normalized to comparable scales.
# Alternative: Mahalanobis metric using covariance structure.
# 
# We explicitly do NOT claim Riemannian structure from the data itself;
# the geometry is imposed for analytical convenience.
```

### 11.2 Hamiltonian Framework (If Claimed)
```
theory/hamiltonian.py
├── define_hamiltonian()     # H(q, p) energy function
├── compute_phase_space()    # (position, momentum) coordinates
├── hamilton_equations()     # dq/dt, dp/dt
├── check_conservation()     # Is H conserved along trajectories?
├── liouville_check()        # Phase space volume preservation
└── HamiltonianReport
```

**Either:**
- Define a proper Hamiltonian with conserved quantities, OR
- Remove Hamiltonian language from the framework description

### 11.3 Symmetry Documentation
```
theory/symmetries.py
├── test_scale_invariance()      # f(λx) = λ^α f(x)?
├── test_translation_invariance() # f(x + c) = f(x)?
├── test_rotation_invariance()   # f(Rx) = f(x)?
├── document_broken_symmetries() # What's NOT invariant
└── SymmetryReport
```

### 11.4 Dimensional Analysis
```
theory/dimensions.py
├── assign_dimensions()      # [indicator] = ?, [coordinate] = ?
├── check_consistency()      # Are equations dimensionally consistent?
├── derive_scaling()         # What scaling laws emerge?
└── DimensionalReport
```

### 11.5 Ergodicity Analysis
```
theory/ergodicity.py
├── test_stationarity_strict()   # Is the process stationary?
├── time_vs_ensemble()           # Compare time average to ensemble estimate
├── compute_mixing_time()        # How long until independence?
├── ergodicity_economics()       # Reference Ole Peters' framework
└── ErgodicityReport
```

**Key disclosure:**
> "We have a single realization of market history. Our time averages are used as estimators of ensemble properties. This assumes ergodicity, which may not hold for economic systems. Results should be interpreted as properties of this particular history, not necessarily of 'the market' as an abstract entity."

### 11.6 Theoretical Mechanism
Write a document:
```
theory/MECHANISM.md
├── Why should cross-domain coherence exist?
├── What physical/economic/information processes create it?
├── Predictions the theory makes
├── How to falsify the theory
└── Connection to existing theoretical frameworks
```

---

## Phase 12: Multi-Domain Expansion

**Goal:** Validate framework on non-financial data. Prove universality claims.

### 12.1 New Data Domains

#### Climate Data (Easy to fetch)
```yaml
climate:
  sources:
    - NOAA Climate Data Online
    - NASA GISS
    - Copernicus Climate Data Store
    
  indicators:
    - id: global_temp_anomaly
      source: NASA GISS
      frequency: monthly
      history: 1880-present
      url: https://data.giss.nasa.gov/gistemp/
      
    - id: co2_mauna_loa
      source: NOAA
      frequency: monthly
      history: 1958-present
      url: https://gml.noaa.gov/ccgg/trends/data.html
      
    - id: enso_oni
      source: NOAA
      frequency: monthly
      history: 1950-present
      notes: "El Niño / La Niña oscillation"
      
    - id: arctic_sea_ice_extent
      source: NSIDC
      frequency: monthly
      history: 1979-present
      
    - id: atlantic_multidecadal_oscillation
      source: NOAA
      frequency: monthly
      history: 1856-present
```

#### Epidemiological Data
```yaml
epidemiology:
  sources:
    - CDC FluView
    - WHO
    - Our World in Data
    
  indicators:
    - id: ili_national
      source: CDC FluView
      frequency: weekly
      history: 1997-present
      notes: "Influenza-like illness rate"
      
    - id: covid_cases_us
      source: Our World in Data
      frequency: daily
      history: 2020-present
      
    - id: excess_mortality
      source: Our World in Data
      frequency: weekly
      history: 2020-present
```

#### Geophysical Data
```yaml
geophysical:
  sources:
    - USGS
    - NOAA
    
  indicators:
    - id: earthquake_energy
      source: USGS
      frequency: monthly (aggregated)
      history: 1900-present
      notes: "Total seismic moment release"
      
    - id: solar_flux
      source: NOAA SWPC
      frequency: daily
      history: 1947-present
      notes: "F10.7 solar radio flux"
      
    - id: geomagnetic_aa
      source: ISGI
      frequency: monthly
      history: 1868-present
      notes: "Geomagnetic activity index"
```

#### Social/Behavioral Data
```yaml
social:
  sources:
    - Google Trends
    - University of Michigan
    - Conference Board
    
  indicators:
    - id: consumer_sentiment
      source: U Michigan
      frequency: monthly
      history: 1952-present
      
    - id: google_uncertainty
      source: Google Trends
      frequency: weekly
      history: 2004-present
      search_term: "recession"
      
    - id: economic_policy_uncertainty
      source: PolicyUncertainty.com
      frequency: monthly
      history: 1985-present
```

#### Commodity/Physical
```yaml
commodities:
  sources:
    - FRED
    - World Bank
    
  indicators:
    - id: oil_brent
      source: FRED
      frequency: daily
      history: 1987-present
      
    - id: gold_price
      source: FRED
      frequency: daily
      history: 1968-present
      
    - id: copper_price
      source: World Bank
      frequency: monthly
      history: 1960-present
      notes: "Dr. Copper - economic indicator"
      
    - id: baltic_dry_index
      source: Bloomberg/FRED
      frequency: daily
      history: 1985-present
      notes: "Shipping/trade activity"
```

### 12.2 Cross-Domain Test Matrix

| Domain A | Domain B | Hypothesis | Expected |
|----------|----------|------------|----------|
| Economic | Climate | Weak/lagged coupling | Low coherence |
| Economic | Epidemiology | Crisis correlation | Medium coherence |
| Climate | Epidemiology | Seasonal coupling | High annual coherence |
| Geophysical | Economic | No coupling | Near-zero coherence |
| Social | Economic | Strong coupling | High coherence |
| Climate | Geophysical | Solar-climate link | Medium coherence |

### 12.3 Fetcher Infrastructure
```
data/fetchers/
├── base_fetcher.py          # Abstract base class
├── fred_fetcher.py          # FRED API ✅ (exists)
├── yahoo_fetcher.py         # Yahoo Finance ✅ (exists)
├── noaa_fetcher.py          # NOAA climate data
├── nasa_fetcher.py          # NASA GISS
├── cdc_fetcher.py           # CDC epidemiology
├── usgs_fetcher.py          # USGS earthquakes
├── google_trends_fetcher.py # Google Trends
└── owid_fetcher.py          # Our World in Data
```

### 12.4 Domain-Agnostic Validation
The ultimate test:
```python
def test_framework_universality():
    """
    If VCF is truly universal, it should:
    1. Find known relationships (economic <-> sentiment)
    2. Not find spurious relationships (earthquakes <-> stocks)
    3. Discover surprising-but-real relationships (???)
    """
    
    # Known positive: should detect
    assert cross_coherence(economic, sentiment) > 0.5
    
    # Known negative: should not detect
    assert cross_coherence(economic, earthquakes) < 0.2
    
    # The interesting part: what does it find?
    discoveries = find_unexpected_coherences(all_domains)
    for discovery in discoveries:
        # Each must pass surrogate testing
        assert surrogate_test(discovery).p_value < 0.01
```

---

## Additional Recommendations

### A. Reproducibility Infrastructure

```
reproducibility/
├── environment.yaml              # Exact package versions
├── Dockerfile                    # Containerized environment
├── data_manifest.csv             # All data sources, hashes
├── analysis_manifest.yaml        # All parameters, seeds
├── run_full_analysis.sh          # One-click reproduction
├── expected_outputs/             # Reference results
│   ├── hurst_values.csv
│   ├── coherence_matrix.csv
│   └── regime_classifications.csv
├── REPRODUCTION_GUIDE.md
└── checksums.sha256
```

### B. Documentation Standards

Every analysis module needs:
```python
"""
Module: hurst_engine.py

PURPOSE:
    Compute Hurst exponent to measure long-term memory.

MATHEMATICAL BACKGROUND:
    The Hurst exponent H characterizes self-similarity:
    E[|X(t+τ) - X(t)|²] ~ τ^(2H)
    
    H > 0.5: Persistent (trending)
    H = 0.5: Random walk
    H < 0.5: Anti-persistent (mean-reverting)

ASSUMPTIONS:
    1. Series is stationary or trend-stationary
    2. Sufficient length (N > 500 recommended)
    3. No structural breaks in sample period

LIMITATIONS:
    - R/S method biased for short series
    - DFA sensitive to polynomial order choice
    - Both assume single scaling regime

REFERENCES:
    - Hurst (1951) "Long-term storage capacity of reservoirs"
    - Mandelbrot & Wallis (1969) "Robustness of R/S analysis"
    - Peng et al. (1994) "Mosaic organization" (DFA)

VALIDATION:
    Tested against known processes:
    - fBm(H=0.3): Estimated 0.31 ± 0.03
    - fBm(H=0.7): Estimated 0.69 ± 0.02
    - ARFIMA(0, 0.2, 0): Estimated H ≈ 0.7
"""
```

### C. Pre-Registration Document

Before running validation phase, write:
```
PREREGISTRATION.md

Date: [Before validation phase]

HYPOTHESES:
1. VCF regime classification accuracy > 60% out-of-sample
2. Cross-domain coherence (economic-climate) < 0.3
3. Cross-domain coherence (economic-sentiment) > 0.5
4. Hurst estimates stable across reasonable parameter variations

ANALYSIS PLAN:
[Exact steps, no deviations]

STOPPING RULES:
[When to conclude positive/negative]

EXCLUSION CRITERIA:
[What data points get excluded and why]
```

This prevents "garden of forking paths" criticism.

### D. Failure Modes Document

```
FAILURE_MODES.md

WHAT WOULD FALSIFY VCF:

1. Out-of-sample regime accuracy < 50% (random)
2. Surrogate data shows same patterns as real data
3. Results highly sensitive to arbitrary parameter choices
4. Cross-domain coherence no different from within-domain noise
5. Historical stress tests show no predictive value

KNOWN LIMITATIONS:

1. Single historical realization (ergodicity assumption)
2. Lookback bias in regime labeling methodology
3. Parameter choices not derived from first principles
4. No causal mechanism proposed

HONEST UNCERTAINTIES:

1. Is observed coherence "real" or artifact of shared trends?
2. Would results replicate on different historical period?
3. Are we overfitting to known crises?
```

---

## Timeline Estimate

| Phase | Duration | Dependencies |
|-------|----------|--------------|
| Phase 8 | 2-3 weeks | None |
| Phase 9 | 2 weeks | Phase 8 |
| Phase 10 | 2 weeks | Phases 8-9 |
| Phase 11 | 2 weeks | Can parallel Phase 10 |
| Phase 12 | 3-4 weeks | Phases 8-10 |

**Total:** 10-13 weeks to publication-ready state

---

## Immediate Next Steps

1. **Phase 8.1:** Build stationarity testing module
2. **Phase 8.2:** Add bootstrap CI to all engines
3. **Phase 8.3:** Implement FDR corrections
4. **Parallel:** Start fetching climate/epidemiology data

---

## Success Criteria

### For Physicist
- [ ] Metric tensor explicitly defined
- [ ] Hamiltonian justified or removed
- [ ] Dimensional analysis complete
- [ ] Symmetries documented
- [ ] Ergodicity discussed

### For Statistician
- [ ] All estimates have CIs
- [ ] Multiple comparison corrections applied
- [ ] Surrogate testing validates findings
- [ ] Stationarity properly handled
- [ ] Out-of-sample validation clean

### For Actuary
- [ ] Historical stress tests documented
- [ ] Tail behavior analyzed
- [ ] False positive rates quantified
- [ ] Model limitations disclosed
- [ ] Actionable thresholds derived

---

*"The goal is not to prove VCF works. The goal is to rigorously test whether it works, and report honestly either way."*

---
Document Version: 1.0
Created: December 2024
