# PRISM Phase 3 (CLI Runner) - Quick Reference

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
```

---

## Files Created/Updated (6 total)

```
runner/
├── __init__.py              # Updated: exports CLI components
├── cli_runner.py            # NEW: Interactive CLI (~350 lines)
├── executor.py              # NEW: Workflow execution (~250 lines)
├── output_manager.py        # NEW: Result formatting (~180 lines)

prism_run.py                 # UPDATED: Unified entry point
test_phase3_cli.py           # NEW: Verification script
```

---

## Verification Commands

```bash
# Test 1: Show help
python prism_run.py --help

# Test 2: List panels
python prism_run.py --list-panels
# Expected: 📈 Market, 🏛️ Economy, 🌍 Climate, ⚙️ Custom

# Test 3: List workflows
python prism_run.py --list-workflows
# Expected: 10 workflows including regime_comparison

# Test 4: List engines
python prism_run.py --list-engines
# Expected: 20 engines including pca, granger, clustering

# Test 5: Direct mode
python prism_run.py --panel market --workflow lens_validation
# Expected: EXECUTION COMPLETED

# Test 6: Full verification
python test_phase3_cli.py
# Expected: ALL 7 TESTS PASSED
```

---

## Usage

### Interactive Mode
```bash
python prism_run.py

# Follow the menus:
# 1. Select panel (market, economy, climate, custom)
# 2. Select workflow (regime_comparison, daily_update, etc.)
# 3. Configure parameters (or accept defaults)
# 4. Confirm and run
# 5. View results and saved files
```

### Direct Mode
```bash
# Basic
python prism_run.py --panel market --workflow regime_comparison

# With options
python prism_run.py -p market -w regime_comparison --comparison-periods 2008 2020 2022

# Verbose
python prism_run.py --panel economy --workflow daily_update --verbose
```

### HTML Mode (Flask)
```bash
python prism_run.py --html
# Opens browser at localhost:5000
```

---

## Commit Message

```
Phase 3: Add unified CLI runner

- Add runner/cli_runner.py interactive menu system
- Add runner/executor.py workflow execution engine
- Add runner/output_manager.py result formatting
- Update prism_run.py as unified entry point

Supports:
- Interactive mode: python prism_run.py
- Direct mode: python prism_run.py --panel market
- List commands: --list-panels, --list-workflows, --list-engines
- HTML mode: python prism_run.py --html

Integrates Phase 1 (engines) + Phase 2 (panels) + workflows
```

---

## Success Criteria

✅ `python prism_run.py --help` shows usage  
✅ `python prism_run.py --list-panels` shows 4 panels  
✅ `python prism_run.py --list-workflows` shows 10 workflows  
✅ `python prism_run.py --list-engines` shows 20 engines  
✅ `python prism_run.py --panel market --workflow lens_validation` completes  
✅ Results saved to output/ directory  
✅ test_phase3_cli.py passes all 7 tests

---

## What This Enables

**Before Phase 3:**
```bash
# No unified entry point
python run_regime.py
python run_temporal.py  
python run_daily.py
```

**After Phase 3:**
```bash
# Single unified entry point
python prism_run.py                                    # Interactive
python prism_run.py --panel market -w daily_update     # Direct
python prism_run.py --list-workflows                   # Discovery
python prism_run.py --html                             # Web UI
```

---

## Phase 4 Preview

Phase 4 (HTML Output System) will:
- Add Jinja2 templates for reports
- Create templates/ directory structure
- Convert analysis results to HTML reports
- Add charts and visualizations
