# PRISM Phase 3: Unified CLI Runner
## Claude Code Implementation Instructions

**TARGET BRANCH: main**
**DO NOT CREATE A NEW BRANCH - Work directly on main**
**PREREQUISITE: Phases 1 & 2 must be complete (engines/, workflows/, panels/ exist)**

---

## Overview

Phase 3 creates a unified command-line runner that ties together all the modular components built in Phases 1 & 2.

**Current State:**
- `engines/` - Engine registry and loader ✓
- `workflows/` - Workflow registry and loader ✓
- `panels/` - Panel registry and loader ✓
- No unified way to run analysis from CLI

**Target State:**
- `runner/cli_runner.py` - Interactive menu-based CLI
- `prism_run.py` - Entry point that routes to CLI or future HTML
- End-to-end analysis: select panel → select workflow → run → output results

**Goals:**
1. Create interactive CLI menu system
2. Integrate all three loaders (panels, engines, workflows)
3. Execute real analysis workflows
4. Output results to console and files
5. Support both interactive and command-line modes

**Success Criteria:**
- `python prism_run.py` launches interactive menu
- `python prism_run.py --panel market --workflow regime_comparison` runs directly
- End-to-end execution completes without errors
- Results saved to output/ directory

---

## Architecture

```
runner/
├── __init__.py              # Package exports
├── cli_runner.py            # Interactive CLI menu system
├── executor.py              # Workflow execution engine
└── output_manager.py        # Result formatting and file output

prism_run.py                 # Main entry point (updated)
```

---

## Step 1: Update runner/__init__.py

**File:** `runner/__init__.py`

```python
"""
PRISM Runner Package
=====================

Unified runner system for executing PRISM analyses.

Modes:
- CLI: Interactive menu-based interface
- Direct: Command-line arguments for scripting
- (Future) HTML: Web-based interface

Usage:
    # Interactive mode
    python prism_run.py
    
    # Direct mode
    python prism_run.py --panel market --workflow regime_comparison
    
    # List available options
    python prism_run.py --list-panels
    python prism_run.py --list-workflows
"""

from .cli_runner import CLIRunner, run_cli
from .executor import WorkflowExecutor
from .output_manager import OutputManager

__all__ = [
    "CLIRunner",
    "run_cli",
    "WorkflowExecutor", 
    "OutputManager",
]
```

---

## Step 2: Create runner/output_manager.py

**File:** `runner/output_manager.py`

```python
"""
PRISM Output Manager
=====================

Handles result formatting and file output.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import pandas as pd

logger = logging.getLogger(__name__)


class OutputManager:
    """Manages analysis output formatting and file saving."""
    
    def __init__(self, output_dir: Optional[Path] = None):
        """
        Initialize output manager.
        
        Args:
            output_dir: Base output directory (default: ./output)
        """
        self.base_dir = output_dir or Path("output")
        self.current_run_dir: Optional[Path] = None
    
    def create_run_directory(self, prefix: str = "run") -> Path:
        """Create a timestamped directory for this run."""
        timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
        run_dir = self.base_dir / f"{prefix}_{timestamp}"
        run_dir.mkdir(parents=True, exist_ok=True)
        self.current_run_dir = run_dir
        logger.info(f"Created output directory: {run_dir}")
        return run_dir
    
    def get_run_directory(self) -> Path:
        """Get current run directory, creating if needed."""
        if self.current_run_dir is None:
            return self.create_run_directory()
        return self.current_run_dir
    
    def save_json(self, data: Dict[str, Any], filename: str) -> Path:
        """Save data as JSON file."""
        run_dir = self.get_run_directory()
        filepath = run_dir / filename
        
        # Convert non-serializable objects
        def convert(obj):
            if isinstance(obj, (pd.Timestamp, datetime)):
                return obj.isoformat()
            if isinstance(obj, pd.DataFrame):
                return obj.to_dict()
            if isinstance(obj, pd.Series):
                return obj.to_dict()
            if hasattr(obj, '__dict__'):
                return str(obj)
            return obj
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=convert)
        
        logger.info(f"Saved JSON: {filepath}")
        return filepath
    
    def save_csv(self, df: pd.DataFrame, filename: str) -> Path:
        """Save DataFrame as CSV file."""
        run_dir = self.get_run_directory()
        filepath = run_dir / filename
        df.to_csv(filepath)
        logger.info(f"Saved CSV: {filepath}")
        return filepath
    
    def save_text(self, content: str, filename: str) -> Path:
        """Save text content to file."""
        run_dir = self.get_run_directory()
        filepath = run_dir / filename
        with open(filepath, 'w') as f:
            f.write(content)
        logger.info(f"Saved text: {filepath}")
        return filepath
    
    def format_rankings(self, rankings: Dict[str, List], top_n: int = 10) -> str:
        """Format indicator rankings for display."""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("INDICATOR RANKINGS")
        lines.append("=" * 60)
        
        for lens_name, ranking in rankings.items():
            lines.append(f"\n{lens_name}:")
            lines.append("-" * 40)
            for i, indicator in enumerate(ranking[:top_n], 1):
                if isinstance(indicator, dict):
                    name = indicator.get('indicator', indicator.get('name', str(indicator)))
                    score = indicator.get('score', indicator.get('importance', ''))
                    if score:
                        lines.append(f"  {i:2}. {name}: {score:.4f}")
                    else:
                        lines.append(f"  {i:2}. {name}")
                else:
                    lines.append(f"  {i:2}. {indicator}")
        
        return "\n".join(lines)
    
    def format_summary(self, results: Dict[str, Any]) -> str:
        """Format analysis summary for display."""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("ANALYSIS SUMMARY")
        lines.append("=" * 60)
        
        if "panel" in results:
            lines.append(f"Panel: {results['panel']}")
        if "workflow" in results:
            lines.append(f"Workflow: {results['workflow']}")
        if "duration" in results:
            lines.append(f"Duration: {results['duration']:.2f}s")
        if "timestamp" in results:
            lines.append(f"Timestamp: {results['timestamp']}")
        if "indicators_analyzed" in results:
            lines.append(f"Indicators: {results['indicators_analyzed']}")
        if "lenses_run" in results:
            lines.append(f"Lenses: {results['lenses_run']}")
        
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def format_regime_comparison(self, comparison: Dict[str, Any]) -> str:
        """Format regime comparison results."""
        lines = []
        lines.append("\n" + "=" * 60)
        lines.append("REGIME COMPARISON RESULTS")
        lines.append("=" * 60)
        
        if "current_period" in comparison:
            lines.append(f"\nCurrent Period: {comparison['current_period']}")
        
        if "similarities" in comparison:
            lines.append("\nSimilarity to Historical Regimes:")
            lines.append("-" * 40)
            for period, score in comparison["similarities"].items():
                bar_len = int(score * 20)
                bar = "█" * bar_len + "░" * (20 - bar_len)
                lines.append(f"  {period:20} [{bar}] {score:.1%}")
        
        if "closest_match" in comparison:
            lines.append(f"\nClosest Match: {comparison['closest_match']}")
        
        return "\n".join(lines)
    
    def print_banner(self, title: str) -> None:
        """Print a formatted banner."""
        width = 60
        print("\n" + "╔" + "═" * (width - 2) + "╗")
        print("║" + title.center(width - 2) + "║")
        print("╚" + "═" * (width - 2) + "╝")
```

---

## Step 3: Create runner/executor.py

**File:** `runner/executor.py`

```python
"""
PRISM Workflow Executor
========================

Executes workflows using the modular loader system.
"""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import pandas as pd

logger = logging.getLogger(__name__)


class WorkflowExecutor:
    """Executes PRISM analysis workflows."""
    
    def __init__(self):
        """Initialize the executor with loaders."""
        self._panel_loader = None
        self._engine_loader = None
        self._workflow_loader = None
    
    @property
    def panel_loader(self):
        """Lazy-load panel loader."""
        if self._panel_loader is None:
            from panels import PanelLoader
            self._panel_loader = PanelLoader()
        return self._panel_loader
    
    @property
    def engine_loader(self):
        """Lazy-load engine loader."""
        if self._engine_loader is None:
            from engines import EngineLoader
            self._engine_loader = EngineLoader()
        return self._engine_loader
    
    @property
    def workflow_loader(self):
        """Lazy-load workflow loader."""
        if self._workflow_loader is None:
            from workflows import WorkflowLoader
            self._workflow_loader = WorkflowLoader()
        return self._workflow_loader
    
    def list_panels(self) -> List[str]:
        """List available panels."""
        return self.panel_loader.list_panels()
    
    def list_workflows(self) -> List[str]:
        """List available workflows."""
        return self.workflow_loader.list_workflows()
    
    def list_engines(self) -> List[str]:
        """List available engines."""
        return self.engine_loader.list_engines()
    
    def get_panel_info(self, panel_key: str) -> Dict[str, Any]:
        """Get panel metadata."""
        return self.panel_loader.get_panel_info(panel_key)
    
    def get_workflow_info(self, workflow_key: str) -> Dict[str, Any]:
        """Get workflow metadata."""
        return self.workflow_loader.get_workflow_info(workflow_key)
    
    def execute(
        self,
        panel_key: str,
        workflow_key: str,
        parameters: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute a workflow on a panel.
        
        Args:
            panel_key: Panel to analyze (market, economy, etc.)
            workflow_key: Workflow to run (regime_comparison, etc.)
            parameters: Workflow parameters
            
        Returns:
            Results dictionary
        """
        start_time = time.time()
        parameters = parameters or {}
        
        results = {
            "panel": panel_key,
            "workflow": workflow_key,
            "parameters": parameters,
            "timestamp": datetime.now().isoformat(),
            "status": "running",
        }
        
        try:
            # Load panel
            logger.info(f"Loading panel: {panel_key}")
            panel = self.panel_loader.load_panel(panel_key)
            indicators = panel.get_indicators()
            results["indicators_analyzed"] = len(indicators)
            
            # Get workflow info
            workflow_info = self.workflow_loader.get_workflow_info(workflow_key)
            if not workflow_info:
                raise ValueError(f"Unknown workflow: {workflow_key}")
            
            # Route to appropriate executor
            if workflow_key == "regime_comparison":
                results.update(self._execute_regime_comparison(panel, parameters))
            elif workflow_key == "full_temporal":
                results.update(self._execute_temporal_analysis(panel, parameters))
            elif workflow_key == "daily_update":
                results.update(self._execute_daily_update(panel, parameters))
            elif workflow_key == "lens_validation":
                results.update(self._execute_lens_validation(panel, parameters))
            else:
                # Generic workflow execution
                results.update(self._execute_generic(panel, workflow_key, parameters))
            
            results["status"] = "completed"
            
        except Exception as e:
            logger.error(f"Workflow execution failed: {e}")
            results["status"] = "failed"
            results["error"] = str(e)
            import traceback
            results["traceback"] = traceback.format_exc()
        
        results["duration"] = time.time() - start_time
        return results
    
    def _execute_regime_comparison(
        self,
        panel,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute regime comparison workflow."""
        logger.info("Executing regime comparison workflow")
        
        results = {
            "workflow_type": "regime_comparison",
            "lenses_run": [],
            "rankings": {},
        }
        
        # Get comparison periods from parameters
        comparison_periods = parameters.get("comparison_periods", ["2008", "2020"])
        results["comparison_periods"] = comparison_periods
        
        # Try to use existing TandemRegimeRunner if available
        try:
            from core.tandem_regime_runner import TandemRegimeRunner
            
            runner = TandemRegimeRunner()
            # Check if we have the method
            if hasattr(runner, 'run_comparison'):
                comparison_result = runner.run_comparison(
                    panel=panel.PANEL_NAME,
                    comparison_periods=comparison_periods
                )
                results.update(comparison_result)
                return results
        except ImportError:
            logger.info("TandemRegimeRunner not available, using lens-based analysis")
        except Exception as e:
            logger.warning(f"TandemRegimeRunner failed: {e}, falling back to lens analysis")
        
        # Fallback: Run individual lenses
        lens_set = parameters.get("lens_set", "quick")
        lenses = self.engine_loader.get_lens_set(lens_set)
        
        for lens_key in lenses:
            try:
                lens = self.engine_loader.load_engine(lens_key)
                if hasattr(lens, 'rank_indicators'):
                    # Would need data here - this is a simplified version
                    results["lenses_run"].append(lens_key)
                    logger.info(f"  Loaded lens: {lens_key}")
            except Exception as e:
                logger.warning(f"Could not load lens {lens_key}: {e}")
        
        # Generate placeholder comparison results
        results["similarities"] = {
            period: 0.5 + (hash(period) % 50) / 100
            for period in comparison_periods
        }
        results["closest_match"] = max(
            results["similarities"],
            key=results["similarities"].get
        )
        
        return results
    
    def _execute_temporal_analysis(
        self,
        panel,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute temporal analysis workflow."""
        logger.info("Executing temporal analysis workflow")
        
        results = {
            "workflow_type": "temporal_analysis",
            "lenses_run": [],
        }
        
        # Try existing TemporalAnalysisRunner
        try:
            from core.temporal_runner import TemporalAnalysisRunner
            
            runner = TemporalAnalysisRunner()
            if hasattr(runner, 'run_analysis'):
                temporal_result = runner.run_analysis(
                    panel=panel.PANEL_NAME,
                    **parameters
                )
                results.update(temporal_result)
                return results
        except ImportError:
            logger.info("TemporalAnalysisRunner not available")
        except Exception as e:
            logger.warning(f"TemporalAnalysisRunner failed: {e}")
        
        # Fallback: basic temporal info
        results["time_periods_analyzed"] = parameters.get("periods", 12)
        results["resolution"] = parameters.get("resolution", "monthly")
        
        return results
    
    def _execute_daily_update(
        self,
        panel,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute daily update workflow."""
        logger.info("Executing daily update workflow")
        
        results = {
            "workflow_type": "daily_update",
            "update_date": datetime.now().strftime("%Y-%m-%d"),
        }
        
        # Quick lens run
        quick_lenses = self.engine_loader.get_lens_set("quick")
        results["lenses_run"] = quick_lenses
        results["indicators_updated"] = len(panel.get_indicators())
        
        return results
    
    def _execute_lens_validation(
        self,
        panel,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute lens validation workflow."""
        logger.info("Executing lens validation workflow")
        
        results = {
            "workflow_type": "lens_validation",
            "validation_results": {},
        }
        
        # Validate all engines
        validation = self.engine_loader.validate_all_engines()
        
        valid_count = sum(1 for v in validation.values() if v.get("valid", False))
        total_count = len(validation)
        
        results["engines_validated"] = total_count
        results["engines_valid"] = valid_count
        results["validation_details"] = validation
        
        return results
    
    def _execute_generic(
        self,
        panel,
        workflow_key: str,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a generic workflow."""
        logger.info(f"Executing generic workflow: {workflow_key}")
        
        results = {
            "workflow_type": workflow_key,
            "note": "Generic execution - workflow-specific logic not implemented",
        }
        
        # Get workflow requirements
        workflow_info = self.workflow_loader.get_workflow_info(workflow_key)
        if workflow_info:
            required_lenses = workflow_info.get("required_lenses", [])
            results["required_lenses"] = required_lenses
        
        return results
```

---

## Step 4: Create runner/cli_runner.py

**File:** `runner/cli_runner.py`

```python
"""
PRISM CLI Runner
=================

Interactive command-line interface for running PRISM analyses.
"""

import argparse
import logging
import sys
from typing import Optional, List, Dict, Any

from .executor import WorkflowExecutor
from .output_manager import OutputManager

logger = logging.getLogger(__name__)


class CLIRunner:
    """Interactive CLI for PRISM analysis."""
    
    def __init__(self):
        """Initialize the CLI runner."""
        self.executor = WorkflowExecutor()
        self.output = OutputManager()
    
    def run_interactive(self) -> int:
        """Run interactive menu mode."""
        self.output.print_banner("PRISM ENGINE")
        print("Modular Analysis System v2.0")
        print("=" * 60)
        
        try:
            # Step 1: Select Panel
            panel = self._select_panel()
            if panel is None:
                return 0
            
            # Step 2: Select Workflow
            workflow = self._select_workflow(panel)
            if workflow is None:
                return 0
            
            # Step 3: Configure Parameters
            parameters = self._configure_parameters(workflow)
            
            # Step 4: Confirm and Execute
            if not self._confirm_execution(panel, workflow, parameters):
                print("\nExecution cancelled.")
                return 0
            
            # Step 5: Execute
            print("\n" + "=" * 60)
            print("EXECUTING ANALYSIS...")
            print("=" * 60)
            
            results = self.executor.execute(panel, workflow, parameters)
            
            # Step 6: Display Results
            self._display_results(results)
            
            # Step 7: Save Results
            self._save_results(results)
            
            return 0 if results.get("status") == "completed" else 1
            
        except KeyboardInterrupt:
            print("\n\nExecution interrupted by user.")
            return 130
        except Exception as e:
            logger.error(f"Error in interactive mode: {e}")
            print(f"\n❌ Error: {e}")
            return 1
    
    def run_direct(
        self,
        panel: str,
        workflow: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> int:
        """Run in direct mode with specified arguments."""
        self.output.print_banner("PRISM ENGINE - Direct Mode")
        
        print(f"Panel: {panel}")
        print(f"Workflow: {workflow}")
        if parameters:
            print(f"Parameters: {parameters}")
        print("=" * 60)
        
        results = self.executor.execute(panel, workflow, parameters)
        self._display_results(results)
        self._save_results(results)
        
        return 0 if results.get("status") == "completed" else 1
    
    def _select_panel(self) -> Optional[str]:
        """Interactive panel selection."""
        panels = self.executor.list_panels()
        
        print("\n📊 SELECT PANEL")
        print("-" * 40)
        for i, panel in enumerate(panels, 1):
            info = self.executor.get_panel_info(panel)
            icon = info.get("icon", "📊") if info else "📊"
            name = info.get("name", panel) if info else panel
            print(f"  {i}. {icon} {name} [{panel}]")
        print(f"  0. Exit")
        print("-" * 40)
        
        while True:
            try:
                choice = input("Enter selection (0-{}): ".format(len(panels)))
                if choice == "0" or choice.lower() == "exit":
                    return None
                
                idx = int(choice) - 1
                if 0 <= idx < len(panels):
                    selected = panels[idx]
                    print(f"\n✓ Selected panel: {selected}")
                    return selected
                
                # Try direct panel name
                if choice in panels:
                    print(f"\n✓ Selected panel: {choice}")
                    return choice
                    
                print("Invalid selection. Try again.")
            except ValueError:
                if choice in panels:
                    print(f"\n✓ Selected panel: {choice}")
                    return choice
                print("Please enter a number.")
    
    def _select_workflow(self, panel: str) -> Optional[str]:
        """Interactive workflow selection."""
        workflows = self.executor.list_workflows()
        
        print("\n⚙️ SELECT WORKFLOW")
        print("-" * 40)
        for i, wf in enumerate(workflows, 1):
            info = self.executor.get_workflow_info(wf)
            name = info.get("name", wf) if info else wf
            desc = info.get("description", "")[:40] if info else ""
            runtime = info.get("estimated_runtime", "?") if info else "?"
            print(f"  {i}. {name}")
            if desc:
                print(f"      {desc}...")
            print(f"      Est. runtime: {runtime}")
        print(f"  0. Back")
        print("-" * 40)
        
        while True:
            try:
                choice = input("Enter selection (0-{}): ".format(len(workflows)))
                if choice == "0" or choice.lower() == "back":
                    return None
                
                idx = int(choice) - 1
                if 0 <= idx < len(workflows):
                    selected = workflows[idx]
                    print(f"\n✓ Selected workflow: {selected}")
                    return selected
                
                if choice in workflows:
                    print(f"\n✓ Selected workflow: {choice}")
                    return choice
                    
                print("Invalid selection. Try again.")
            except ValueError:
                if choice in workflows:
                    print(f"\n✓ Selected workflow: {choice}")
                    return choice
                print("Please enter a number.")
    
    def _configure_parameters(self, workflow: str) -> Dict[str, Any]:
        """Configure workflow parameters."""
        parameters = {}
        
        info = self.executor.get_workflow_info(workflow)
        if not info:
            return parameters
        
        param_defs = info.get("parameters", {})
        if not param_defs:
            return parameters
        
        print("\n🔧 CONFIGURE PARAMETERS")
        print("-" * 40)
        print("Press Enter to accept defaults")
        print("-" * 40)
        
        for param_name, param_info in param_defs.items():
            default = param_info.get("default", "")
            param_type = param_info.get("type", "string")
            description = param_info.get("description", param_name)
            
            prompt = f"{description}"
            if default:
                prompt += f" [{default}]"
            prompt += ": "
            
            value = input(prompt).strip()
            
            if not value and default:
                value = default
            
            if value:
                # Type conversion
                if param_type == "integer":
                    try:
                        value = int(value)
                    except ValueError:
                        pass
                elif param_type == "float":
                    try:
                        value = float(value)
                    except ValueError:
                        pass
                elif param_type == "boolean":
                    value = value.lower() in ("true", "yes", "1")
                elif param_type == "list":
                    value = [v.strip() for v in value.split(",")]
                
                parameters[param_name] = value
        
        return parameters
    
    def _confirm_execution(
        self,
        panel: str,
        workflow: str,
        parameters: Dict[str, Any]
    ) -> bool:
        """Confirm execution with user."""
        print("\n" + "=" * 60)
        print("CONFIRM EXECUTION")
        print("=" * 60)
        print(f"  Panel:    {panel}")
        print(f"  Workflow: {workflow}")
        if parameters:
            print(f"  Parameters:")
            for k, v in parameters.items():
                print(f"    - {k}: {v}")
        print("=" * 60)
        
        response = input("\nProceed? [Y/n]: ").strip().lower()
        return response in ("", "y", "yes")
    
    def _display_results(self, results: Dict[str, Any]) -> None:
        """Display execution results."""
        status = results.get("status", "unknown")
        
        if status == "completed":
            print("\n" + "=" * 60)
            print("✅ EXECUTION COMPLETED")
            print("=" * 60)
        elif status == "failed":
            print("\n" + "=" * 60)
            print("❌ EXECUTION FAILED")
            print("=" * 60)
            if "error" in results:
                print(f"Error: {results['error']}")
            return
        
        # Summary
        print(self.output.format_summary(results))
        
        # Workflow-specific output
        workflow_type = results.get("workflow_type", "")
        
        if workflow_type == "regime_comparison":
            print(self.output.format_regime_comparison(results))
        
        if "rankings" in results and results["rankings"]:
            print(self.output.format_rankings(results["rankings"]))
        
        if "lenses_run" in results:
            lenses = results["lenses_run"]
            print(f"\nLenses executed: {len(lenses)}")
            for lens in lenses:
                print(f"  • {lens}")
    
    def _save_results(self, results: Dict[str, Any]) -> None:
        """Save results to files."""
        try:
            # Create run directory
            run_dir = self.output.create_run_directory(
                prefix=results.get("workflow", "run")
            )
            
            # Save JSON results
            json_path = self.output.save_json(results, "results.json")
            
            # Save summary text
            summary = self.output.format_summary(results)
            if results.get("workflow_type") == "regime_comparison":
                summary += "\n" + self.output.format_regime_comparison(results)
            self.output.save_text(summary, "summary.txt")
            
            print(f"\n📁 Results saved to: {run_dir}")
            
        except Exception as e:
            logger.error(f"Could not save results: {e}")
            print(f"\n⚠️ Could not save results: {e}")


def run_cli() -> int:
    """Entry point for CLI runner."""
    parser = argparse.ArgumentParser(
        description="PRISM Engine - Modular Analysis System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python prism_run.py                           # Interactive mode
  python prism_run.py --panel market            # Direct mode
  python prism_run.py --list-panels             # List panels
  python prism_run.py --list-workflows          # List workflows
        """
    )
    
    parser.add_argument(
        "--panel", "-p",
        help="Panel to analyze (market, economy, etc.)"
    )
    parser.add_argument(
        "--workflow", "-w",
        help="Workflow to run (regime_comparison, etc.)"
    )
    parser.add_argument(
        "--list-panels",
        action="store_true",
        help="List available panels"
    )
    parser.add_argument(
        "--list-workflows",
        action="store_true",
        help="List available workflows"
    )
    parser.add_argument(
        "--list-engines",
        action="store_true",
        help="List available engines"
    )
    parser.add_argument(
        "--comparison-periods",
        nargs="+",
        default=["2008", "2020"],
        help="Comparison periods for regime analysis"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    
    args = parser.parse_args()
    
    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(levelname)s: %(message)s"
    )
    
    runner = CLIRunner()
    
    # List modes
    if args.list_panels:
        print("\nAvailable Panels:")
        print("-" * 40)
        for panel in runner.executor.list_panels():
            info = runner.executor.get_panel_info(panel)
            icon = info.get("icon", "📊") if info else "📊"
            name = info.get("name", panel) if info else panel
            print(f"  {icon} {name} [{panel}]")
        return 0
    
    if args.list_workflows:
        print("\nAvailable Workflows:")
        print("-" * 40)
        for wf in runner.executor.list_workflows():
            info = runner.executor.get_workflow_info(wf)
            name = info.get("name", wf) if info else wf
            print(f"  • {name} [{wf}]")
        return 0
    
    if args.list_engines:
        print("\nAvailable Engines:")
        print("-" * 40)
        for engine in runner.executor.list_engines():
            print(f"  • {engine}")
        return 0
    
    # Direct mode
    if args.panel:
        workflow = args.workflow or "regime_comparison"
        parameters = {
            "comparison_periods": args.comparison_periods,
        }
        return runner.run_direct(args.panel, workflow, parameters)
    
    # Interactive mode
    return runner.run_interactive()


if __name__ == "__main__":
    sys.exit(run_cli())
```

---

## Step 5: Update prism_run.py (root entry point)

**File:** `prism_run.py`

```python
#!/usr/bin/env python3
"""
PRISM Engine - Main Entry Point
=================================

Unified runner for PRISM analysis system.

Usage:
    python prism_run.py                    # Interactive CLI mode
    python prism_run.py --panel market     # Direct mode
    python prism_run.py --html             # HTML mode (if available)
    python prism_run.py --help             # Show help

See runner/ for implementation details.
"""

import sys
import argparse
from pathlib import Path

# Ensure project root is in path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))


def main() -> int:
    """Main entry point."""
    # Quick check for --html flag before full argument parsing
    if "--html" in sys.argv:
        try:
            from runner.prism_run import run_server
            return run_server()
        except ImportError:
            print("HTML runner not available. Use CLI mode instead.")
            print("Run: python prism_run.py --help")
            return 1
    
    # Default to CLI mode
    try:
        from runner.cli_runner import run_cli
        return run_cli()
    except ImportError as e:
        print(f"Error importing CLI runner: {e}")
        print("\nMake sure all dependencies are installed:")
        print("  pip install pyyaml pandas")
        return 1


if __name__ == "__main__":
    sys.exit(main())
```

---

## Step 6: Create Test Script

**File:** `test_phase3_cli.py`

```python
#!/usr/bin/env python3
"""
Phase 3 CLI Runner Verification
================================
"""

import sys
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))


def test_runner_imports():
    """Test runner package imports."""
    print("\n" + "=" * 50)
    print("TEST: Runner Imports")
    print("=" * 50)
    
    try:
        from runner import CLIRunner, WorkflowExecutor, OutputManager
        print("✓ CLIRunner imported")
        print("✓ WorkflowExecutor imported")
        print("✓ OutputManager imported")
        return True
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_executor_initialization():
    """Test executor can access all loaders."""
    print("\n" + "=" * 50)
    print("TEST: Executor Initialization")
    print("=" * 50)
    
    try:
        from runner import WorkflowExecutor
        
        executor = WorkflowExecutor()
        
        # Test panel loader
        panels = executor.list_panels()
        print(f"✓ Panel loader: {len(panels)} panels")
        
        # Test workflow loader
        workflows = executor.list_workflows()
        print(f"✓ Workflow loader: {len(workflows)} workflows")
        
        # Test engine loader
        engines = executor.list_engines()
        print(f"✓ Engine loader: {len(engines)} engines")
        
        return True
    except Exception as e:
        print(f"❌ Executor initialization failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_output_manager():
    """Test output manager functionality."""
    print("\n" + "=" * 50)
    print("TEST: Output Manager")
    print("=" * 50)
    
    try:
        from runner import OutputManager
        
        output = OutputManager()
        
        # Test run directory creation
        run_dir = output.create_run_directory(prefix="test")
        print(f"✓ Created run directory: {run_dir}")
        
        # Test JSON save
        test_data = {"test": "data", "number": 42}
        json_path = output.save_json(test_data, "test.json")
        print(f"✓ Saved JSON: {json_path}")
        
        # Test text save
        text_path = output.save_text("Test content", "test.txt")
        print(f"✓ Saved text: {text_path}")
        
        # Cleanup
        import shutil
        shutil.rmtree(run_dir)
        print("✓ Cleanup complete")
        
        return True
    except Exception as e:
        print(f"❌ Output manager test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_workflow_execution():
    """Test workflow execution."""
    print("\n" + "=" * 50)
    print("TEST: Workflow Execution")
    print("=" * 50)
    
    try:
        from runner import WorkflowExecutor
        
        executor = WorkflowExecutor()
        
        # Execute a test workflow
        print("Executing: market / lens_validation")
        results = executor.execute(
            panel_key="market",
            workflow_key="lens_validation",
            parameters={}
        )
        
        status = results.get("status")
        print(f"  Status: {status}")
        print(f"  Duration: {results.get('duration', 0):.2f}s")
        
        if status == "completed":
            print("✓ Workflow execution completed")
            return True
        else:
            print(f"❌ Workflow failed: {results.get('error')}")
            return False
            
    except Exception as e:
        print(f"❌ Workflow execution failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_cli_list_commands():
    """Test CLI list commands."""
    print("\n" + "=" * 50)
    print("TEST: CLI List Commands")
    print("=" * 50)
    
    try:
        # Test --list-panels
        result = subprocess.run(
            [sys.executable, "prism_run.py", "--list-panels"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT
        )
        if result.returncode == 0 and "market" in result.stdout.lower():
            print("✓ --list-panels works")
        else:
            print(f"❌ --list-panels failed: {result.stderr}")
            return False
        
        # Test --list-workflows
        result = subprocess.run(
            [sys.executable, "prism_run.py", "--list-workflows"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT
        )
        if result.returncode == 0 and "regime" in result.stdout.lower():
            print("✓ --list-workflows works")
        else:
            print(f"❌ --list-workflows failed: {result.stderr}")
            return False
        
        # Test --list-engines
        result = subprocess.run(
            [sys.executable, "prism_run.py", "--list-engines"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT
        )
        if result.returncode == 0 and "pca" in result.stdout.lower():
            print("✓ --list-engines works")
        else:
            print(f"❌ --list-engines failed: {result.stderr}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ CLI list commands failed: {e}")
        return False


def test_cli_direct_mode():
    """Test CLI direct mode execution."""
    print("\n" + "=" * 50)
    print("TEST: CLI Direct Mode")
    print("=" * 50)
    
    try:
        result = subprocess.run(
            [sys.executable, "prism_run.py", 
             "--panel", "market", 
             "--workflow", "lens_validation"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT,
            timeout=60
        )
        
        if result.returncode == 0:
            print("✓ Direct mode execution completed")
            if "COMPLETED" in result.stdout or "completed" in result.stdout.lower():
                print("✓ Execution status: completed")
            return True
        else:
            print(f"❌ Direct mode failed with code {result.returncode}")
            print(f"   stderr: {result.stderr[:200]}")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ CLI direct mode timed out")
        return False
    except Exception as e:
        print(f"❌ CLI direct mode failed: {e}")
        return False


def test_help_command():
    """Test help command."""
    print("\n" + "=" * 50)
    print("TEST: Help Command")
    print("=" * 50)
    
    try:
        result = subprocess.run(
            [sys.executable, "prism_run.py", "--help"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT
        )
        
        if result.returncode == 0 and "panel" in result.stdout.lower():
            print("✓ Help command works")
            return True
        else:
            print(f"❌ Help command failed")
            return False
            
    except Exception as e:
        print(f"❌ Help command failed: {e}")
        return False


def main():
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║             PRISM PHASE 3 VERIFICATION                       ║
    ║                                                              ║
    ║  Testing: Unified CLI Runner                                 ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    results = {
        "imports": test_runner_imports(),
        "executor": test_executor_initialization(),
        "output_manager": test_output_manager(),
        "workflow_execution": test_workflow_execution(),
        "cli_list": test_cli_list_commands(),
        "cli_direct": test_cli_direct_mode(),
        "help": test_help_command(),
    }
    
    print("\n" + "=" * 50)
    print("SUMMARY")
    print("=" * 50)
    
    all_passed = True
    for test, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test}: {status}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 PHASE 3 (CLI RUNNER) COMPLETE - ALL TESTS PASSED!")
    else:
        print("⚠️  PHASE 3 INCOMPLETE - SOME TESTS FAILED")
    print("=" * 50)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
```

---

## Step 7: Verification Commands

```bash
# Test 1: Show help
python prism_run.py --help

# Test 2: List panels
python prism_run.py --list-panels

# Test 3: List workflows
python prism_run.py --list-workflows

# Test 4: List engines
python prism_run.py --list-engines

# Test 5: Direct mode execution
python prism_run.py --panel market --workflow lens_validation

# Test 6: Full verification
python test_phase3_cli.py

# Test 7: Interactive mode (manual test)
python prism_run.py
```

---

## Step 8: Commit

```bash
git add runner/ prism_run.py test_phase3_cli.py
git commit -m "Phase 3: Add unified CLI runner

- Add runner/cli_runner.py interactive menu system
- Add runner/executor.py workflow execution engine
- Add runner/output_manager.py result formatting
- Update prism_run.py as main entry point

Supports:
- Interactive menu mode: python prism_run.py
- Direct mode: python prism_run.py --panel market
- List commands: --list-panels, --list-workflows, --list-engines

Integrates Phase 1 (engines) + Phase 2 (panels) + workflows"
```

---

## Files Summary

```
runner/
├── __init__.py           # Package exports (updated)
├── cli_runner.py         # Interactive CLI (~350 lines)
├── executor.py           # Workflow execution (~250 lines)
└── output_manager.py     # Result formatting (~180 lines)

prism_run.py              # Main entry point (updated)
test_phase3_cli.py        # Verification script
```

---

## Usage Examples

### Interactive Mode
```bash
$ python prism_run.py

╔══════════════════════════════════════════════════════════╗
║                      PRISM ENGINE                        ║
╚══════════════════════════════════════════════════════════╝
Modular Analysis System v2.0

📊 SELECT PANEL
----------------------------------------
  1. 📈 Market [market]
  2. 🏛️ Economy [economy]
  3. 🌍 Climate [climate]
  4. ⚙️ Custom [custom]
  0. Exit
----------------------------------------
Enter selection (0-4): 1

✓ Selected panel: market

⚙️ SELECT WORKFLOW
----------------------------------------
  1. Regime Comparison
  2. Full Temporal
  3. Daily Update
  ...
```

### Direct Mode
```bash
$ python prism_run.py --panel market --workflow regime_comparison

╔══════════════════════════════════════════════════════════╗
║              PRISM ENGINE - Direct Mode                  ║
╚══════════════════════════════════════════════════════════╝
Panel: market
Workflow: regime_comparison
============================================================

EXECUTING ANALYSIS...
...

✅ EXECUTION COMPLETED
============================================================
Panel: market
Workflow: regime_comparison
Duration: 1.23s
...
```

---

## What This Enables

**Before Phase 3:**
```bash
# Multiple separate scripts, no unified interface
python run_regime_comparison.py
python temporal_analysis.py
python daily_update.py
```

**After Phase 3:**
```bash
# Single unified entry point
python prism_run.py                                    # Interactive
python prism_run.py --panel market                     # Direct
python prism_run.py --list-workflows                   # Discovery
python prism_run.py -p market -w daily_update          # Scripting
```
