# PRISM Fetcher Quick Reference

## API Keys
```
FRED_API_KEY=3fd12c9d0fa4d7fd3c858b72251e3388
TIINGO_API_KEY=39a87d4f616a7432dbc92533eeed14c238f6d159
```

## Dependencies
```bash
pip install fredapi tiingo --break-system-packages
```

## Architecture
```
FRED (54 indicators)     →  Economic/Macro data
Tiingo (16 indicators)   →  Sector ETFs + Market ETFs
                         
NO FALLBACK - Each source is authoritative
```

## Files to Create/Modify

| File | Action |
|------|--------|
| `fetch/fetcher_tiingo.py` | CREATE (new file) |
| `fetch/fetcher_fred.py` | UPDATE (remove sectors) |
| `fetch/fetcher_unified.py` | UPDATE (combined interface) |
| `fetch/__init__.py` | UPDATE (new exports) |
| `fetch/fetcher_yahoo.py` | DELETE |
| `fetch/fetcher_stooq.py` | DELETE |

## Tiingo Indicators (16 total)

### Sector ETFs (11)
```python
'sector_energy':                ('XLE',  'Energy Select Sector SPDR')
'sector_materials':             ('XLB',  'Materials Select Sector SPDR')
'sector_industrials':           ('XLI',  'Industrial Select Sector SPDR')
'sector_consumer_discretionary':('XLY',  'Consumer Discretionary SPDR')
'sector_consumer_staples':      ('XLP',  'Consumer Staples SPDR')
'sector_healthcare':            ('XLV',  'Health Care Select Sector SPDR')
'sector_financials':            ('XLF',  'Financial Select Sector SPDR')
'sector_technology':            ('XLK',  'Technology Select Sector SPDR')
'sector_communication':         ('XLC',  'Communication Services SPDR')
'sector_utilities':             ('XLU',  'Utilities Select Sector SPDR')
'sector_real_estate':           ('XLRE', 'Real Estate Select Sector SPDR')
```

### Index ETFs (4)
```python
'etf_sp500':      ('SPY', 'S&P 500 ETF')
'etf_nasdaq100':  ('QQQ', 'NASDAQ 100 ETF')
'etf_dow':        ('DIA', 'Dow Jones ETF')
'etf_russell2000':('IWM', 'Russell 2000 ETF')
```

### Volatility (1)
```python
'etf_volatility': ('VIXY', 'VIX Short-Term Futures ETF')
```

## FRED Indicators to REMOVE (moving to Tiingo)
```python
# DELETE these from FRED registry:
'sector_energy'
'sector_materials'
'sector_industrials'
'sector_consumer_discretionary'
'sector_consumer_staples'
'sector_healthcare'
'sector_financials'
'sector_technology'
'sector_communication'
'sector_utilities'
'sector_real_estate'
```

## Quick Test
```python
import os
os.environ['TIINGO_API_KEY'] = '39a87d4f616a7432dbc92533eeed14c238f6d159'

from tiingo import TiingoClient
client = TiingoClient({'api_key': os.environ['TIINGO_API_KEY']})

# Test XLE
df = client.get_dataframe('XLE', startDate='2024-01-01', frequency='daily')
print(f"XLE: {len(df)} rows")
print(df.tail())
```

## Usage After Implementation
```python
from fetch import PRISMUnifiedFetcher

fetcher = PRISMUnifiedFetcher()

# Fetch everything
df = fetcher.fetch_all()

# Or specific data
sectors = fetcher.fetch_sectors()    # Tiingo
economy = fetcher.fetch_economy()    # FRED

# Combined monthly
monthly = fetcher.get_combined(frequency='M')
```
