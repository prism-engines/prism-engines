# PRISM Fetcher Implementation: FRED + Tiingo

## Instructions for Claude Code

Implement a dual-source data fetcher architecture eliminating Yahoo and Stooq entirely.

---

## API Keys

```bash
FRED_API_KEY=3fd12c9d0fa4d7fd3c858b72251e3388
TIINGO_API_KEY=39a87d4f616a7432dbc92533eeed14c238f6d159
```

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     PRISM Data Layer                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   FRED (Economic Data)           Tiingo (Market Data)        │
│   ════════════════════           ═══════════════════         │
│   • Macro indicators             • Sector ETFs               │
│   • Interest rates               • Market ETFs (SPY, QQQ)    │
│   • Employment/Labor             • VIX ETF proxy             │
│   • Inflation/Prices             • Individual stocks         │
│   • GDP/Production                                           │
│   • Credit spreads                                           │
│   • Monetary policy                                          │
│   • Trade/Currency                                           │
│                                                              │
│   ~54 indicators                 ~15 indicators              │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                    NO FALLBACK LOGIC                         │
│         Each source is authoritative for its indicators      │
└─────────────────────────────────────────────────────────────┘
```

---

## File Structure

```
fetch/
├── __init__.py              # Updated exports
├── fetcher_fred.py          # FRED-only fetcher (economic data)
├── fetcher_tiingo.py        # NEW: Tiingo fetcher (market/sector data)
├── fetcher_unified.py       # Combined interface
├── fetcher_base.py          # Keep as-is
├── configs/
│   └── sources.yaml         # Combined source config
└── [DELETE these files]
    ├── fetcher_yahoo.py     # DELETE
    └── fetcher_stooq.py     # DELETE
```

---

## Step 1: Install Dependencies

```bash
pip install fredapi tiingo --break-system-packages
```

---

## Step 2: Create `fetch/fetcher_tiingo.py`

```python
"""
PRISM Tiingo Fetcher
====================
Market and sector data from Tiingo API.

Handles data not available from FRED:
- Sector ETFs (XLE, XLF, XLK, etc.)
- Market ETFs (SPY, QQQ, DIA, IWM)
- Volatility proxy (VXX or VIXY)

NO FALLBACK LOGIC - Tiingo is authoritative for these indicators.

Author: PRISM Engine Project
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
import logging
import os

logger = logging.getLogger(__name__)


# =============================================================================
# TIINGO INDICATOR REGISTRY
# =============================================================================

TIINGO_INDICATORS = {
    # =========================================================================
    # SECTOR ETFs - SPDR Select Sector
    # =========================================================================
    'sector_energy': {
        'symbol': 'XLE',
        'name': 'Energy Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Energy sector',
        'inception': '1998-12-16',
    },
    'sector_materials': {
        'symbol': 'XLB',
        'name': 'Materials Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Materials sector',
        'inception': '1998-12-16',
    },
    'sector_industrials': {
        'symbol': 'XLI',
        'name': 'Industrial Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Industrials sector',
        'inception': '1998-12-16',
    },
    'sector_consumer_discretionary': {
        'symbol': 'XLY',
        'name': 'Consumer Discretionary Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Consumer Discretionary sector',
        'inception': '1998-12-16',
    },
    'sector_consumer_staples': {
        'symbol': 'XLP',
        'name': 'Consumer Staples Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Consumer Staples sector',
        'inception': '1998-12-16',
    },
    'sector_healthcare': {
        'symbol': 'XLV',
        'name': 'Health Care Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Health Care sector',
        'inception': '1998-12-16',
    },
    'sector_financials': {
        'symbol': 'XLF',
        'name': 'Financial Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Financials sector',
        'inception': '1998-12-16',
    },
    'sector_technology': {
        'symbol': 'XLK',
        'name': 'Technology Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Information Technology sector',
        'inception': '1998-12-16',
    },
    'sector_communication': {
        'symbol': 'XLC',
        'name': 'Communication Services Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Communication Services sector',
        'inception': '2018-06-18',
    },
    'sector_utilities': {
        'symbol': 'XLU',
        'name': 'Utilities Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Utilities sector',
        'inception': '1998-12-16',
    },
    'sector_real_estate': {
        'symbol': 'XLRE',
        'name': 'Real Estate Select Sector SPDR',
        'category': 'sectors',
        'description': 'Tracks S&P 500 Real Estate sector',
        'inception': '2015-10-07',
    },

    # =========================================================================
    # MARKET ETFs
    # =========================================================================
    'etf_sp500': {
        'symbol': 'SPY',
        'name': 'SPDR S&P 500 ETF Trust',
        'category': 'indexes',
        'description': 'Tracks S&P 500 Index',
        'inception': '1993-01-22',
    },
    'etf_nasdaq100': {
        'symbol': 'QQQ',
        'name': 'Invesco QQQ Trust',
        'category': 'indexes',
        'description': 'Tracks NASDAQ-100 Index',
        'inception': '1999-03-10',
    },
    'etf_dow': {
        'symbol': 'DIA',
        'name': 'SPDR Dow Jones Industrial Average ETF',
        'category': 'indexes',
        'description': 'Tracks Dow Jones Industrial Average',
        'inception': '1998-01-14',
    },
    'etf_russell2000': {
        'symbol': 'IWM',
        'name': 'iShares Russell 2000 ETF',
        'category': 'indexes',
        'description': 'Tracks Russell 2000 small-cap index',
        'inception': '2000-05-22',
    },

    # =========================================================================
    # VOLATILITY
    # =========================================================================
    'etf_volatility': {
        'symbol': 'VIXY',
        'name': 'ProShares VIX Short-Term Futures ETF',
        'category': 'volatility',
        'description': 'VIX short-term futures exposure',
        'inception': '2011-01-03',
    },
}


# =============================================================================
# TIINGO FETCHER CLASS
# =============================================================================

class TiingoFetcher:
    """
    Tiingo data fetcher for market and sector data.
    
    Complements FRED fetcher - handles data FRED doesn't provide.
    NO FALLBACK LOGIC - Tiingo is authoritative for its indicators.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        start_date: str = '1998-01-01',
        end_date: Optional[str] = None
    ):
        """
        Initialize the Tiingo fetcher.
        
        Parameters:
            api_key: Tiingo API key (or set TIINGO_API_KEY env variable)
            start_date: Default start date for data fetches
            end_date: Default end date (defaults to today)
        """
        self.api_key = api_key or os.environ.get('TIINGO_API_KEY')
        if not self.api_key:
            raise ValueError(
                "Tiingo API key required. Set TIINGO_API_KEY env variable or pass api_key parameter.\n"
                "Get a free key at: https://www.tiingo.com/"
            )
        
        self.start_date = start_date
        self.end_date = end_date or datetime.today().strftime('%Y-%m-%d')
        
        # Initialize Tiingo client
        try:
            from tiingo import TiingoClient
            config = {'api_key': self.api_key, 'session': True}
            self.client = TiingoClient(config)
        except ImportError:
            raise ImportError("tiingo required: pip install tiingo")
        
        # Storage
        self.data: Dict[str, pd.DataFrame] = {}
        self.metadata: Dict[str, Dict] = {}
        self.failed: List[tuple] = []
    
    # -------------------------------------------------------------------------
    # Core Fetch Methods
    # -------------------------------------------------------------------------
    
    def fetch_series(
        self,
        symbol: str,
        key: str,
        start: Optional[str] = None,
        end: Optional[str] = None
    ) -> Optional[pd.Series]:
        """
        Fetch a single ticker from Tiingo.
        
        Parameters:
            symbol: Ticker symbol
            key: PRISM indicator key
            start: Start date
            end: End date
            
        Returns:
            pandas Series (adjusted close) or None if failed
        """
        start = start or self.start_date
        end = end or self.end_date
        
        try:
            # Fetch historical prices
            df = self.client.get_dataframe(
                symbol,
                startDate=start,
                endDate=end,
                frequency='daily'
            )
            
            if df.empty:
                logger.warning(f"Empty data for {key} ({symbol})")
                self.failed.append((key, symbol, "Empty data returned"))
                return None
            
            # Use adjusted close price
            if 'adjClose' in df.columns:
                series = df['adjClose']
            elif 'close' in df.columns:
                series = df['close']
            else:
                logger.warning(f"No close price for {key} ({symbol})")
                self.failed.append((key, symbol, "No close price column"))
                return None
            
            series.name = key
            series.index = pd.to_datetime(series.index)
            
            # Remove timezone info if present
            if series.index.tz is not None:
                series.index = series.index.tz_localize(None)
            
            logger.debug(f"Fetched {key} ({symbol}): {len(series)} obs")
            return series
            
        except Exception as e:
            logger.warning(f"Failed {key} ({symbol}): {str(e)[:80]}")
            self.failed.append((key, symbol, str(e)))
            return None
    
    def fetch_sectors(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        verbose: bool = True
    ) -> pd.DataFrame:
        """
        Fetch all sector ETF data.
        
        Parameters:
            start: Start date
            end: End date
            verbose: Print progress
            
        Returns:
            DataFrame with all sector ETFs
        """
        if verbose:
            print(f"\n{'='*60}")
            print("📊 Fetching Sector ETFs from Tiingo")
            print(f"{'='*60}")
        
        results = {}
        
        for key, config in TIINGO_INDICATORS.items():
            if config['category'] != 'sectors':
                continue
            
            symbol = config['symbol']
            series = self.fetch_series(symbol, key, start, end)
            
            if series is not None:
                results[key] = series
                self.metadata[key] = {
                    'symbol': symbol,
                    'name': config['name'],
                    'category': config['category'],
                    'source': 'tiingo',
                    'observations': len(series),
                }
                if verbose:
                    print(f"  ✅ {key:35s} {symbol:6s} {len(series):5d} obs")
            elif verbose:
                print(f"  ❌ {key:35s} {symbol:6s} FAILED")
        
        if results:
            df = pd.DataFrame(results)
            df.index = pd.to_datetime(df.index)
            df = df.sort_index()
            self.data['sectors'] = df
            return df
        
        return pd.DataFrame()
    
    def fetch_indexes(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        verbose: bool = True
    ) -> pd.DataFrame:
        """
        Fetch market index ETFs.
        
        Parameters:
            start: Start date
            end: End date
            verbose: Print progress
            
        Returns:
            DataFrame with index ETFs
        """
        if verbose:
            print(f"\n{'='*60}")
            print("📈 Fetching Index ETFs from Tiingo")
            print(f"{'='*60}")
        
        results = {}
        
        for key, config in TIINGO_INDICATORS.items():
            if config['category'] != 'indexes':
                continue
            
            symbol = config['symbol']
            series = self.fetch_series(symbol, key, start, end)
            
            if series is not None:
                results[key] = series
                self.metadata[key] = {
                    'symbol': symbol,
                    'name': config['name'],
                    'category': config['category'],
                    'source': 'tiingo',
                    'observations': len(series),
                }
                if verbose:
                    print(f"  ✅ {key:20s} {symbol:6s} {len(series):5d} obs")
            elif verbose:
                print(f"  ❌ {key:20s} {symbol:6s} FAILED")
        
        if results:
            df = pd.DataFrame(results)
            df.index = pd.to_datetime(df.index)
            df = df.sort_index()
            self.data['indexes'] = df
            return df
        
        return pd.DataFrame()
    
    def fetch_all(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        verbose: bool = True
    ) -> pd.DataFrame:
        """
        Fetch all Tiingo indicators.
        
        Parameters:
            start: Start date
            end: End date
            verbose: Print progress
            
        Returns:
            Combined DataFrame
        """
        if verbose:
            print("\n" + "="*60)
            print("PRISM TIINGO FETCHER")
            print(f"Date Range: {start or self.start_date} to {end or self.end_date}")
            print(f"Indicators: {len(TIINGO_INDICATORS)}")
            print("="*60)
        
        results = {}
        
        for key, config in TIINGO_INDICATORS.items():
            symbol = config['symbol']
            series = self.fetch_series(symbol, key, start, end)
            
            if series is not None:
                results[key] = series
                self.metadata[key] = {
                    'symbol': symbol,
                    'name': config['name'],
                    'category': config['category'],
                    'source': 'tiingo',
                    'observations': len(series),
                }
                if verbose:
                    print(f"  ✅ {key:35s} {symbol:6s} {len(series):5d} obs  ({config['category']})")
            elif verbose:
                print(f"  ❌ {key:35s} {symbol:6s} FAILED")
        
        if verbose:
            self._print_summary()
        
        if results:
            df = pd.DataFrame(results)
            df.index = pd.to_datetime(df.index)
            df = df.sort_index()
            self.data['all'] = df
            return df
        
        return pd.DataFrame()
    
    # -------------------------------------------------------------------------
    # Data Access Methods
    # -------------------------------------------------------------------------
    
    def get_combined(self, frequency: str = 'D') -> pd.DataFrame:
        """
        Get all fetched data combined.
        
        Parameters:
            frequency: Resample frequency ('D', 'W', 'M')
            
        Returns:
            Combined DataFrame
        """
        all_series = {}
        
        for category, df in self.data.items():
            for col in df.columns:
                all_series[col] = df[col]
        
        if not all_series:
            return pd.DataFrame()
        
        combined = pd.DataFrame(all_series)
        
        if frequency and frequency != 'D':
            combined = combined.resample(frequency).last()
        
        return combined
    
    def get_sectors(self) -> pd.DataFrame:
        """Get sector ETF data."""
        return self.data.get('sectors', pd.DataFrame())
    
    def get_indexes(self) -> pd.DataFrame:
        """Get index ETF data."""
        return self.data.get('indexes', pd.DataFrame())
    
    # -------------------------------------------------------------------------
    # Export Methods
    # -------------------------------------------------------------------------
    
    def save_to_csv(
        self,
        output_dir: str,
        prefix: str = 'tiingo'
    ) -> Path:
        """
        Save data to CSV files.
        
        Parameters:
            output_dir: Output directory
            prefix: Filename prefix
            
        Returns:
            Path to output directory
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        for category, df in self.data.items():
            filepath = output_path / f'{prefix}_{category}.csv'
            df.to_csv(filepath)
            print(f"+ Saved: {filepath} ({df.shape})")
        
        # Save metadata
        if self.metadata:
            meta_df = pd.DataFrame(self.metadata).T
            meta_path = output_path / f'{prefix}_metadata.csv'
            meta_df.to_csv(meta_path)
            print(f"+ Saved: {meta_path}")
        
        return output_path
    
    # -------------------------------------------------------------------------
    # Utility Methods
    # -------------------------------------------------------------------------
    
    def _print_summary(self):
        """Print fetch summary."""
        print("\n" + "-"*60)
        print("TIINGO FETCH SUMMARY")
        print("-"*60)
        
        total_fetched = len(self.metadata)
        total_failed = len(self.failed)
        
        print(f"Total indicators: {len(TIINGO_INDICATORS)}")
        print(f"Successfully fetched: {total_fetched}")
        print(f"Failed: {total_failed}")
        
        if self.failed:
            print("\nFailed tickers:")
            for key, symbol, error in self.failed[:5]:
                print(f"  - {key} ({symbol}): {error[:50]}")
            if len(self.failed) > 5:
                print(f"  ... and {len(self.failed) - 5} more")
        
        # Count by category
        categories = {}
        for key, meta in self.metadata.items():
            cat = meta.get('category', 'other')
            categories[cat] = categories.get(cat, 0) + 1
        
        if categories:
            print("\nBy category:")
            for cat, count in sorted(categories.items()):
                print(f"  {cat:15s}: {count:3d} indicators")
    
    @staticmethod
    def list_indicators(category: Optional[str] = None) -> pd.DataFrame:
        """
        List all available Tiingo indicators.
        
        Parameters:
            category: Filter by category (None = all)
            
        Returns:
            DataFrame with indicator information
        """
        rows = []
        for key, config in TIINGO_INDICATORS.items():
            if category and config['category'] != category:
                continue
            rows.append({
                'key': key,
                'symbol': config['symbol'],
                'name': config['name'],
                'category': config['category'],
                'inception': config.get('inception', 'N/A'),
            })
        return pd.DataFrame(rows)
    
    @staticmethod
    def list_categories() -> List[str]:
        """List all available categories."""
        return sorted(set(c['category'] for c in TIINGO_INDICATORS.values()))


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def fetch_sectors(api_key: Optional[str] = None) -> pd.DataFrame:
    """Quick function to fetch sector ETF data."""
    fetcher = TiingoFetcher(api_key=api_key)
    return fetcher.fetch_sectors()


def fetch_market_etfs(api_key: Optional[str] = None) -> pd.DataFrame:
    """Quick function to fetch market index ETFs."""
    fetcher = TiingoFetcher(api_key=api_key)
    return fetcher.fetch_indexes()


def fetch_tiingo_all(api_key: Optional[str] = None) -> pd.DataFrame:
    """Quick function to fetch all Tiingo data."""
    fetcher = TiingoFetcher(api_key=api_key)
    return fetcher.fetch_all()


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    print("""
    ================================================================
    PRISM TIINGO FETCHER
    ================================================================
    Market and sector data from Tiingo API
    
    Indicators:
    - 11 Sector ETFs (XLE, XLF, XLK, etc.)
    -  4 Index ETFs (SPY, QQQ, DIA, IWM)
    -  1 Volatility ETF (VIXY)
    
    Total: 16 indicators
    ================================================================
    """)
    
    # Print inventory
    print("\nINDICATOR INVENTORY")
    print("="*70)
    
    for category in TiingoFetcher.list_categories():
        indicators = [(k, v) for k, v in TIINGO_INDICATORS.items() if v['category'] == category]
        print(f"\n[{category.upper()}] - {len(indicators)} indicators")
        print("-"*50)
        for key, config in indicators:
            print(f"  {key:35s} {config['symbol']:6s} {config['name'][:40]}")
    
    print("\n" + "="*70)
    print(f"TOTAL INDICATORS: {len(TIINGO_INDICATORS)}")
    print("="*70)
```

---

## Step 3: Update `fetch/fetcher_fred.py` (Remove Sectors)

Remove the sector indicators from FRED fetcher since they don't exist on FRED.

The FRED fetcher should contain ONLY economic/macro data:
- Growth (GDP, industrial production, etc.)
- Labor (payrolls, unemployment, etc.)
- Inflation (CPI, PCE, etc.)
- Monetary (fed funds, treasury yields, etc.)
- Credit (spreads, lending, etc.)
- Sentiment (consumer sentiment, ISM, etc.)
- Trade (imports, exports, trade balance)
- Debt (federal debt, consumer credit, etc.)
- Housing (mortgage rates, home prices)
- Volatility (VIX from FRED: VIXCLS)
- Indexes (SP500, NASDAQ, DJIA from FRED)

**DELETE these from FRED registry** (moving to Tiingo):
```python
# DELETE - These are moving to Tiingo
'sector_energy'
'sector_materials'
'sector_industrials'
'sector_consumer_discretionary'
'sector_consumer_staples'
'sector_healthcare'
'sector_financials'
'sector_technology'
'sector_communication'
'sector_utilities'
'sector_real_estate'
```

---

## Step 4: Create `fetch/fetcher_unified.py` (Combined Interface)

```python
"""
PRISM Unified Data Fetcher
==========================
Combined interface for FRED + Tiingo data sources.

NO FALLBACK LOGIC - Each source is authoritative for its indicators:
- FRED: Economic/macro data (54 indicators)
- Tiingo: Market/sector data (16 indicators)

Author: PRISM Engine Project
"""

import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path
import logging
import os

logger = logging.getLogger(__name__)


class PRISMUnifiedFetcher:
    """
    Unified data fetcher combining FRED and Tiingo.
    
    Each source handles specific data types with no overlap or fallback.
    """
    
    def __init__(
        self,
        fred_api_key: Optional[str] = None,
        tiingo_api_key: Optional[str] = None,
        start_date: str = '1970-01-01',
        end_date: Optional[str] = None
    ):
        """
        Initialize unified fetcher.
        
        Parameters:
            fred_api_key: FRED API key (or FRED_API_KEY env var)
            tiingo_api_key: Tiingo API key (or TIINGO_API_KEY env var)
            start_date: Default start date
            end_date: Default end date
        """
        self.fred_api_key = fred_api_key or os.environ.get('FRED_API_KEY')
        self.tiingo_api_key = tiingo_api_key or os.environ.get('TIINGO_API_KEY')
        
        self.start_date = start_date
        self.end_date = end_date or datetime.today().strftime('%Y-%m-%d')
        
        # Initialize fetchers lazily
        self._fred_fetcher = None
        self._tiingo_fetcher = None
        
        # Combined data storage
        self.data: Dict[str, pd.DataFrame] = {}
        self.metadata: Dict[str, Dict] = {}
    
    @property
    def fred(self):
        """Lazy-load FRED fetcher."""
        if self._fred_fetcher is None:
            from fetch.fetcher_fred import FREDFetcher
            self._fred_fetcher = FREDFetcher(
                api_key=self.fred_api_key,
                start_date=self.start_date,
                end_date=self.end_date
            )
        return self._fred_fetcher
    
    @property
    def tiingo(self):
        """Lazy-load Tiingo fetcher."""
        if self._tiingo_fetcher is None:
            from fetch.fetcher_tiingo import TiingoFetcher
            self._tiingo_fetcher = TiingoFetcher(
                api_key=self.tiingo_api_key,
                start_date=self.start_date,
                end_date=self.end_date
            )
        return self._tiingo_fetcher
    
    def fetch_all(self, verbose: bool = True) -> pd.DataFrame:
        """
        Fetch all data from both sources.
        
        Returns:
            Combined DataFrame with all indicators
        """
        if verbose:
            print("\n" + "="*70)
            print("PRISM UNIFIED DATA FETCHER")
            print(f"Date Range: {self.start_date} to {self.end_date}")
            print("Sources: FRED (economic) + Tiingo (market/sectors)")
            print("="*70)
        
        # Fetch from FRED (economic data)
        if verbose:
            print("\n[1/2] FRED Economic Data")
        fred_df = self.fred.fetch_all(verbose=verbose)
        self.data['fred'] = fred_df
        self.metadata.update(self.fred.metadata)
        
        # Fetch from Tiingo (market/sector data)
        if verbose:
            print("\n[2/2] Tiingo Market Data")
        tiingo_df = self.tiingo.fetch_all(verbose=verbose)
        self.data['tiingo'] = tiingo_df
        self.metadata.update(self.tiingo.metadata)
        
        # Combine
        combined = self.get_combined()
        
        if verbose:
            self._print_summary()
        
        return combined
    
    def fetch_economy(self, verbose: bool = True) -> pd.DataFrame:
        """Fetch FRED economic data only."""
        df = self.fred.fetch_all(verbose=verbose)
        self.data['fred'] = df
        self.metadata.update(self.fred.metadata)
        return df
    
    def fetch_sectors(self, verbose: bool = True) -> pd.DataFrame:
        """Fetch Tiingo sector ETF data only."""
        df = self.tiingo.fetch_sectors(verbose=verbose)
        self.data['sectors'] = df
        self.metadata.update(self.tiingo.metadata)
        return df
    
    def fetch_market(self, verbose: bool = True) -> pd.DataFrame:
        """Fetch all Tiingo market data (sectors + indexes)."""
        df = self.tiingo.fetch_all(verbose=verbose)
        self.data['tiingo'] = df
        self.metadata.update(self.tiingo.metadata)
        return df
    
    def get_combined(self, frequency: str = 'D') -> pd.DataFrame:
        """
        Get combined DataFrame from all sources.
        
        Parameters:
            frequency: Resample frequency ('D', 'W', 'M')
            
        Returns:
            Combined DataFrame
        """
        all_dfs = []
        
        for source, df in self.data.items():
            if not df.empty:
                all_dfs.append(df)
        
        if not all_dfs:
            return pd.DataFrame()
        
        # Combine all DataFrames
        combined = pd.concat(all_dfs, axis=1)
        
        # Remove duplicate columns if any
        combined = combined.loc[:, ~combined.columns.duplicated()]
        
        # Resample if needed
        if frequency and frequency != 'D':
            combined = combined.resample(frequency).last()
        
        return combined
    
    def get_by_category(self, category: str) -> pd.DataFrame:
        """
        Get indicators by category.
        
        Parameters:
            category: Category name (e.g., 'sectors', 'labor', 'inflation')
            
        Returns:
            DataFrame with category indicators
        """
        keys = [
            k for k, meta in self.metadata.items()
            if meta.get('category') == category
        ]
        
        combined = self.get_combined()
        return combined[[k for k in keys if k in combined.columns]]
    
    def save_to_csv(
        self,
        output_dir: str,
        combined: bool = True,
        by_source: bool = True,
        prefix: str = 'prism'
    ) -> Path:
        """
        Save data to CSV files.
        
        Parameters:
            output_dir: Output directory
            combined: Save combined DataFrame
            by_source: Save separate files by source
            prefix: Filename prefix
            
        Returns:
            Output directory path
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        if combined:
            combined_df = self.get_combined(frequency='M')
            if not combined_df.empty:
                filepath = output_path / f'{prefix}_combined.csv'
                combined_df.to_csv(filepath)
                print(f"+ Saved: {filepath} ({combined_df.shape})")
        
        if by_source:
            for source, df in self.data.items():
                if not df.empty:
                    filepath = output_path / f'{prefix}_{source}.csv'
                    df.to_csv(filepath)
                    print(f"+ Saved: {filepath} ({df.shape})")
        
        # Save metadata
        if self.metadata:
            meta_df = pd.DataFrame(self.metadata).T
            meta_path = output_path / f'{prefix}_metadata.csv'
            meta_df.to_csv(meta_path)
            print(f"+ Saved: {meta_path}")
        
        return output_path
    
    def _print_summary(self):
        """Print combined fetch summary."""
        print("\n" + "="*70)
        print("UNIFIED FETCH SUMMARY")
        print("="*70)
        
        # By source
        print("\nBy source:")
        for source, df in self.data.items():
            if not df.empty:
                print(f"  {source:15s}: {len(df.columns):3d} indicators, {len(df):6d} rows")
        
        # By category
        categories = {}
        for key, meta in self.metadata.items():
            cat = meta.get('category', 'other')
            categories[cat] = categories.get(cat, 0) + 1
        
        print("\nBy category:")
        for cat, count in sorted(categories.items()):
            print(f"  {cat:20s}: {count:3d} indicators")
        
        total = len(self.metadata)
        print(f"\nTOTAL: {total} indicators")


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def fetch_prism_data(
    fred_api_key: Optional[str] = None,
    tiingo_api_key: Optional[str] = None,
    output_dir: Optional[str] = None,
    start_date: str = '1970-01-01'
) -> PRISMUnifiedFetcher:
    """
    Quick-start function to fetch all PRISM data.
    
    Parameters:
        fred_api_key: FRED API key
        tiingo_api_key: Tiingo API key
        output_dir: Save CSVs to this directory
        start_date: Data start date
        
    Returns:
        PRISMUnifiedFetcher instance with data
    """
    fetcher = PRISMUnifiedFetcher(
        fred_api_key=fred_api_key,
        tiingo_api_key=tiingo_api_key,
        start_date=start_date
    )
    
    fetcher.fetch_all()
    
    if output_dir:
        fetcher.save_to_csv(output_dir)
    
    return fetcher


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    print("""
    ================================================================
    PRISM UNIFIED DATA FETCHER
    ================================================================
    
    Combined FRED + Tiingo data access
    
    FRED:   ~54 economic/macro indicators
    Tiingo: ~16 market/sector indicators
    
    Usage:
    ------
    from fetch.fetcher_unified import PRISMUnifiedFetcher
    
    fetcher = PRISMUnifiedFetcher()
    df = fetcher.fetch_all()
    
    # Or fetch specific data
    economy_df = fetcher.fetch_economy()
    sectors_df = fetcher.fetch_sectors()
    
    # Get by category
    labor_df = fetcher.get_by_category('labor')
    ================================================================
    """)
```

---

## Step 5: Update `fetch/__init__.py`

```python
"""
PRISM Fetch Module
==================
Unified data fetching from FRED and Tiingo.

NO FALLBACK LOGIC - Each source is authoritative:
- FRED: Economic/macro data
- Tiingo: Market/sector data
"""

from .fetcher_fred import FREDFetcher, FRED_INDICATORS
from .fetcher_tiingo import TiingoFetcher, TIINGO_INDICATORS
from .fetcher_unified import PRISMUnifiedFetcher, fetch_prism_data

__all__ = [
    # Classes
    'FREDFetcher',
    'TiingoFetcher', 
    'PRISMUnifiedFetcher',
    
    # Registries
    'FRED_INDICATORS',
    'TIINGO_INDICATORS',
    
    # Convenience functions
    'fetch_prism_data',
]
```

---

## Step 6: Delete Old Files

```bash
# Delete Yahoo and Stooq fetchers
rm fetch/fetcher_yahoo.py
rm fetch/fetcher_stooq.py

# If they exist in configs
rm -f fetch/configs/yahoo_sources.yaml
rm -f fetch/configs/stooq_sources.yaml
```

---

## Step 7: Test the Implementation

```python
#!/usr/bin/env python3
"""Test FRED + Tiingo fetcher implementation."""

import os

# Set API keys
os.environ['FRED_API_KEY'] = '3fd12c9d0fa4d7fd3c858b72251e3388'
os.environ['TIINGO_API_KEY'] = '39a87d4f616a7432dbc92533eeed14c238f6d159'

def test_tiingo():
    """Test Tiingo fetcher."""
    print("\n" + "="*60)
    print("TEST: Tiingo Fetcher")
    print("="*60)
    
    from fetch.fetcher_tiingo import TiingoFetcher
    
    fetcher = TiingoFetcher()
    
    # Test sectors
    sectors_df = fetcher.fetch_sectors()
    print(f"\nSectors: {sectors_df.shape}")
    print(f"Columns: {list(sectors_df.columns)}")
    
    # Test indexes
    indexes_df = fetcher.fetch_indexes()
    print(f"\nIndexes: {indexes_df.shape}")
    
    return len(sectors_df.columns) >= 10


def test_fred():
    """Test FRED fetcher."""
    print("\n" + "="*60)
    print("TEST: FRED Fetcher")
    print("="*60)
    
    from fetch.fetcher_fred import FREDFetcher
    
    fetcher = FREDFetcher()
    
    # Fetch subset for testing
    df = fetcher.fetch_panel(
        categories=['labor', 'inflation'],
        verbose=True
    )
    
    print(f"\nFRED data: {df.shape}")
    
    return len(df.columns) >= 5


def test_unified():
    """Test unified fetcher."""
    print("\n" + "="*60)
    print("TEST: Unified Fetcher")
    print("="*60)
    
    from fetch.fetcher_unified import PRISMUnifiedFetcher
    
    fetcher = PRISMUnifiedFetcher()
    
    # Fetch sectors
    sectors_df = fetcher.fetch_sectors()
    print(f"\nSectors from Tiingo: {sectors_df.shape}")
    
    # Combined
    combined = fetcher.get_combined(frequency='M')
    print(f"Combined monthly: {combined.shape}")
    
    return not combined.empty


def main():
    results = {
        'tiingo': test_tiingo(),
        'fred': test_fred(),
        'unified': test_unified(),
    }
    
    print("\n" + "="*60)
    print("TEST RESULTS")
    print("="*60)
    
    for test, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"  {test:15s} {status}")
    
    all_passed = all(results.values())
    print("\n" + ("🎉 ALL TESTS PASSED!" if all_passed else "⚠️ SOME TESTS FAILED"))
    
    return 0 if all_passed else 1


if __name__ == '__main__':
    exit(main())
```

---

## Summary

| Component | Status | Notes |
|-----------|--------|-------|
| `fetcher_tiingo.py` | NEW | 16 indicators (sectors + indexes) |
| `fetcher_fred.py` | UPDATE | Remove sector indicators |
| `fetcher_unified.py` | UPDATE | Combined FRED + Tiingo |
| `fetcher_yahoo.py` | DELETE | Eliminated |
| `fetcher_stooq.py` | DELETE | Eliminated |
| `__init__.py` | UPDATE | New exports |

**Final indicator count:**
- FRED: ~54 indicators (economic/macro)
- Tiingo: ~16 indicators (sectors/market)
- **Total: ~70 indicators**

**API Keys to configure:**
```bash
FRED_API_KEY=3fd12c9d0fa4d7fd3c858b72251e3388
TIINGO_API_KEY=39a87d4f616a7432dbc92533eeed14c238f6d159
```
