# PRISM Phase 1 - Quick Reference for Claude Code

## ⚠️ CRITICAL: Work on MAIN branch only

```bash
git checkout main
git pull origin main
```

---

## Files to Create (8 total)

### 1. engines/__init__.py
```python
from .engine_loader import (EngineLoader, EngineLoadError, get_loader, 
    list_engines, list_lenses, load_engine, run_engine)
__all__ = ["EngineLoader", "EngineLoadError", "get_loader", 
    "list_engines", "list_lenses", "load_engine", "run_engine"]
```

### 2. engines/registry.yaml
- YAML file defining 14 lenses + 2 meta engines
- Each engine has: name, module, class, category, lens (bool), compatible_panels
- See CLAUDE_CODE_PHASE1_INSTRUCTIONS.md for full content

### 3. engines/engine_loader.py
- EngineLoader class with methods:
  - list_engines(), list_lenses()
  - get_engine_info(key), get_engines_by_category(cat)
  - get_compatible_engines(panel, resolution)
  - load_engine(key), validate_engine(key)
- Module-level functions: list_engines(), list_lenses(), load_engine()

### 4. workflows/__init__.py
```python
from .workflow_loader import (WorkflowLoader, WorkflowLoadError, get_loader,
    list_workflows, run_workflow, run_preset)
__all__ = ["WorkflowLoader", "WorkflowLoadError", "get_loader",
    "list_workflows", "run_workflow", "run_preset"]
```

### 5. workflows/registry.yaml
- YAML file defining 3 workflows: regime_comparison, full_temporal, daily_update
- Each workflow has: name, module, class, compatible_panels, parameters
- Include presets section

### 6. workflows/workflow_loader.py
- WorkflowLoader class with methods:
  - list_workflows(), get_workflow_info(key)
  - get_compatible_workflows(panel)
  - run_workflow(key, **params), run_preset(name)
- Module-level functions: list_workflows(), run_workflow(), run_preset()

### 7. runner/__init__.py
```python
"""PRISM Runner Package - Unified entry point."""
__all__ = []
```

### 8. test_phase1.py (at project root)
- Verification script to confirm everything works
- Tests: engine loader, workflow loader, existing code compatibility

---

## Verification Commands

```bash
# Test 1: Engine loader
python -c "from engines import list_engines; print(list_engines())"
# Expected: ['pca', 'granger', 'clustering', ...] (16 engines)

# Test 2: Workflow loader  
python -c "from workflows import list_workflows; print(list_workflows())"
# Expected: ['regime_comparison', 'full_temporal', 'daily_update']

# Test 3: Full verification
python test_phase1.py
# Expected: ALL TESTS PASSED
```

---

## Commit Message

```
Phase 1: Add engine and workflow registry infrastructure

- Add engines/registry.yaml with 14 lenses + weighting engines
- Add engines/engine_loader.py with auto-discovery
- Add workflows/registry.yaml with workflow definitions
- Add workflows/workflow_loader.py with auto-discovery
- Create runner/ directory for unified entry point
- Add test_phase1.py verification script

This enables plugin-style architecture where adding new engines
or workflows only requires updating the YAML registry.
```

---

## Success Criteria

✅ `from engines import list_engines` works  
✅ `from workflows import list_workflows` works  
✅ Returns correct number of engines (16) and workflows (3)  
✅ Existing code (engine_core.lenses.*) still imports  
✅ test_phase1.py passes all tests
