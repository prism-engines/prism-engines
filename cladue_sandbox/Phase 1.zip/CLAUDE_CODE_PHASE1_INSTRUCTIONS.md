# PRISM Phase 1: Registry + Loader Infrastructure
## Claude Code Implementation Instructions

**TARGET BRANCH: main**
**DO NOT CREATE A NEW BRANCH - Work directly on main**

---

## Overview

Phase 1 creates the plugin infrastructure that enables auto-discovery of engines and workflows. This is foundational - everything else builds on it.

**Goals:**
1. Create engine registry (YAML) mapping all 14 lenses + weighting engines
2. Create workflow registry (YAML) defining available workflows
3. Create engine loader with auto-discovery
4. Create workflow loader with auto-discovery
5. Verify existing code still works

**Success Criteria:**
- `python -c "from engines import list_engines; print(list_engines())"` returns engine list
- `python -c "from workflows import list_workflows; print(list_workflows())"` returns workflow list
- All existing tests still pass

---

## Step 1: Create Directory Structure

```bash
# Run from project root (prism-engine/)
mkdir -p engines
mkdir -p workflows
mkdir -p runner
mkdir -p templates/runner
mkdir -p templates/static
```

**Verify:**
```bash
ls -la engines/ workflows/ runner/ templates/
```

---

## Step 2: Create engines/__init__.py

**File:** `engines/__init__.py`

```python
"""
PRISM Engines Package
======================

Auto-discoverable analysis engines loaded from registry.yaml.

Usage:
    from engines import EngineLoader, list_engines, load_engine
    
    # List all engines
    engines = list_engines()
    
    # Load a specific engine
    pca = load_engine("pca")
    
    # Run analysis
    results = pca.rank_indicators(df)
"""

from .engine_loader import (
    EngineLoader,
    EngineLoadError,
    get_loader,
    list_engines,
    list_lenses,
    load_engine,
    run_engine,
)

__all__ = [
    "EngineLoader",
    "EngineLoadError",
    "get_loader",
    "list_engines",
    "list_lenses",
    "load_engine",
    "run_engine",
]
```

---

## Step 3: Create engines/registry.yaml

**File:** `engines/registry.yaml`

This file defines all available engines. Create it with the following content:

```yaml
# PRISM ENGINE REGISTRY
# Defines all available analysis engines and their capabilities.

version: "1.0.0"
last_updated: "2024-12-07"

categories:
  geometry:
    name: "Geometric Analysis"
    description: "Dimensionality reduction and manifold analysis"
  causality:
    name: "Causal Analysis"
    description: "Causal inference and network analysis"
  regime:
    name: "Regime Detection"
    description: "Market regime identification and comparison"
  weighting:
    name: "Indicator Weighting"
    description: "Methods for weighting indicator importance"
  temporal:
    name: "Temporal Analysis"
    description: "Time-based and window analysis"
  diagnostics:
    name: "Diagnostics & Validation"
    description: "Model validation and stress testing"

engines:
  # LENS ENGINES (Core 14)
  pca:
    name: "PCA Analysis"
    module: "engine_core.lenses.pca_lens"
    class: "PCALens"
    category: "geometry"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate", "custom"]
    compatible_resolutions: ["daily", "weekly", "monthly"]

  granger:
    name: "Granger Causality"
    module: "engine_core.lenses.granger_lens"
    class: "GrangerLens"
    category: "causality"
    lens: true
    compatible_panels: ["market", "economy", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  clustering:
    name: "Hierarchical Clustering"
    module: "engine_core.lenses.clustering_lens"
    class: "ClusteringLens"
    category: "regime"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate", "custom"]
    compatible_resolutions: ["daily", "weekly", "monthly"]

  network:
    name: "Network Analysis"
    module: "engine_core.lenses.network_lens"
    class: "NetworkLens"
    category: "causality"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate"]
    compatible_resolutions: ["daily", "weekly", "monthly"]

  tda:
    name: "Topological Data Analysis"
    module: "engine_core.lenses.tda_lens"
    class: "TDALens"
    category: "geometry"
    lens: true
    compatible_panels: ["market", "economy", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  anomaly:
    name: "Anomaly Detection"
    module: "engine_core.lenses.anomaly_lens"
    class: "AnomalyLens"
    category: "regime"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate"]
    compatible_resolutions: ["daily", "weekly"]

  correlation:
    name: "Correlation Analysis"
    module: "engine_core.lenses.correlation_lens"
    class: "CorrelationLens"
    category: "geometry"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate", "custom"]
    compatible_resolutions: ["daily", "weekly", "monthly"]

  volatility:
    name: "Volatility Analysis"
    module: "engine_core.lenses.volatility_lens"
    class: "VolatilityLens"
    category: "regime"
    lens: true
    compatible_panels: ["market", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  momentum:
    name: "Momentum Analysis"
    module: "engine_core.lenses.momentum_lens"
    class: "MomentumLens"
    category: "temporal"
    lens: true
    compatible_panels: ["market", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  mean_reversion:
    name: "Mean Reversion"
    module: "engine_core.lenses.mean_reversion_lens"
    class: "MeanReversionLens"
    category: "temporal"
    lens: true
    compatible_panels: ["market", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  cointegration:
    name: "Cointegration Analysis"
    module: "engine_core.lenses.cointegration_lens"
    class: "CointegrationLens"
    category: "causality"
    lens: true
    compatible_panels: ["market", "economy", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  wavelet:
    name: "Wavelet Analysis"
    module: "engine_core.lenses.wavelet_lens"
    class: "WaveletLens"
    category: "temporal"
    lens: true
    compatible_panels: ["market", "economy", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  entropy:
    name: "Entropy Analysis"
    module: "engine_core.lenses.entropy_lens"
    class: "EntropyLens"
    category: "regime"
    lens: true
    compatible_panels: ["market", "economy", "market_economy", "climate"]
    compatible_resolutions: ["daily", "weekly", "monthly"]

  causality:
    name: "Transfer Entropy"
    module: "engine_core.lenses.causality_lens"
    class: "CausalityLens"
    category: "causality"
    lens: true
    compatible_panels: ["market", "economy", "market_economy"]
    compatible_resolutions: ["daily", "weekly"]

  # WEIGHTING ENGINES
  meta_consensus:
    name: "Meta Engine (Consensus)"
    module: "engine_core.orchestration.consensus"
    class: "ConsensusEngine"
    category: "weighting"
    lens: false
    compatible_panels: ["*"]
    compatible_resolutions: ["*"]

  # REGIME ENGINES
  regime_fingerprint:
    name: "Regime Fingerprint"
    module: "engine_core.regime_fingerprint"
    class: "RegimeFingerprintAnalyzer"
    category: "regime"
    lens: false
    compatible_panels: ["market", "market_economy"]
    compatible_resolutions: ["daily"]

defaults:
  lens_set: "full"
  lens_sets:
    full:
      - pca
      - granger
      - clustering
      - network
      - tda
      - anomaly
      - correlation
      - volatility
      - momentum
      - mean_reversion
      - cointegration
      - wavelet
      - entropy
      - causality
    quick:
      - pca
      - correlation
      - volatility
      - clustering
```

---

## Step 4: Create engines/engine_loader.py

**File:** `engines/engine_loader.py`

```python
"""
PRISM Engine Loader
====================

Auto-discovers and loads engines from the registry.
"""

import importlib
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Type
import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent
REGISTRY_PATH = PROJECT_ROOT / "engines" / "registry.yaml"


class EngineLoadError(Exception):
    """Raised when an engine cannot be loaded."""
    pass


class EngineLoader:
    """Loads and manages analysis engines from the registry."""
    
    def __init__(self, registry_path: Optional[Path] = None):
        self.registry_path = registry_path or REGISTRY_PATH
        self._registry: Optional[Dict] = None
        self._engine_cache: Dict[str, Any] = {}
        self._class_cache: Dict[str, Type] = {}
        
    @property
    def registry(self) -> Dict:
        """Lazy-load the registry."""
        if self._registry is None:
            self._registry = self._load_registry()
        return self._registry
    
    def _load_registry(self) -> Dict:
        """Load the engine registry from YAML."""
        if not self.registry_path.exists():
            raise FileNotFoundError(f"Engine registry not found: {self.registry_path}")
        
        with open(self.registry_path, 'r') as f:
            registry = yaml.safe_load(f)
        
        logger.info(f"Loaded engine registry: {len(registry.get('engines', {}))} engines")
        return registry
    
    def reload_registry(self) -> None:
        """Force reload of the registry."""
        self._registry = None
        self._engine_cache.clear()
        self._class_cache.clear()
    
    def list_engines(self) -> List[str]:
        """List all available engine names."""
        return list(self.registry.get("engines", {}).keys())
    
    def list_lenses(self) -> List[str]:
        """List all lens engines."""
        return [
            key for key, config in self.registry.get("engines", {}).items()
            if config.get("lens", False)
        ]
    
    def get_engine_info(self, engine_key: str) -> Optional[Dict]:
        """Get full configuration for an engine."""
        return self.registry.get("engines", {}).get(engine_key)
    
    def get_engines_by_category(self, category: str) -> List[str]:
        """Get all engines in a category."""
        return [
            key for key, config in self.registry.get("engines", {}).items()
            if config.get("category") == category
        ]
    
    def get_compatible_engines(self, panel: str, resolution: str = "daily") -> List[str]:
        """Get engines compatible with a panel and resolution."""
        compatible = []
        for key, config in self.registry.get("engines", {}).items():
            panels = config.get("compatible_panels", [])
            resolutions = config.get("compatible_resolutions", [])
            panel_ok = "*" in panels or panel in panels
            resolution_ok = "*" in resolutions or resolution in resolutions
            if panel_ok and resolution_ok:
                compatible.append(key)
        return compatible
    
    def get_lens_set(self, set_name: str = "full") -> List[str]:
        """Get a predefined set of lenses."""
        defaults = self.registry.get("defaults", {})
        lens_sets = defaults.get("lens_sets", {})
        return lens_sets.get(set_name, self.list_lenses())
    
    def get_categories(self) -> Dict[str, Dict]:
        """Get all engine categories."""
        return self.registry.get("categories", {})
    
    def load_engine_class(self, engine_key: str) -> Type:
        """Load an engine class without instantiating."""
        if engine_key in self._class_cache:
            return self._class_cache[engine_key]
        
        config = self.get_engine_info(engine_key)
        if not config:
            raise EngineLoadError(f"Unknown engine: {engine_key}")
        
        module_path = config.get("module")
        class_name = config.get("class")
        
        if not module_path or not class_name:
            raise EngineLoadError(f"Engine {engine_key} missing module or class")
        
        try:
            module = importlib.import_module(module_path)
            engine_class = getattr(module, class_name)
            self._class_cache[engine_key] = engine_class
            return engine_class
        except ImportError as e:
            raise EngineLoadError(f"Could not import {module_path}: {e}")
        except AttributeError as e:
            raise EngineLoadError(f"Class {class_name} not found in {module_path}: {e}")
    
    def load_engine(self, engine_key: str, **init_kwargs) -> Any:
        """Load and instantiate an engine."""
        cache_key = f"{engine_key}_{hash(frozenset(init_kwargs.items()))}"
        
        if cache_key in self._engine_cache:
            return self._engine_cache[cache_key]
        
        engine_class = self.load_engine_class(engine_key)
        
        try:
            engine = engine_class(**init_kwargs)
            self._engine_cache[cache_key] = engine
            return engine
        except Exception as e:
            raise EngineLoadError(f"Could not instantiate {engine_key}: {e}")
    
    def validate_engine(self, engine_key: str) -> Dict[str, Any]:
        """Validate that an engine can be loaded."""
        result = {"engine": engine_key, "valid": False, "errors": []}
        
        config = self.get_engine_info(engine_key)
        if not config:
            result["errors"].append("Engine not in registry")
            return result
        
        try:
            engine_class = self.load_engine_class(engine_key)
            result["loadable"] = True
            result["has_rank_indicators"] = hasattr(engine_class, "rank_indicators")
            result["valid"] = result["loadable"] and not result["errors"]
        except EngineLoadError as e:
            result["errors"].append(str(e))
        
        return result
    
    def get_engine_summary(self) -> str:
        """Get a formatted summary of all engines."""
        lines = ["=" * 60, "PRISM ENGINE REGISTRY", "=" * 60, ""]
        
        for cat_key, cat_info in self.get_categories().items():
            engines = self.get_engines_by_category(cat_key)
            if engines:
                lines.append(f"📁 {cat_info.get('name', cat_key)}")
                for eng in engines:
                    info = self.get_engine_info(eng)
                    lens_marker = "🔍" if info.get("lens") else "  "
                    lines.append(f"   {lens_marker} {eng}: {info.get('name', '')}")
                lines.append("")
        
        lines.extend(["-" * 60, f"Total: {len(self.list_engines())} engines, {len(self.list_lenses())} lenses"])
        return "\n".join(lines)


# Module-level convenience functions
_default_loader: Optional[EngineLoader] = None

def get_loader() -> EngineLoader:
    global _default_loader
    if _default_loader is None:
        _default_loader = EngineLoader()
    return _default_loader

def list_engines() -> List[str]:
    return get_loader().list_engines()

def list_lenses() -> List[str]:
    return get_loader().list_lenses()

def load_engine(engine_key: str, **kwargs) -> Any:
    return get_loader().load_engine(engine_key, **kwargs)

def run_engine(engine_key: str, method: str = "analyze", **kwargs) -> Any:
    engine = get_loader().load_engine(engine_key)
    return getattr(engine, method)(**kwargs)


if __name__ == "__main__":
    loader = EngineLoader()
    print(loader.get_engine_summary())
```

---

## Step 5: Test Engine Loader

```bash
# From project root
cd /path/to/prism-engine

# Test 1: List engines
python -c "from engines import list_engines; print('Engines:', list_engines())"

# Test 2: List lenses  
python -c "from engines import list_lenses; print('Lenses:', list_lenses())"

# Test 3: Get engine summary
python -c "from engines import EngineLoader; print(EngineLoader().get_engine_summary())"

# Test 4: Validate a specific engine
python -c "from engines import EngineLoader; print(EngineLoader().validate_engine('pca'))"
```

**Expected Output for Test 1:**
```
Engines: ['pca', 'granger', 'clustering', 'network', 'tda', 'anomaly', 'correlation', 'volatility', 'momentum', 'mean_reversion', 'cointegration', 'wavelet', 'entropy', 'causality', 'meta_consensus', 'regime_fingerprint']
```

---

## Step 6: Create workflows/__init__.py

**File:** `workflows/__init__.py`

```python
"""
PRISM Workflows Package
========================

Auto-discoverable analysis workflows loaded from registry.yaml.
"""

from .workflow_loader import (
    WorkflowLoader,
    WorkflowLoadError,
    get_loader,
    list_workflows,
    run_workflow,
    run_preset,
)

__all__ = [
    "WorkflowLoader",
    "WorkflowLoadError",
    "get_loader",
    "list_workflows",
    "run_workflow",
    "run_preset",
]
```

---

## Step 7: Create workflows/registry.yaml

**File:** `workflows/registry.yaml`

```yaml
# PRISM WORKFLOW REGISTRY
# Defines all available analysis workflows.

version: "1.0.0"
last_updated: "2024-12-07"

categories:
  regime:
    name: "Regime Analysis"
    description: "Market regime detection and comparison"
  temporal:
    name: "Temporal Analysis"
    description: "Time-windowed historical analysis"
  monitoring:
    name: "Monitoring & Updates"
    description: "Regular monitoring and daily updates"

workflows:
  regime_comparison:
    name: "Regime Comparison Analysis"
    description: "Compare current market regime to historical periods"
    category: "regime"
    module: "engine_core.tandem_regime_runner"
    class: "TandemRegimeRunner"
    compatible_panels: ["market", "market_economy"]
    estimated_runtime: "2-5 minutes"
    parameters:
      current_period:
        type: "string"
        default: "2024_current"
      comparison_periods:
        type: "list"
        default: ["2001_dotcom", "2008_gfc", "2020_covid", "2022_bear"]
      data_source:
        type: "string"
        default: "database"

  full_temporal:
    name: "Full Temporal Analysis"
    description: "55-window analysis from 1970-2025"
    category: "temporal"
    module: "engine_core.orchestration.temporal_runner"
    class: "TemporalAnalysisRunner"
    compatible_panels: ["market", "market_economy"]
    estimated_runtime: "10-30 minutes"
    parameters:
      start_year:
        type: "int"
        default: 1970
      end_year:
        type: "int"
        default: 2025
      window_years:
        type: "int"
        default: 2

  daily_update:
    name: "Daily Market Update"
    description: "Quick daily check of market regime"
    category: "monitoring"
    module: "workflows.daily_update"
    class: "DailyUpdateWorkflow"
    compatible_panels: ["market"]
    estimated_runtime: "30 seconds"
    parameters:
      lookback_days:
        type: "int"
        default: 21

presets:
  quick_check:
    name: "Quick Market Check"
    workflow: "daily_update"
    parameters:
      lookback_days: 5
      
  deep_dive:
    name: "Deep Dive Analysis"
    workflow: "regime_comparison"
    parameters:
      comparison_periods: ["2001_dotcom", "2008_gfc", "2020_covid", "2022_bear"]

defaults:
  default_workflow: "regime_comparison"
  output_dir: "output/{date}_{time}"
```

---

## Step 8: Create workflows/workflow_loader.py

**File:** `workflows/workflow_loader.py`

```python
"""
PRISM Workflow Loader
======================

Auto-discovers and loads workflows from the registry.
"""

import importlib
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Type
import yaml

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent
REGISTRY_PATH = PROJECT_ROOT / "workflows" / "registry.yaml"


class WorkflowLoadError(Exception):
    """Raised when a workflow cannot be loaded."""
    pass


class WorkflowLoader:
    """Loads and manages analysis workflows from the registry."""
    
    def __init__(self, registry_path: Optional[Path] = None):
        self.registry_path = registry_path or REGISTRY_PATH
        self._registry: Optional[Dict] = None
        
    @property
    def registry(self) -> Dict:
        if self._registry is None:
            self._registry = self._load_registry()
        return self._registry
    
    def _load_registry(self) -> Dict:
        if not self.registry_path.exists():
            raise FileNotFoundError(f"Workflow registry not found: {self.registry_path}")
        with open(self.registry_path, 'r') as f:
            return yaml.safe_load(f)
    
    def reload_registry(self) -> None:
        self._registry = None
    
    def list_workflows(self) -> List[str]:
        return list(self.registry.get("workflows", {}).keys())
    
    def get_workflow_info(self, workflow_key: str) -> Optional[Dict]:
        return self.registry.get("workflows", {}).get(workflow_key)
    
    def get_workflows_by_category(self, category: str) -> List[str]:
        return [
            key for key, config in self.registry.get("workflows", {}).items()
            if config.get("category") == category
        ]
    
    def get_compatible_workflows(self, panel: str) -> List[str]:
        compatible = []
        for key, config in self.registry.get("workflows", {}).items():
            panels = config.get("compatible_panels", [])
            if "*" in panels or panel in panels:
                compatible.append(key)
        return compatible
    
    def get_categories(self) -> Dict[str, Dict]:
        return self.registry.get("categories", {})
    
    def get_presets(self) -> Dict[str, Dict]:
        return self.registry.get("presets", {})
    
    def get_default_parameters(self, workflow_key: str) -> Dict[str, Any]:
        params = self.get_workflow_info(workflow_key).get("parameters", {})
        return {name: config.get("default") for name, config in params.items()}
    
    def load_workflow_class(self, workflow_key: str) -> Type:
        config = self.get_workflow_info(workflow_key)
        if not config:
            raise WorkflowLoadError(f"Unknown workflow: {workflow_key}")
        
        module_path = config.get("module")
        class_name = config.get("class")
        
        try:
            module = importlib.import_module(module_path)
            return getattr(module, class_name)
        except ImportError as e:
            raise WorkflowLoadError(f"Could not import {module_path}: {e}")
        except AttributeError as e:
            raise WorkflowLoadError(f"Class {class_name} not found: {e}")
    
    def load_workflow(self, workflow_key: str, **init_kwargs) -> Any:
        workflow_class = self.load_workflow_class(workflow_key)
        return workflow_class(**init_kwargs)
    
    def run_workflow(self, workflow_key: str, panel: Optional[str] = None, **params) -> Dict[str, Any]:
        info = self.get_workflow_info(workflow_key)
        if not info:
            raise WorkflowLoadError(f"Unknown workflow: {workflow_key}")
        
        # Validate panel compatibility
        if panel:
            compatible = info.get("compatible_panels", ["*"])
            if "*" not in compatible and panel not in compatible:
                raise ValueError(f"Workflow {workflow_key} not compatible with panel {panel}")
        
        # Merge defaults with provided params
        defaults = self.get_default_parameters(workflow_key)
        final_params = {**defaults, **params}
        
        # Load and run
        workflow = self.load_workflow(workflow_key)
        
        if hasattr(workflow, 'run'):
            return workflow.run(**final_params)
        elif hasattr(workflow, 'analyze'):
            return workflow.analyze(**final_params)
        else:
            raise WorkflowLoadError(f"Workflow {workflow_key} has no run() method")
    
    def run_preset(self, preset_name: str, **override_params) -> Dict[str, Any]:
        presets = self.get_presets()
        if preset_name not in presets:
            raise WorkflowLoadError(f"Unknown preset: {preset_name}")
        
        preset = presets[preset_name]
        workflow_key = preset.get("workflow")
        preset_params = preset.get("parameters", {})
        
        return self.run_workflow(workflow_key, **{**preset_params, **override_params})
    
    def get_workflow_summary(self) -> str:
        lines = ["=" * 60, "PRISM WORKFLOW REGISTRY", "=" * 60, ""]
        
        for cat_key, cat_info in self.get_categories().items():
            workflows = self.get_workflows_by_category(cat_key)
            if workflows:
                lines.append(f"📁 {cat_info.get('name', cat_key)}")
                for wf in workflows:
                    info = self.get_workflow_info(wf)
                    lines.append(f"   • {wf}: {info.get('name', '')} ({info.get('estimated_runtime', '')})")
                lines.append("")
        
        lines.extend(["-" * 60, f"Total: {len(self.list_workflows())} workflows"])
        return "\n".join(lines)


# Module-level convenience functions
_default_loader: Optional[WorkflowLoader] = None

def get_loader() -> WorkflowLoader:
    global _default_loader
    if _default_loader is None:
        _default_loader = WorkflowLoader()
    return _default_loader

def list_workflows() -> List[str]:
    return get_loader().list_workflows()

def run_workflow(workflow_key: str, **params) -> Dict[str, Any]:
    return get_loader().run_workflow(workflow_key, **params)

def run_preset(preset_name: str, **params) -> Dict[str, Any]:
    return get_loader().run_preset(preset_name, **params)


if __name__ == "__main__":
    loader = WorkflowLoader()
    print(loader.get_workflow_summary())
```

---

## Step 9: Test Workflow Loader

```bash
# Test 1: List workflows
python -c "from workflows import list_workflows; print('Workflows:', list_workflows())"

# Test 2: Get workflow summary
python -c "from workflows import WorkflowLoader; print(WorkflowLoader().get_workflow_summary())"

# Test 3: Get compatible workflows for market panel
python -c "from workflows import WorkflowLoader; print(WorkflowLoader().get_compatible_workflows('market'))"
```

**Expected Output for Test 1:**
```
Workflows: ['regime_comparison', 'full_temporal', 'daily_update']
```

---

## Step 10: Create runner/__init__.py

**File:** `runner/__init__.py`

```python
"""
PRISM Runner Package
=====================

Unified entry point for PRISM analysis.
"""

__all__ = []
```

---

## Step 11: Verify Existing Code Still Works

```bash
# Test that existing lenses still import
python -c "from engine_core.lenses import PCALens; print('PCALens OK')"

# Test that orchestration still imports
python -c "from engine_core.orchestration.consensus import ConsensusEngine; print('ConsensusEngine OK')"

# Run existing tests if available
python -m pytest tests/ -v --tb=short 2>/dev/null || echo "No pytest or tests skipped"
```

---

## Step 12: Commit Changes

```bash
git add engines/ workflows/ runner/
git commit -m "Phase 1: Add engine and workflow registry infrastructure

- Add engines/registry.yaml with 14 lenses + weighting engines
- Add engines/engine_loader.py with auto-discovery
- Add workflows/registry.yaml with workflow definitions  
- Add workflows/workflow_loader.py with auto-discovery
- Create runner/ directory for unified entry point

This enables plugin-style architecture where adding new engines
or workflows only requires updating the YAML registry."
```

---

## Verification Checklist

Run all these commands and verify they work:

```bash
# ✓ Engine loader works
python -c "from engines import list_engines; assert len(list_engines()) >= 14"

# ✓ Workflow loader works
python -c "from workflows import list_workflows; assert len(list_workflows()) >= 3"

# ✓ Engine registry loads
python -c "from engines import EngineLoader; l = EngineLoader(); assert 'pca' in l.list_lenses()"

# ✓ Workflow registry loads
python -c "from workflows import WorkflowLoader; l = WorkflowLoader(); assert 'regime_comparison' in l.list_workflows()"

# ✓ Existing code unaffected
python -c "from engine_core.lenses.pca_lens import PCALens"
```

If all pass, Phase 1 is complete!

---

## Files Created Summary

```
engines/
  __init__.py
  registry.yaml
  engine_loader.py

workflows/
  __init__.py
  registry.yaml
  workflow_loader.py

runner/
  __init__.py
```

---

## Next Phase Preview

Phase 2 will add:
- `runner/prism_run.py` - Flask-based HTML interface
- `runner/dispatcher.py` - Routes UI to workflows
- `templates/` - HTML templates for the UI
